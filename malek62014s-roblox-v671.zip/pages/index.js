import { db, auth } from "hatchable";

const OWNER_EMAIL = "robloxassetsowner@protonmail.com";

const esc = (s) => String(s ?? "")
  .replace(/&/g, "&amp;")
  .replace(/</g, "&lt;")
  .replace(/>/g, "&gt;")
  .replace(/\"/g, "&quot;")
  .replace(/'/g, "&#39;");

export const access = "public";

export default async function (req, res) {
  const member = await auth.getUser(req);
  let username = "User";
  let isAdmin = false;
  let userId = "";

  let maintenance = { enabled: false, reason: "" };
  try {
    const { rows: maintenanceRows } = await db.query("SELECT key,value FROM site_settings WHERE key IN ('maintenance_enabled','maintenance_reason')");
    const maintenanceMap = Object.fromEntries(maintenanceRows.map(x => [x.key, x.value]));
    maintenance = { enabled: maintenanceMap.maintenance_enabled === "1", reason: maintenanceMap.maintenance_reason || "" };
  } catch (_) {}

  if (member) {
    userId = String(member.id || "");
    let email = String(member.email || "").trim().toLowerCase();
    if (!email) {
      try {
        const { rows: userRows } = await db.query("SELECT lower(email) AS email FROM users WHERE id = $1 LIMIT 1", [userId]);
        email = String(userRows[0]?.email || "").trim().toLowerCase();
      } catch (_) {}
    }
    isAdmin = email === OWNER_EMAIL;
    if (!isAdmin) {
      try {
        const { rows: adminRows } = await db.query(
          "SELECT 1 FROM admin_user_directory WHERE is_admin = true AND (user_id = $1 OR lower(email) = lower($2)) LIMIT 1",
          [userId, email]
        );
        isAdmin = adminRows.length > 0;
      } catch (_) {}
    }

    try {
      const { rows } = await db.query(
        "SELECT username FROM profile_usernames WHERE user_id = $1 LIMIT 1",
        [userId]
      );
      username = String(rows[0]?.username || "User");
    } catch (_) {
      username = "User";
    }
  }

  if (maintenance.enabled) {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Vary", "Cookie");
    res.send(`<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Website Offline · Roblox Assets</title><style>*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#07090c;color:#f7f8fa;font-family:Segoe UI,system-ui,sans-serif}body{min-height:100vh;display:grid;place-items:center;padding:22px;background:radial-gradient(circle at 50% 0,rgba(226,35,26,.18),transparent 35%),linear-gradient(180deg,#0a0d11,#06080b)}.card{width:min(620px,100%);padding:38px;border:1px solid rgba(255,255,255,.10);border-radius:26px;background:linear-gradient(180deg,#151b23,#0b1016);box-shadow:0 35px 120px rgba(0,0,0,.65);text-align:center}.icon{width:74px;height:74px;margin:0 auto 18px;border-radius:22px;display:grid;place-items:center;background:linear-gradient(145deg,#ff5149,#9e1712);font-size:32px;font-weight:950;box-shadow:0 18px 45px rgba(226,35,26,.25)}.eyebrow{font-size:10px;letter-spacing:.18em;color:#798595;font-weight:950;text-transform:uppercase}.title{font-size:34px;letter-spacing:-1px;font-weight:950;margin:9px 0}.copy{color:#9aa5b4;line-height:1.65;font-size:13px}.reason{margin-top:20px;padding:15px 16px;border:1px solid rgba(226,35,26,.22);border-radius:15px;background:rgba(226,35,26,.07);text-align:left}.reason b{display:block;font-size:10px;letter-spacing:.1em;color:#ffaaa4;text-transform:uppercase}.reason p{margin:7px 0 0;color:#d8dde4;line-height:1.5;white-space:pre-wrap}.foot{margin-top:20px;color:#727f8f;font-size:10px}a{display:inline-block;margin-top:18px;padding:11px 16px;border-radius:11px;background:#171e27;border:1px solid #344151;color:#fff;text-decoration:none;font-weight:850}a:hover{border-color:#586679}</style></head><body><main class="card"><div class="icon">R</div><div class="eyebrow">MALEK62014'S ROBLOX ASSETS</div><div class="title">Website temporarily offline</div><div class="copy">The website is currently shut down while maintenance is in progress. Please check back later.</div>${maintenance.reason?`<div class="reason"><b>Maintenance reason</b><p>${esc(maintenance.reason)}</p></div>`:""}<div class="foot">The admin control center remains available to the site owner.</div><a href="/support/">Customer Support</a></main></body></html>`);
    return;
  }

  const accountHtml = member
    ? `<div class="account-wrap"><span class="account-name">${esc(username)}</span><button class="account-btn" id="public-account">Account ▾</button>${isAdmin ? '<a class="account-admin" id="public-admin-link" href="/admin/">Admin</a>' : ''}<div id="public-account-menu" class="account-menu" style="display:none;position:absolute;right:0;top:44px;background:#14171c;border:1px solid #262b33;border-radius:10px;padding:8px;min-width:190px"><button class="account-btn" id="change-username">Change Username</button><button class="account-btn" id="sign-out">Sign out</button></div></div>`
    : `<div class="account-wrap"><button class="account-btn" id="public-account">Account ▾</button><div id="public-account-menu" class="account-menu" style="display:none;position:absolute;right:0;top:44px;background:#14171c;border:1px solid #262b33;border-radius:10px;padding:8px;min-width:150px"><a class="account-btn" href="/login?next=/">Sign in</a></div></div>`;

  res.setHeader("Cache-Control", "private, no-store, max-age=0");
  res.setHeader("Vary", "Cookie");
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>malek62014's Roblox Assets</title>
<meta name="description" content="Download Roblox Studio assets by malek62014 — flashlights, scripts, models and tools." />
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2220%22 fill=%22%23E2231A%22/><text x=%2250%22 y=%2266%22 font-size=%2260%22 text-anchor=%22middle%22 fill=%22white%22 font-family=%22Arial%22>R</text></svg>" />
<link rel="manifest" href="/manifest.webmanifest" />
<meta name="theme-color" content="#e2231a" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-title" content="Roblox Assets" />
<style>
:root{--bg:#0b0d10;--bg-elev:#14171c;--bg-elev-2:#1b1f26;--border:#262b33;--red:#e2231a;--red-bright:#ff3b30;--white:#f5f6f7;--muted:#9aa1ab;--success:#34c759;--danger:#ff453a}*{box-sizing:border-box}html,body{margin:0;padding:0;background:var(--bg);color:var(--white);font-family:'Segoe UI','Inter',system-ui,-apple-system,Arial,sans-serif;-webkit-font-smoothing:antialiased;overflow-x:hidden}#root{min-height:100vh}::-webkit-scrollbar{width:10px}::-webkit-scrollbar-track{background:var(--bg)}::-webkit-scrollbar-thumb{background:#33383f;border-radius:8px}::-webkit-scrollbar-thumb:hover{background:var(--red)}a{color:inherit}button{font-family:inherit;cursor:pointer}@keyframes fadeIn{from{opacity:0}to{opacity:1}}@keyframes slideUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}@keyframes slideDown{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:translateY(0)}}@keyframes scaleIn{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}@keyframes toastIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:translateX(0)}}@keyframes toastOut{from{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(40px)}}@keyframes pulseGlow{0%,100%{box-shadow:0 0 0 0 rgba(226,35,26,.35)}50%{box-shadow:0 0 0 8px rgba(226,35,26,0)}}@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.asset-card{position:relative;overflow:hidden}.asset-card::before{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 20%,rgba(255,255,255,.045) 45%,transparent 70%);background-size:220% 100%;background-position:-220% 0;pointer-events:none;opacity:0;transition:opacity .25s ease}.asset-card:hover::before{opacity:1;animation:shimmer 1s ease}.asset-card:hover{border-color:rgba(226,35,26,.45)!important;box-shadow:0 16px 34px rgba(0,0,0,.35),0 0 0 1px rgba(226,35,26,.08);transform:translateY(-5px)!important}.asset-card button{box-shadow:0 8px 18px rgba(0,0,0,.14)}#account-root{position:relative;z-index:45;max-width:1200px;margin:8px auto 0;padding:0 20px;display:flex;justify-content:flex-end;pointer-events:none;min-height:0}.account-wrap{position:static;pointer-events:auto;display:flex;align-items:center;gap:8px;background:rgba(11,13,16,.96);padding:6px;border:1px solid var(--border);border-radius:10px;box-shadow:0 8px 25px rgba(0,0,0,.3)}.account-name{color:var(--muted);font-size:12px}.account-btn,.account-admin{padding:8px 11px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:700}.account-btn{background:var(--red);color:#fff;border:1px solid var(--red)}.account-admin{background:var(--red);color:#fff}
[dir="rtl"] .toast-rtl-flip{transform:scaleX(-1)}@media(max-width:640px){.rbx-hide-mobile{display:none!important}}
/* Premium UI polish: motion, depth, focus, and micro-interactions */
.ui-fx button,.ui-fx a,button,a{transition:transform .16s cubic-bezier(.2,.8,.2,1),filter .16s ease,box-shadow .16s ease,background-color .16s ease,border-color .16s ease,opacity .16s ease}
button:hover,a:hover{filter:brightness(1.08)}
button:active,a:active{transform:scale(.965)}
button:focus-visible,a:focus-visible{outline:2px solid rgba(255,59,48,.8);outline-offset:2px}
.account-wrap{transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease;background:rgba(14,17,22,.88);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
.account-wrap:hover{transform:translateY(-1px);box-shadow:0 12px 32px rgba(0,0,0,.42),0 0 0 1px rgba(226,35,26,.12)}
.account-menu{transform-origin:top right;animation:menuPop .18s cubic-bezier(.2,.8,.2,1)}
.account-menu button,.account-menu a{display:block!important;width:100%;margin:4px 0;text-align:left;background:#1a1f27!important;border-color:#303743!important}
.account-menu button:hover,.account-menu a:hover{background:#232a34!important;transform:translateX(2px)}
@keyframes menuPop{from{opacity:0;transform:translateY(-6px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes shimmer{0%{background-position:-220% 0}100%{background-position:220% 0}}
@keyframes floatIn{from{opacity:0;transform:translateY(12px) scale(.985)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes softGlow{0%,100%{box-shadow:0 0 0 rgba(226,35,26,0)}50%{box-shadow:0 0 28px rgba(226,35,26,.08)}}
#root{animation:floatIn .42s ease both}
.hero-card,.premium-panel{box-shadow:0 18px 50px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.03)}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.001ms!important}}.prestige-status-grid{margin-bottom:2px}.prestige-status-grid button{font-family:inherit;cursor:pointer}@media(max-width:760px){.prestige-status-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:430px){.prestige-status-grid{grid-template-columns:1fr!important}}
</style>
</head>
<body>
<div id="account-root" data-ssr-auth="${member ? "1" : "0"}" data-ssr-admin="${isAdmin ? "1" : "0"}" data-ssr-user-id="${esc(userId)}" data-ssr-username="${esc(username)}">${accountHtml}</div><div id="root"></div>
<script src="/vendor/react.production.min.js"></script><script src="/vendor/react-dom.production.min.js"></script>
<script src="/deploy-updater.js?ts=${Date.now()}"></script><script src="/runtime-resilience.js?v=1"></script><script src="/admin/ui.js?v=530"></script><script src="/translations.js?v=530"></script><script src="/english-only-notice.js?v=1"></script><script src="/social.js?v=3"></script><script>window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__rbxInstallPrompt=e;});window.addEventListener('appinstalled',()=>{window.__rbxInstallPrompt=null;});</script><script src="/notifications-bridge.js?v=2"></script><script src="/push-client.js?v=1"></script><script>window.rbxNotificationSW?.register?.();</script><script src="/account.js?v=530"></script><script src="/app.js?v=531"></script><script src="/asset-sync.js?v=530"></script>
</body></html>`);
}