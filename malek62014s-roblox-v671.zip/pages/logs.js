import { db } from "hatchable";

export const access = "user";

const esc = (s) => String(s ?? "")
  .replace(/&/g, "&amp;")
  .replace(/</g, "&lt;")
  .replace(/>/g, "&gt;")
  .replace(/\"/g, "&quot;")
  .replace(/'/g, "&#39;");

const dateText = (value) => {
  try {
    return new Date(value).toLocaleString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit"
    });
  } catch (_) {
    return "Recent update";
  }
};

export default async function (_req, res) {
  let updates = [];
  try {
    const { rows } = await db.query(
      "SELECT version,title,summary,kind,created_at FROM update_logs ORDER BY created_at DESC,id DESC"
    );
    updates = rows;
  } catch (_) {}

  const cards = updates.length
    ? updates.map((u, i) => `
      <article class="log-card ${i === 0 ? "latest" : ""}">
        <div class="log-top">
          <div class="version">VERSION ${esc(u.version)}</div>
          <div class="type-pill">${esc(u.kind || 'Update')}</div>
          ${i === 0 ? '<div class="badge">LATEST</div>' : ''}
        </div>
        <h2>${esc(u.title)}</h2>
        <p>${esc(u.summary)}</p>
        <div class="date">${esc(dateText(u.created_at))}</div>
      </article>`).join("")
    : '<div class="empty">No updates have been recorded yet.</div>';

  res.setHeader("Cache-Control", "private, no-store, max-age=0");
  res.setHeader("Vary", "Cookie");
  return res.send(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Update Logs · malek62014's Roblox Assets</title>
<meta name="description" content="Site updates and release notes for malek62014's Roblox Assets.">
<style>
:root{--bg:#080a0e;--card:#11161d;--card2:#0d1218;--border:#283240;--muted:#7f8a99;--text:#f4f6f8;--red:#e2231a}*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:var(--bg);color:var(--text);font-family:Segoe UI,Inter,system-ui,-apple-system,Arial,sans-serif}body{min-height:100vh;padding:26px 18px 40px;background:radial-gradient(circle at 50% -10%,rgba(226,35,26,.18),transparent 38%),linear-gradient(180deg,#0b0e13,#07090c 70%)}a{color:inherit}.shell{width:min(900px,100%);margin:0 auto}.nav{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:26px}.brand{font-weight:950;letter-spacing:-.02em}.back{padding:9px 13px;border:1px solid var(--border);border-radius:11px;background:#11171e;text-decoration:none;font-size:12px;font-weight:850}.hero{padding:24px;border:1px solid rgba(226,35,26,.2);border-radius:22px;background:linear-gradient(145deg,#151b23,#0d1218);box-shadow:0 24px 70px rgba(0,0,0,.35)}.eyebrow{font-size:10px;letter-spacing:.16em;font-weight:950;color:#ffaaa4}.title{margin:7px 0 8px;font-size:34px;line-height:1.05;letter-spacing:-1px}.sub{color:#9aa5b4;font-size:13px;line-height:1.6}.logs{display:grid;gap:12px;margin-top:16px}.log-card{padding:20px;border:1px solid var(--border);border-radius:18px;background:linear-gradient(180deg,var(--card),var(--card2));box-shadow:0 14px 36px rgba(0,0,0,.2)}.log-card.latest{border-color:rgba(226,35,26,.4);box-shadow:0 18px 42px rgba(0,0,0,.25),0 0 0 1px rgba(226,35,26,.06)}.log-top{display:flex;align-items:center;gap:8px}.version{font-size:10px;font-weight:950;letter-spacing:.1em;color:#9ca7b5}.type-pill{font-size:8px;font-weight:900;letter-spacing:.06em;padding:4px 7px;border-radius:999px;color:#c9d1db;background:#151c24;border:1px solid #313d4b}.badge{font-size:8px;font-weight:950;letter-spacing:.08em;padding:4px 7px;border-radius:999px;color:#fff;background:linear-gradient(135deg,#e2231a,#9f1712);border:1px solid rgba(255,255,255,.1)}h2{margin:10px 0 7px;font-size:19px;letter-spacing:-.3px}p{margin:0;color:#abb4c0;font-size:12px;line-height:1.65}.date{margin-top:14px;color:#6f7b8a;font-size:10px}.log-card p{white-space:pre-wrap;word-break:break-word}.empty{text-align:center;padding:30px;border:1px dashed #344150;border-radius:16px;color:#7f8a99;background:#0d1218}@media(max-width:640px){body{padding:16px 12px 28px}.hero{padding:18px}.title{font-size:28px}.nav{margin-bottom:18px}}
</style>
</head>
<body>
<main class="shell">
  <div class="nav"><div class="brand">malek62014's Roblox Assets</div><a class="back" href="/">← Back to website</a></div>
  <section class="hero">
    <div class="eyebrow">SITE UPDATE LOG</div>
    <div class="title">What's new</div>
    <div class="sub">A running history of website updates, fixes, and new features. This page is available to signed-in members only.</div>
  </section>
  <section class="logs">${cards}</section>
</main>
</body>
</html>`);
}