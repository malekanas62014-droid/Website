(()=>{
  if(window.__malekRuntimeResilience)return;
  window.__malekRuntimeResilience=true;

  const nativeFetch=window.fetch.bind(window);
  const retryable=(response)=>response&&[502,503,504].includes(response.status);
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  window.fetch=async(...args)=>{
    let response;
    for(let attempt=0;attempt<3;attempt++){
      try{
        response=await nativeFetch(...args);
      }catch(error){
        if(attempt>=2)throw error;
        await sleep(250*(attempt+1));
        continue;
      }
      if(!retryable(response)||attempt>=2)return response;
      await sleep(250*(attempt+1));
    }
    return response;
  };

  const isTransientErrorText=el=>{
    if(!el||el===document.body||el===document.documentElement)return false;
    const text=String(el.textContent||'').trim().toLowerCase();
    return text.includes('isolate runtime is temporarily unavailable')||text.includes('retry shortly');
  };

  const hideSoon=el=>{
    if(!el||el.dataset.malekTransientScheduled)return;
    el.dataset.malekTransientScheduled='1';
    setTimeout(()=>{
      try{
        if(!isTransientErrorText(el))return;
        el.style.transition='opacity .2s ease,transform .2s ease';
        el.style.opacity='0';
        el.style.transform='translateY(-4px)';
        setTimeout(()=>el.remove(),220);
      }catch(_){ }
    },3000);
  };

  const inspect=root=>{
    if(!root||root.nodeType!==1)return;
    if(isTransientErrorText(root))hideSoon(root);
    root.querySelectorAll?.('[role="alert"],[aria-live="assertive"],[aria-live="polite"],button,div,section').forEach(el=>{
      if(isTransientErrorText(el))hideSoon(el);
    });
  };

  const observer=new MutationObserver(mutations=>{
    for(const m of mutations){
      if(m.type==='childList')m.addedNodes.forEach(inspect);
      else if(m.type==='characterData')inspect(m.target.parentElement);
    }
  });
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  inspect(document.body);
})();