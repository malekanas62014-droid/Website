self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>{
  event.waitUntil((async()=>{
    let data={};
    try{data=event.data?event.data.json():{};}catch(_){try{data={body:event.data?.text?.()||''};}catch(__){data={};}}
    const title=String(data.title||"Malek62014's Roblox Assets");
    const body=String(data.body||'');
    const tag=String(data.tag||'malek-notification');
    const url=String(data.url||'/');
    await self.registration.showNotification(title,{body,tag,renotify:false,data:{url}});
  })());
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  event.waitUntil((async()=>{
    const target=new URL(String(event.notification.data?.url||'/'),self.location.origin).href;
    const clientsList=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    for(const client of clientsList){
      if('focus' in client){await client.focus();return;}
    }
    if(self.clients.openWindow)await self.clients.openWindow(target);
  })());
});