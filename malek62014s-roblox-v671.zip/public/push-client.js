(function(){
  const state={ready:false,promise:null};
  const b64ToBytes=s=>{const raw=atob(String(s||'').replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-(String(s||'').length%4))%4));const out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;};
  async function register(){
    if(state.promise)return state.promise;
    state.promise=(async()=>{
      if(!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window))return false;
      const reg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});
      await navigator.serviceWorker.ready;
      if(Notification.permission!=='granted')return false;
      const r=await fetch('/api/account/push-config?ts='+Date.now(),{cache:'no-store',credentials:'include'});
      const d=await r.json().catch(()=>({}));
      if(!r.ok||!d.public_key)return false;
      let sub=await reg.pushManager.getSubscription();
      if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64ToBytes(d.public_key)});
      await fetch('/api/account/push-subscription',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({subscription:sub.toJSON()})});
      state.ready=true;return true;
    })().catch(()=>false).finally(()=>{state.promise=null});
    return state.promise;
  }
  async function remove(){
    try{const reg=await navigator.serviceWorker?.ready;const sub=await reg?.pushManager?.getSubscription();if(sub){await fetch('/api/account/push-subscription',{method:'DELETE',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({endpoint:sub.endpoint})}).catch(()=>{});await sub.unsubscribe().catch(()=>{});}}catch(_){ }
  }
  window.rbxPush={register,remove,isReady:()=>state.ready};
})();