(() => {
  const root = document.getElementById('account-controls');
  if (!root) return;
  async function render() {
    try {
      const s = await window.hatchable?.auth?.getSession?.();
      if (!s?.user) { root.innerHTML = '<button id="account-signin">Sign in</button>'; document.getElementById('account-signin').onclick=()=>window.hatchable.auth.signIn(); return; }
      const u=s.user;
      root.innerHTML=`<span class="account-name">${String(u.email||u.handle||'Account')}</span><button id="account-signout">Sign out</button>`;
      document.getElementById('account-signout').onclick=async()=>{ await window.hatchable.auth.signOut(); location.reload(); };
    } catch(e) { root.innerHTML=''; }
  }
  render();
})();