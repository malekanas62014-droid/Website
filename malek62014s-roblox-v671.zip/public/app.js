const { useState, useEffect, useMemo, useCallback, useRef } = React;

// ---------------------------------------------------------------------------
// UI micro-sounds: tiny synthesized sounds, no external audio files required.
// AudioContext is created only after a real user gesture so browsers allow it.
// ---------------------------------------------------------------------------
(() => {
  let ctx = null;
  let resumePromise = null;
  const getContext = () => {
    try {
      if (ctx && ctx.state !== 'closed') return ctx;
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      ctx = new Ctx();
      return ctx;
    } catch (_) { ctx = null; return null; }
  };
  const ready = () => {
    const c = getContext(); if (!c) return Promise.resolve(null);
    if (c.state === 'running') return Promise.resolve(c);
    if (c.state === 'suspended' && !resumePromise) {
      resumePromise = c.resume().catch(() => null).finally(() => { resumePromise = null; });
    }
    return resumePromise || Promise.resolve(c);
  };
  const tone = (freq, duration, type = 'sine', volume = 0.042, delay = 0) => {
    ready().then(c => {
      if (!c || c.state === 'closed') return;
      try {
        const now = c.currentTime + delay;
        const osc = c.createOscillator();
        const gain = c.createGain();
        osc.type = type; osc.frequency.setValueAtTime(freq, now);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(volume, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
        osc.connect(gain); gain.connect(c.destination);
        osc.start(now); osc.stop(now + duration + 0.02);
      } catch (_) { ctx = null; }
    });
  };
  const click = () => { tone(520, .055, 'sine', .042); };
  const open = () => { tone(430, .06, 'sine', .042); tone(690, .08, 'sine', .030, .035); };
  const success = () => { tone(620, .07, 'sine', .042); tone(880, .11, 'sine', .030, .045); };
  window.rbxUISound = { click, open, success };
  window.showPrestigeTroll = (title, message, buttonText='Got it') => {
    const old=document.getElementById('prestige-troll-notice'); if(old) old.remove();
    const ov=document.createElement('div'); ov.id='prestige-troll-notice';
    ov.style.cssText='position:fixed;inset:0;z-index:12000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.78);backdrop-filter:blur(16px);animation:pnFade .16s ease';
    const card=document.createElement('div'); card.style.cssText='width:min(560px,100%);padding:25px;border-radius:22px;border:1px solid rgba(226,35,26,.28);background:radial-gradient(circle at 100% 0,rgba(226,35,26,.18),transparent 42%),linear-gradient(180deg,#171c24,#0b0f14);box-shadow:0 35px 120px rgba(0,0,0,.8),0 0 75px rgba(226,35,26,.16);animation:pnIn .2s ease';
    const badge=document.createElement('div'); badge.textContent='ACCOUNT NOTICE'; badge.style.cssText='display:inline-flex;align-items:center;padding:6px 9px;margin-top:0;border-radius:999px;background:rgba(226,35,26,.10);border:1px solid rgba(226,35,26,.24);color:#ffaaa4;font-size:9px;font-weight:950;letter-spacing:.10em';
    const h=document.createElement('h3'); h.textContent=title||'Notice'; h.style.cssText='margin:13px 0 9px;font-size:28px;letter-spacing:-.7px;color:#fff';
    const p=document.createElement('p'); p.textContent=message||''; p.style.cssText='margin:0;color:#a4adba;line-height:1.65;font-size:13px;white-space:pre-wrap';
    const btn=document.createElement('button'); btn.type='button'; btn.textContent=String(buttonText||'Got it').slice(0,40); btn.style.cssText='width:100%;margin-top:21px;height:49px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:linear-gradient(135deg,#ff554d,#c91d15);color:#fff;font:inherit;font-weight:950;cursor:pointer;box-shadow:0 12px 28px rgba(226,35,26,.22)';
    card.append(badge,h,p,btn); ov.append(card); document.body.appendChild(ov);
    const close=()=>ov.remove(); btn.onclick=close; ov.onclick=e=>{if(e.target===ov)close()}; ov.onkeydown=e=>{if(e.key==='Escape')close()}; ov.tabIndex=-1; ov.focus();
  };
  window.showPrestigeNotice = (title, message, danger=false, hideBrand=false) => {
    const old=document.getElementById('prestige-notice'); if(old) old.remove();
    const ov=document.createElement('div'); ov.id='prestige-notice';
    ov.style.cssText='position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.72);backdrop-filter:blur(14px);animation:pnFade .16s ease';
    const card=document.createElement('div'); card.style.cssText='width:min(460px,100%);padding:24px;border-radius:22px;border:1px solid rgba(255,255,255,.12);background:radial-gradient(circle at 100% 0,rgba(226,35,26,.15),transparent 38%),linear-gradient(180deg,#171b23,#0b0f14);box-shadow:0 35px 120px rgba(0,0,0,.75),0 0 70px rgba(226,35,26,.13);animation:pnIn .2s ease';
    const icon=document.createElement('div'); icon.textContent=danger?'⚠️':'✦'; icon.style.cssText='width:48px;height:48px;border-radius:15px;display:grid;place-items:center;background:rgba(226,35,26,.11);border:1px solid rgba(226,35,26,.25);font-size:22px';
    const brand=document.createElement('div'); brand.textContent="MALEK62014’S ROBLOX ASSETS"; brand.style.cssText='margin-top:15px;font-size:10px;font-weight:950;letter-spacing:.16em;color:#ff7068'; if(hideBrand) brand.style.display='none';
    const h=document.createElement('h3'); h.textContent=title||'Notice'; h.style.cssText='margin:6px 0 8px;font-size:24px;letter-spacing:-.6px;color:#fff';
    const p=document.createElement('p'); p.textContent=message||''; p.style.cssText='margin:0;color:#9aa5b3;line-height:1.6;font-size:12px;white-space:pre-wrap';
    const btn=document.createElement('button'); btn.type='button'; btn.textContent='Got it'; btn.style.cssText='width:100%;margin-top:20px;height:48px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:linear-gradient(135deg,#ff554d,#c91d15);color:#fff;font:inherit;font-weight:950;cursor:pointer;box-shadow:0 12px 28px rgba(226,35,26,.22)';
    card.append(icon,brand,h,p,btn); ov.append(card); document.body.appendChild(ov);
    const close=()=>ov.remove(); btn.onclick=close; ov.onclick=e=>{if(e.target===ov)close()}; ov.onkeydown=e=>{if(e.key==='Escape')close()}; ov.tabIndex=-1; ov.focus();
  };
  window.showPrestigeConfirm = (title, message) => new Promise(resolve => {
    const old=document.getElementById('prestige-confirm'); if(old) old.remove();
    const ov=document.createElement('div'); ov.id='prestige-confirm';
    ov.style.cssText='position:fixed;inset:0;z-index:10001;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.75);backdrop-filter:blur(15px)';
    const card=document.createElement('div'); card.style.cssText='width:min(460px,100%);padding:24px;border-radius:22px;border:1px solid rgba(255,255,255,.12);background:radial-gradient(circle at 100% 0,rgba(226,35,26,.16),transparent 40%),linear-gradient(180deg,#171b23,#0b0f14);box-shadow:0 35px 120px rgba(0,0,0,.78),0 0 70px rgba(226,35,26,.14)';
    const icon=document.createElement('div'); icon.textContent='🔐'; icon.style.cssText='width:48px;height:48px;border-radius:15px;display:grid;place-items:center;background:rgba(226,35,26,.11);border:1px solid rgba(226,35,26,.25);font-size:22px';
    const brand=document.createElement('div'); brand.textContent="MALEK62014’S ROBLOX ASSETS"; brand.style.cssText='margin-top:15px;font-size:10px;font-weight:950;letter-spacing:.16em;color:#ff7068';
    const h=document.createElement('h3'); h.textContent=title||'Confirm action'; h.style.cssText='margin:6px 0 8px;font-size:24px;letter-spacing:-.6px;color:#fff';
    const p=document.createElement('p'); p.textContent=message||''; p.style.cssText='margin:0;color:#9aa5b3;line-height:1.6;font-size:12px';
    const actions=document.createElement('div'); actions.style.cssText='display:flex;gap:9px;margin-top:20px';
    const cancel=document.createElement('button'); cancel.type='button'; cancel.textContent='Cancel'; cancel.style.cssText='flex:1;height:48px;border-radius:12px;border:1px solid #394656;background:linear-gradient(180deg,#18212c,#10161e);color:#e7ecf2;font:inherit;font-weight:900;cursor:pointer';
    const ok=document.createElement('button'); ok.type='button'; ok.textContent='Remove passkey'; ok.style.cssText='flex:1;height:48px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:linear-gradient(135deg,#ff554d,#c91d15);color:#fff;font:inherit;font-weight:950;cursor:pointer;box-shadow:0 12px 28px rgba(226,35,26,.22)';
    actions.append(cancel,ok); card.append(icon,brand,h,p,actions); ov.append(card); document.body.appendChild(ov);
    const finish=v=>{ov.remove();resolve(v)}; cancel.onclick=()=>finish(false); ok.onclick=()=>finish(true); ov.onclick=e=>{if(e.target===ov)finish(false)}; ov.onkeydown=e=>{if(e.key==='Escape')finish(false)}; ov.tabIndex=-1; ov.focus();
  });
  document.addEventListener('pointerdown', (event) => {
    const el = event.target?.closest?.('button,a');
    if (!el || el.disabled) return;
    if (el.id === 'public-account' || el.classList.contains('account-admin')) open();
    else if (el.id === 'sign-out' || el.id === 'change-username' || el.matches('[data-fold],[data-page]')) click();
    else click();
  }, true);
})();

// ---------------------------------------------------------------------------
// Data: file catalog (placeholder sizes, simulated content for Blob download)
// ---------------------------------------------------------------------------
const FILES = [
  { id: "wall", name: "Wall Gamepass Script.rbxm", category: "scripts", size: "10.1 KB" },
  { id: "boss", name: "BossFight.rbxm", category: "scripts", size: "12.6 KB" },
  { id: "sink", name: "Sink.rbxm", category: "models", size: "8.1 KB" },
  { id: "acv2", name: "AcV2.rbxm", category: "models", size: "12.1 KB" },
  { id: "ac", name: "Ac.rbxm", category: "models", size: "11.3 KB" },
  { id: "flashlight3", name: "FlashLight V3.rbxm", category: "flashlights", size: "10.3 KB" },
  { id: "flashlight2", name: "FlashLight V2.rbxm", category: "flashlights", size: "9.3 KB" },
  { id: "workspace", name: "Workspace deleter (Bug Fixes).rbxm", category: "tools", size: "8.0 KB" },
  { id: "flashlight", name: "FlashLight.rbxm", category: "flashlights", size: "8.2 KB" },
  { id: "traffic", name: "my roblox traffic Light.rbxm", category: "models", size: "5.8 KB" },
];

const CATEGORY_ORDER = ["all", "flashlights", "scripts", "models", "tools", "everything"];

// Visible asset titles are localized; the original .rbx filename remains intact for downloads.
const FILE_DISPLAY_NAMES = {
  ar: {
    f1: "المصباح التكتيكي V2",
    f2: "سكريبت مصباح الوميض",
    f3: "أداة مصباح قابلة للشحن",
    s1: "حارس الحماية من الاستغلال",
    s2: "سكريبت لوحة الصدارة البسيطة",
    s3: "انتقال الكاميرا بالتلاشي",
    m1: "عمود إنارة منخفض التفاصيل",
    m2: "حزمة المستودع المهجور",
    m3: "شبكة مصباح تفصيلية",
    t1: "أداة خطاف التسلق",
    t2: "أداة قتال قريب",
    t3: "أداة وضع المباني",
    e1: "شاشة تحميل مخصصة",
    e2: "نظام دورة الليل والنهار",
    e3: "حزمة المؤثرات الصوتية",
  },
};

const LOCALIZED_FILE_TITLES = {
  en: { wall: "Wall Gamepass Script", boss: "Boss Fight", sink: "Sink", acv2: "Air Conditioner V2", ac: "Air Conditioner", flashlight3: "Flashlight V3", flashlight2: "Flashlight V2", workspace: "Workspace Deleter (Bug Fixes)", flashlight: "Flashlight", traffic: "Roblox Traffic Light" },
  es: { wall: "Script de pase de pared", boss: "Combate de jefe", sink: "Fregadero", acv2: "Aire acondicionado V2", ac: "Aire acondicionado", flashlight3: "Linterna V3", flashlight2: "Linterna V2", workspace: "Eliminador del espacio de trabajo (correcciones)", flashlight: "Linterna", traffic: "Semáforo de Roblox" },
  fr: { wall: "Script de passe pour mur", boss: "Combat de boss", sink: "Évier", acv2: "Climatiseur V2", ac: "Climatiseur", flashlight3: "Lampe torche V3", flashlight2: "Lampe torche V2", workspace: "Suppresseur d’espace de travail (correctifs)", flashlight: "Lampe torche", traffic: "Feu de circulation Roblox" },
  de: { wall: "Wand-Gamepass-Skript", boss: "Bosskampf", sink: "Waschbecken", acv2: "Klimaanlage V2", ac: "Klimaanlage", flashlight3: "Taschenlampe V3", flashlight2: "Taschenlampe V2", workspace: "Arbeitsbereich-Löscher (Fehlerbehebungen)", flashlight: "Taschenlampe", traffic: "Roblox-Ampel" },
  pt: { wall: "Script de passe de parede", boss: "Luta contra chefe", sink: "Pia", acv2: "Ar condicionado V2", ac: "Ar condicionado", flashlight3: "Lanterna V3", flashlight2: "Lanterna V2", workspace: "Removedor do espaço de trabalho (correções)", flashlight: "Lanterna", traffic: "Semáforo do Roblox" },
  ar: { wall: "سكريبت تصريح الجدار", boss: "قتال الزعيم", sink: "مغسلة", acv2: "مكيف هواء V2", ac: "مكيف هواء", flashlight3: "مصباح يدوي V3", flashlight2: "مصباح يدوي V2", workspace: "حاذف مساحة العمل (إصلاحات)", flashlight: "مصباح يدوي", traffic: "إشارة مرور روبلوكس" },
  ja: { wall: "壁ゲームパススクリプト", boss: "ボス戦", sink: "シンク", acv2: "エアコン V2", ac: "エアコン", flashlight3: "懐中電灯 V3", flashlight2: "懐中電灯 V2", workspace: "ワークスペース削除ツール（修正済み）", flashlight: "懐中電灯", traffic: "Roblox 信号機" },
  zh: { wall: "墙体通行证脚本", boss: "首领战斗", sink: "水槽", acv2: "空调 V2", ac: "空调", flashlight3: "手电筒 V3", flashlight2: "手电筒 V2", workspace: "工作区删除工具（错误修复）", flashlight: "手电筒", traffic: "Roblox 交通信号灯" },
  ru: { wall: "Скрипт пропуска через стену", boss: "Битва с боссом", sink: "Раковина", acv2: "Кондиционер V2", ac: "Кондиционер", flashlight3: "Фонарь V3", flashlight2: "Фонарь V2", workspace: "Удалитель рабочего пространства (исправления)", flashlight: "Фонарь", traffic: "Светофор Roblox" },
  tr: { wall: "Duvar oyun geçişi betiği", boss: "Boss savaşı", sink: "Lavabo", acv2: "Klima V2", ac: "Klima", flashlight3: "El feneri V3", flashlight2: "El feneri V2", workspace: "Çalışma alanı silici (hata düzeltmeleri)", flashlight: "El feneri", traffic: "Roblox trafik ışığı" },
  it: { wall: "Script pass muro", boss: "Combattimento boss", sink: "Lavandino", acv2: "Condizionatore d'aria V2", ac: "Condizionatore d'aria", flashlight3: "Torcia V3", flashlight2: "Torcia V2", workspace: "Eliminatore dell’area di lavoro (correzioni)", flashlight: "Torcia", traffic: "Semaforo Roblox" },
};

function displayFileName(file, lang) {
  const code=String(lang||'en').split('-')[0].toLowerCase();
  const legacyId=String(file?.legacy_id || file?.id || '');
  const staticName=LOCALIZED_FILE_TITLES[code]?.[legacyId] || FILE_DISPLAY_NAMES[code]?.[legacyId];
  if(staticName) return staticName;
  const dynamic=window.ASSET_NAME_TRANSLATIONS?.[code]?.[legacyId] || window.ASSET_NAME_TRANSLATIONS?.[code]?.[String(file?.id)];
  const original=String(file?.name || '').trim();
  if(dynamic && dynamic.trim() && dynamic.trim().toLowerCase() !== original.toLowerCase()) return dynamic.trim();
  return original;
}

// ---------------------------------------------------------------------------
// Device detection
// ---------------------------------------------------------------------------
function detectIsMobileOrTablet() {
  // Prefer the browser's device classification so touch-enabled PCs/laptops are not warned.
  if (navigator.userAgentData && typeof navigator.userAgentData.mobile === "boolean") {
    return navigator.userAgentData.mobile;
  }
  const ua = navigator.userAgent || navigator.vendor || "";
  if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|Tablet/i.test(ua)) return true;
  // Modern iPads can identify as macOS; multiple touch points distinguish them from laptops.
  return navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
}

// ---------------------------------------------------------------------------
// Language detection
// ---------------------------------------------------------------------------
function detectLanguage() {
  const supported = window.LANGUAGES.map((l) => l.code);
  const browserLangs = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || "en"];
  for (const bl of browserLangs) {
    const exact = String(bl||'').toLowerCase();
    if (supported.includes(exact)) return window.LANGUAGES.find(l=>l.code===exact)?.code || exact;
    const short = exact.slice(0, 2);
    if (supported.includes(short)) return short;
  }
  return "en";
}

// ---------------------------------------------------------------------------
// Small presentational helpers
// ---------------------------------------------------------------------------
const CATEGORY_COLORS = {
  flashlights: "#f5c518",
  scripts: "#5ac8fa",
  models: "#bf5af2",
  tools: "#34c759",
  everything: "#e2231a",
};

function Spinner() {
  return React.createElement("span", {
    style: {
      display: "inline-block",
      width: 14,
      height: 14,
      border: "2px solid rgba(255,255,255,0.35)",
      borderTopColor: "#fff",
      borderRadius: "50%",
      animation: "spin 0.7s linear infinite",
      marginInlineEnd: 8,
      verticalAlign: "-2px",
    },
  });
}

// ---------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------
function LanguagePicker({ lang, setLang, compact = false }) {
  const base = lang && window.TRANSLATIONS?.[lang] ? lang : (window.getLanguageBase?.(lang) || 'en');
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [locale, setLocale] = useState(() => {
    try { return localStorage.getItem('rbx-assets-locale') || base; } catch (_) { return base; }
  });
  const wrapRef = useRef(null);
  useEffect(() => {
    const onDocClick = e => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, []);
  useEffect(() => {
    const activeBase = window.getLanguageBase?.(locale) || base;
    if (activeBase !== base) {
      setLocale(base);
      try { localStorage.setItem('rbx-assets-locale', base); } catch (_) {}
    }
  }, [base, locale]);
  const selectedLabel = (() => {
    const variants = window.getLanguageVariants?.(locale) || [];
    return variants.find(v => v.code === locale)?.label || window.LANGUAGES.find(l => l.code === base)?.label || 'English';
  })();
  const variants = window.getLanguageVariants?.(base) || [];
  const knownVariantCodes = new Set(Object.values(window.LANGUAGE_VARIANTS || {}).flat().map(v => v.code));
  const filtered = (window.LANGUAGES || []).filter(l => !knownVariantCodes.has(l.code)).filter(l => {
    const q = query.trim().toLowerCase();
    return !q || String(l.label).toLowerCase().includes(q) || String(l.code).toLowerCase().includes(q);
  });
  const choose = (code) => {
    const nextBase = window.getLanguageBase?.(code) || code;
    const firstVariant = (window.getLanguageVariants?.(nextBase) || [])[0]?.code;
    setLang(nextBase);
    const nextLocale = firstVariant || nextBase;
    setLocale(nextLocale);
    try { localStorage.setItem('rbx-assets-locale', nextLocale); } catch (_) {}
    setOpen(false); setQuery('');
  };
  const chooseVariant = (e) => {
    const next = e.target.value || base;
    setLocale(next);
    try { localStorage.setItem('rbx-assets-locale', next); } catch (_) {}
  };
  return React.createElement('div', { ref: wrapRef, style:{position:'relative'} },
    React.createElement('button', { type:'button', onClick:()=>setOpen(o=>!o), style:{background:'var(--bg-elev)',border:'1px solid var(--border)',color:'var(--white)',borderRadius:8,padding:compact?'7px 10px':'9px 12px',fontSize:compact?11:13,display:'flex',alignItems:'center',gap:6,whiteSpace:'nowrap'} }, '🌐 ', selectedLabel, React.createElement('span',{style:{fontSize:10,opacity:.7}},'▾')),
    open && React.createElement('div',{style:{position:'absolute',insetInlineEnd:0,marginTop:6,zIndex:80,background:'var(--bg-elev-2)',border:'1px solid var(--border)',borderRadius:12,boxShadow:'0 16px 38px rgba(0,0,0,.5)',width:compact?270:300,padding:8}},
      React.createElement('input',{value:query,onChange:e=>setQuery(e.target.value),autoFocus:true,placeholder:'Search languages…',style:{width:'100%',boxSizing:'border-box',background:'var(--bg)',border:'1px solid var(--border)',color:'var(--white)',borderRadius:8,padding:'9px 10px',fontSize:12,outline:'none',marginBottom:8}}),
      React.createElement('div',{style:{maxHeight:230,overflowY:'auto'}},filtered.map(l=>React.createElement('button',{type:'button',key:l.code,onClick:()=>choose(l.code),style:{display:'block',width:'100%',textAlign:'start',background:(l.code===base?'rgba(226,35,26,.15)':'transparent'),color:'var(--white)',border:'none',borderBottom:'1px solid var(--border)',padding:'9px 10px',fontSize:12,cursor:'pointer'}},l.label))),
      variants.length>0 && React.createElement('div',{style:{marginTop:8,paddingTop:8,borderTop:'1px solid var(--border)'}},
        React.createElement('div',{style:{fontSize:10,fontWeight:900,color:'var(--muted)',marginBottom:5}},'Accent / region'),
        React.createElement('select',{value:variants.some(v=>v.code===locale)?locale:variants[0].code,onChange:chooseVariant,style:{width:'100%',background:'var(--bg)',border:'1px solid var(--border)',color:'var(--white)',borderRadius:8,padding:'8px 9px',fontSize:11}},variants.map(v=>React.createElement('option',{key:v.code,value:v.code},v.label)))
      )
    )
  );
}

function Header({ t, lang, setLang, search, setSearch }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    function onDocClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  const currentLabel = (() => {
    try {
      const locale = localStorage.getItem('rbx-assets-locale') || lang;
      return (window.getLanguageVariants?.(lang)||[]).find(v=>v.code===locale)?.label || window.LANGUAGES.find(l=>l.code===lang)?.label || 'English';
    } catch (_) { return window.LANGUAGES.find(l=>l.code===lang)?.label || 'English'; }
  })();

  return React.createElement(
    "header",
    {
      style: {
        position: "sticky",
        top: 0,
        zIndex: 40,
        background: "rgba(11,13,16,0.9)",
        backdropFilter: "blur(10px)",
        borderBottom: "1px solid var(--border)",
        animation: "slideDown 0.5s ease",
      },
    },
    React.createElement(
      "div",
      {
        style: {
          maxWidth: 1200,
          margin: "0 auto",
          padding: "14px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 16,
          flexWrap: "wrap",
        },
      },
      React.createElement(
        "div",
        { style: { display: "flex", alignItems: "center", gap: 12, minWidth: 0 } },
        React.createElement(
          "div",
          {
            style: {
              width: 38,
              height: 38,
              borderRadius: 10,
              background: "linear-gradient(135deg, var(--red), #7a0f0a)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 800,
              fontSize: 18,
              flexShrink: 0,
              boxShadow: "0 4px 14px rgba(226,35,26,0.35)",
            },
          },
          "R"
        ),
        React.createElement(
          "div",
          { style: { minWidth: 0, display: "flex", alignItems: "center", gap: 9 } },
          React.createElement(
            "div",
            {
              style: {
                minWidth: 0,
                padding: "7px 10px 8px",
                borderRadius: 13,
                border: "1px solid rgba(255,255,255,.10)",
                background: "linear-gradient(145deg,rgba(255,255,255,.07),rgba(255,255,255,.025))",
                boxShadow: "0 8px 24px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.06)",
              },
            },
            React.createElement(
              "div",
              {
                style: {
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                  minWidth: 0,
                },
              },
              React.createElement("span", { style:{width:7,height:7,flex:"0 0 7px",borderRadius:"50%",background:"#38d878",boxShadow:"0 0 14px rgba(56,216,120,.62)"} }),
              React.createElement(
                "div",
                {
                  style: {
                    fontWeight: 950,
                    fontSize: 15,
                    letterSpacing: -0.25,
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    color: "#fff",
                  },
                },
                t.siteName
              )
            ),
            React.createElement(
              "div",
              {
                className: "rbx-hide-mobile",
                style: { fontSize: 10, color: "#7f8b9a", whiteSpace: "nowrap", marginTop: 2, letterSpacing: ".05em", textTransform:"uppercase" },
              },
              "OFFICIAL ASSET VAULT"
            )
          )
        )
      ),
      React.createElement(
        "div",
        { style: { display: "flex", alignItems: "center", gap: 12, flex: "1 1 320px", justifyContent: "flex-end" } },
        React.createElement("input", {
          value: search,
          onChange: (e) => setSearch(e.target.value),
          placeholder: t.searchPlaceholder,
          style: {
            background: "var(--bg-elev)",
            border: "1px solid var(--border)",
            color: "var(--white)",
            borderRadius: 8,
            padding: "9px 12px",
            fontSize: 13,
            outline: "none",
            width: "100%",
            maxWidth: 220,
            transition: "border-color 0.2s",
          },
          onFocus: (e) => (e.target.style.borderColor = "var(--red)"),
          onBlur: (e) => (e.target.style.borderColor = "var(--border)"),
        }),
        null
      )
    )
  );
}

// ---------------------------------------------------------------------------
// Mobile warning banner
// ---------------------------------------------------------------------------
function MobileBanner({ t, onDismiss }) {
  return React.createElement(
    "div",
    {
      style: {
        position: "relative",
        overflow: "hidden",
        margin: "10px 12px 0",
        border: "1px solid rgba(255,82,72,.28)",
        borderRadius: 18,
        background: "radial-gradient(circle at 0% 50%,rgba(255,72,61,.16),transparent 38%),linear-gradient(145deg,rgba(255,72,61,.10),rgba(255,255,255,.025))",
        boxShadow: "0 14px 35px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.04)",
        color: "#fff",
        padding: "14px 14px 14px 16px",
        display: "flex",
        alignItems: "center",
        gap: 12,
        animation: "slideDown 0.4s ease",
      },
    },
    React.createElement("div", { style:{width:38,height:38,borderRadius:12,display:"grid",placeItems:"center",flex:"0 0 38px",background:"linear-gradient(145deg,#ff5148,#a81812)",border:"1px solid rgba(255,255,255,.12)",boxShadow:"0 10px 24px rgba(226,35,26,.22)",fontSize:18} }, "⚠️"),
    React.createElement(
      "div",
      { style:{minWidth:0,flex:1} },
      React.createElement("div", { style:{fontSize:10,fontWeight:950,letterSpacing:".14em",textTransform:"uppercase",color:"#ff918b"} }, "MOBILE / TABLET"),
      React.createElement("div", { style:{marginTop:3,fontSize:12.5,lineHeight:1.5,color:"#d8dde5"} }, t.mobileWarningBanner)
    ),
    React.createElement(
      "button",
      {
        onClick: onDismiss,
        "aria-label": t.dismiss,
        style: {
          width: 34,
          height: 34,
          borderRadius: 10,
          background: "rgba(255,255,255,.06)",
          border: "1px solid rgba(255,255,255,.12)",
          color: "#fff",
          padding: 0,
          fontSize: 18,
          flexShrink: 0,
        },
      },
      "×"
    )
  );
}

// ---------------------------------------------------------------------------
// Category tabs
// ---------------------------------------------------------------------------
function CategoryTabs({ t, active, setActive, counts, categories }) {
  const labelFor = (c) =>
    c === "all"
      ? t.categoryAll
      : c === "flashlights"
      ? t.categoryFlashlights
      : c === "scripts"
      ? t.categoryScripts
      : c === "models"
      ? t.categoryModels
      : c === "tools"
      ? t.categoryTools
      : c === "everything"
      ? t.categoryEverything
      : c === "favorites"
      ? "Favorites"
      : c.replace(/-/g, " ").replace(/\b\w/g, m => m.toUpperCase());

  return React.createElement(
    "div",
    {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "nowrap",
        overflowX: "auto",
        overflowY: "hidden",
        padding: "16px 20px 7px",
        maxWidth: 1200,
        margin: "0 auto",
        scrollbarWidth: "none",
        WebkitOverflowScrolling: "touch",
      },
    },
    (categories || CATEGORY_ORDER).map((c) =>
      React.createElement(
        "button",
        {
          key: c,
          onClick: () => setActive(c),
          style: {
            background: active === c ? "var(--red)" : "var(--bg-elev)",
            border: `1px solid ${active === c ? "var(--red)" : "var(--border)"}`,
            color: "#fff",
            borderRadius: 999,
            padding: "8px 13px",
            fontSize: 12.5,
            fontWeight: active === c ? 750 : 600,
            whiteSpace: "nowrap",
            flexShrink: 0,
            transition: "all 0.2s ease",
            display: "flex",
            alignItems: "center",
            gap: 6,
          },
        },
        labelFor(c),
        React.createElement(
          "span",
          {
            style: {
              background: active === c ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.08)",
              borderRadius: 999,
              padding: "1px 7px",
              fontSize: 11,
            },
          },
          counts[c] ?? 0
        )
      )
    )
  );
}

// ---------------------------------------------------------------------------
// File card
// ---------------------------------------------------------------------------
function FileCard({ t, lang, file, onDownload, downloadingId, account, purchased, onPurchase, categoryLabels, favorite, onToggleFavorite }) {
  const isDownloading = downloadingId === file.id;
  const isPremium = !!file.premium;
  const price = Math.max(0, Number(isPremium ? (file.premium_price ?? 0) : (file.basic_price ?? 0)));
  const isPaid = price > 0;
  const isPurchased = purchased?.has(String(file.id));
  const isDisabled = !!file.disabled;
  const displayName = displayFileName(file, lang);
  const [hover, setHover] = useState(false);
  const [nameFontSize, setNameFontSize] = useState(14.5);
  const nameRef = React.useRef(null);
  React.useEffect(() => {
    const el = nameRef.current;
    if (!el) return;
    const fit = () => {
      const max = 14.5;
      const min = 8.5;
      const available = el.parentElement?.clientWidth || el.clientWidth || 1;
      el.style.fontSize = max + "px";
      const natural = el.scrollWidth || 1;
      const next = Math.max(min, Math.min(max, max * Math.min(1, available / natural)));
      setNameFontSize(Number(next.toFixed(2)));
    };
    fit();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    ro?.observe(el.parentElement || el);
    window.addEventListener("resize", fit);
    return () => { ro?.disconnect(); window.removeEventListener("resize", fit); };
  }, [displayName]);
  const catLabel =
    file.category === "flashlights"
      ? t.categoryFlashlights
      : file.category === "scripts"
      ? t.categoryScripts
      : file.category === "models"
      ? t.categoryModels
      : file.category === "tools"
      ? t.categoryTools
      : String(file.category || t.categoryEverything).split(',').map(v => { const slug = String(v).trim().toLowerCase(); return categoryLabels?.[slug] || slug.replace(/-/g, " ").replace(/\b\w/g, m => m.toUpperCase()); }).filter(Boolean).join(', ');

  return React.createElement(
    "div",
    {
      className: "asset-card",
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        background: "var(--bg-elev)",
        border: `1px solid ${hover ? "rgba(226,35,26,0.5)" : "var(--border)"}`,
        borderRadius: 14,
        padding: 18,
        display: "flex",
        flexDirection: "column",
        gap: 12,
        transition: "transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease",
        transform: hover ? "translateY(-3px)" : "translateY(0)",
        boxShadow: hover ? "0 12px 28px rgba(0,0,0,0.4)" : "0 0 0 rgba(0,0,0,0)",
        animation: "slideUp 0.4s ease",
      },
    },
    React.createElement(
      "div",
      { style: { display: "flex", flexDirection: "column", gap: 8, minWidth: 0 } },
      React.createElement(
        "div",
        { style: { flex: "1 1 auto", minWidth: 0, width: "100%", display: "flex", flexDirection: "column", gap: 5 } },
        React.createElement(
          "div",
          {
            title: displayName,
            ref: nameRef,
            style: {
              minWidth: 0,
              width: "100%",
              maxWidth: "100%",
              minHeight: 17,
              fontWeight: 700,
              fontSize: nameFontSize,
              lineHeight: 1.15,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "clip",
              wordBreak: "normal",
              letterSpacing: "0",
              transition: "font-size 0.12s ease",
            },
          },
          displayName
        ),
        file.description ? React.createElement("div", { style: { color: "var(--muted)", fontSize: 12, lineHeight: 1.45, overflowWrap: "anywhere" } }, file.description) : null
      ),
      React.createElement(
        "div",
        { style: { display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "space-between", alignItems: "center", width: "100%", flexShrink: 0, maxWidth: "100%" } },
        React.createElement("button", { type:"button", title: favorite ? "Remove from favorites" : "Add to favorites", onClick:(e)=>{e.stopPropagation();onToggleFavorite?.(file.id)}, style:{width:31,height:31,minWidth:31,padding:0,margin:0,borderRadius:9,border:"1px solid rgba(255,255,255,.08)",background:favorite?"rgba(226,35,26,.16)":"rgba(255,255,255,.035)",color:favorite?"#ff746c":"#8f99a8",display:"grid",placeItems:"center",fontSize:14,boxShadow:"none",flexShrink:0,order:2,marginLeft:"auto",position:"relative",zIndex:2,overflow:"hidden"}}, favorite ? "♥" : "♡"),
        React.createElement(
          "span",
          {
            style: {
              fontSize: 10.5,
              fontWeight: 700,
              padding: "4px 8px",
              borderRadius: 999,
              whiteSpace: "nowrap",
              flexShrink: 0,
              maxWidth: "calc(100% - 43px)",
              overflow: "hidden",
              textOverflow: "clip",
              order: 1,
              color: "#0b0d10",
              background: CATEGORY_COLORS[file.category] || "#e2231a",
            },
          },
          catLabel
        ),
        file.has_scripts && React.createElement(
          "span",
          {
            style: {
              fontSize: 10.5,
              fontWeight: 700,
              padding: "4px 8px",
              borderRadius: 999,
              whiteSpace: "nowrap",
              flexShrink: 0,
              maxWidth: "calc(100% - 43px)",
              overflow: "hidden",
              textOverflow: "clip",
              order: 1,
              color: "#0b0d10",
              background: "#bf5af2",
            },
          },
          t.hasScripts || "Has scripts"
        )
      )
    ),
    React.createElement(
      "div",
      { style: { fontSize: 12.5, color: "var(--muted)" } },
      `${t.fileSizeLabel}: ${file.size}`
    ),
    isDisabled && React.createElement(
      "div",
      { style: { background: "rgba(255,69,58,0.10)", border: "1px solid rgba(255,69,58,0.3)", borderRadius: 8, padding: "9px 10px", color: "#ffb4ae", fontSize: 12 } },
      "Disabled",
      file.disabled_reason ? ` — ${file.disabled_reason}` : ""
    ),
    React.createElement(
      "button",
      {
        onClick: () => {
          if (isDisabled) return;
          if (isPremium && !account?.premium_access) {
            if (!account) window.location.href = "/login?next=/";
            else window.showPrestigeNotice?.('Premium access required', 'Unlock Premium above first to download this asset.');
            return;
          }
          if (isPaid && !isPurchased) return onPurchase(file);
          onDownload(file);
        },
        disabled: isDownloading || isDisabled,
        title: isPremium && !account?.premium_access ? (account ? "Premium access required" : "Sign in for Premium") : isPaid && !isPurchased ? (account ? `Buy for ${price} Coins` : "Sign in to buy") : "Download",
        style: {
          marginTop: "auto",
          background: isDisabled ? "#5a2020" : isDownloading ? "#7a0f0a" : "var(--red)",
          color: "#fff",
          border: "none",
          borderRadius: 9,
          padding: "10px 14px",
          fontSize: 13.5,
          fontWeight: 700,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: isDownloading ? 0.85 : 1,
          transition: "background 0.2s ease, transform 0.1s ease",
        },
        onMouseDown: (e) => (e.currentTarget.style.transform = "scale(0.97)"),
        onMouseUp: (e) => (e.currentTarget.style.transform = "scale(1)"),
      },
      isDisabled ? "⛔ " : isDownloading ? React.createElement(Spinner) : isPremium && !account?.premium_access ? "🔒 " : isPaid && !isPurchased ? "🪙 " : "⬇ ",
      isDisabled ? "Disabled" : isDownloading ? t.downloading : isPremium && !account?.premium_access ? (account ? "Premium required" : "Sign in for Premium") : isPaid && !isPurchased ? (account ? `Buy for ${price} Coins` : "Sign in to buy") : t.downloadBtn
    )
  );
}

// ---------------------------------------------------------------------------
// Premium Coins access
// ---------------------------------------------------------------------------
const PREMIUM_FILES = [
  { id: "gamble", name: "GambleGui.rbxm" },
  { id: "door", name: "DoorWithLock.rbxm" },
  { id: "gui", name: "GuiPart.rbxm" },
  { id: "run", name: "RunScript.rbxm" },
  { id: "settings", name: "SettingsGui.rbxm" },
  { id: "shop", name: "ShopGui.rbxm" },
];
const PREMIUM_NAME_TRANSLATIONS = {
  en:{gamble:"Gamble GUI",door:"Door With Lock",gui:"GUI Part",run:"Run Script",settings:"Settings GUI",shop:"Shop GUI"},
  es:{gamble:"Interfaz de apuesta",door:"Puerta con cerradura",gui:"Parte de interfaz",run:"Ejecutar script",settings:"Interfaz de ajustes",shop:"Interfaz de tienda"},
  fr:{gamble:"Interface de pari",door:"Porte avec serrure",gui:"Élément d’interface",run:"Exécuter le script",settings:"Interface des paramètres",shop:"Interface de boutique"},
  de:{gamble:"Glücksspiel-GUI",door:"Tür mit Schloss",gui:"GUI-Teil",run:"Skript ausführen",settings:"Einstellungs-GUI",shop:"Shop-GUI"},
  pt:{gamble:"Interface de aposta",door:"Porta com fechadura",gui:"Parte da interface",run:"Executar script",settings:"Interface de configurações",shop:"Interface da loja"},
  ar:{gamble:"واجهة المقامرة",door:"باب بقفل",gui:"جزء واجهة",run:"تشغيل السكربت",settings:"واجهة الإعدادات",shop:"واجهة المتجر"},
  ja:{gamble:"ギャンブルGUI",door:"鍵付きドア",gui:"GUIパーツ",run:"スクリプト実行",settings:"設定GUI",shop:"ショップGUI"},
  zh:{gamble:"赌博界面",door:"带锁的门",gui:"界面部件",run:"运行脚本",settings:"设置界面",shop:"商店界面"},
  ru:{gamble:"Интерфейс азартной игры",door:"Дверь с замком",gui:"Элемент интерфейса",run:"Запустить скрипт",settings:"Интерфейс настроек",shop:"Интерфейс магазина"},
  tr:{gamble:"Kumar Arayüzü",door:"Kilitli Kapı",gui:"Arayüz Parçası",run:"Komut Dosyasını Çalıştır",settings:"Ayarlar Arayüzü",shop:"Mağaza Arayüzü"},
  it:{gamble:"Interfaccia scommesse",door:"Porta con serratura",gui:"Parte interfaccia",run:"Esegui script",settings:"Interfaccia impostazioni",shop:"Interfaccia negozio"}
};

function PremiumPanel({ account, accountLoading, unlocking, onLogin, onUnlock, onClaimWeekly, claimingWeekly, managedAssets }) {
  const unlocked = !!account?.premium_access;
  const coins = Number(account?.coins ?? 0);
  const missing = Math.max(0, 70 - coins);
  const currentLang = document.documentElement.lang || 'en';
  const ui = (key, fallback) => window.uiText?.(currentLang, key, fallback) || fallback;
  const premiumName = (file) => displayFileName(file, currentLang);
  const statusByName = new Map((managedAssets || []).map((a) => [String(a.name || '').toLowerCase(), a]));
  const premiumStatus = (file) => statusByName.get(String(file.name || '').toLowerCase()) || (managedAssets || []).find((a) => String(a.legacy_id || '') === String(file.id));
  const getDisabled = (file) => { const a = premiumStatus(file); return { disabled: !!a?.disabled, reason: a?.disabled_reason || "Disabled by the owner." }; };
  const managedByLegacy = new Map((managedAssets || []).filter((a) => a.legacy_id).map((a) => [String(a.legacy_id), a]));
  const premiumFiles = [
    ...PREMIUM_FILES.map((p) => { const m = managedByLegacy.get(String(p.id)); return m ? { ...p, ...m, id: p.id, category: m.category, category_name: m.category_name } : p; }),
    ...(managedAssets || []).filter((a) => a && a.premium && !a.removed && !a.legacy_id).map((a) => ({ ...a, id: `managed-${a.id}` })).filter((a) => !PREMIUM_FILES.some((p) => String(p.name).toLowerCase() === String(a.name).toLowerCase()))
  ];
  const unlockButton = !accountLoading && !account ? React.createElement("button", { onClick: onLogin, style: { background:"var(--red)", color:"#fff", border:0, borderRadius:12, padding:"11px 15px", fontWeight:850, boxShadow:"0 10px 28px rgba(226,35,26,.22)" } }, "↪ " + ui("SignInEarn", "Sign in to earn Coins"))
    : !accountLoading && account && !unlocked ? React.createElement("button", { onClick:onUnlock, disabled:unlocking || coins<70, title:coins<70 ? ui("NeedMoreCoins", "You need " + missing + " more Coins.") : "", style:{ background:coins>=70?"#f5c518":"#5a4a16", color:"#111", border:0, borderRadius:12, padding:"11px 15px", fontWeight:900, opacity:unlocking?.72:1 } }, unlocking?"Unlocking…":coins>=70?"★ Unlock Premium · 70 Coins":"Need " + missing + " more Coins") : null;
  return React.createElement("section", { style:{ maxWidth:1200, width:"100%", margin:"22px auto 0", padding:"0 20px" } },
    React.createElement("div", { style:{ position:"relative", overflow:"hidden", borderRadius:22, border:"1px solid " + (unlocked?"rgba(52,199,89,.38)":"rgba(245,197,24,.30)"), background:unlocked?"linear-gradient(135deg,rgba(52,199,89,.14),rgba(18,28,23,.88))":"linear-gradient(135deg,rgba(245,197,24,.14),rgba(24,20,12,.90))", boxShadow:"0 24px 70px rgba(0,0,0,.22)", padding:22, animation:"slideUp .45s ease" } },
      React.createElement("div", { style:{ position:"absolute", width:180, height:180, right:-45, top:-70, borderRadius:"50%", background:unlocked?"rgba(52,199,89,.10)":"rgba(245,197,24,.10)", filter:"blur(4px)" } }),
      React.createElement("div", { style:{ position:"relative", display:"flex", justifyContent:"space-between", gap:18, flexWrap:"wrap", alignItems:"stretch" } },
        React.createElement("div", { style:{ minWidth:240, flex:"1 1 340px" } },
          React.createElement("div", { style:{ display:"inline-flex", alignItems:"center", gap:8, padding:"6px 9px", borderRadius:999, background:"rgba(255,255,255,.06)", border:"1px solid rgba(255,255,255,.08)", fontSize:11, fontWeight:850, letterSpacing:".06em", textTransform:"uppercase" } }, unlocked?"✓ Premium Active":"★ Premium Access"),
          React.createElement("h2", { style:{ margin:"12px 0 5px", fontSize:27, letterSpacing:"-.6px" } }, unlocked?ui("PremiumUnlocked","Premium unlocked!"):ui("Premium","Premium assets")),
          React.createElement("p", { style:{ margin:0, color:"var(--muted)", lineHeight:1.55, maxWidth:620 } }, unlocked?ui("PremiumReady","Your premium Roblox assets are ready to download."):ui("UnlockAll","Unlock all premium assets once for 70 Coins. Your unlock stays permanent.")),
          React.createElement("div", { style:{ display:"flex", gap:9, flexWrap:"wrap", marginTop:15, alignItems:"center" } }, unlockButton, unlocked&&React.createElement("span", { style:{ color:"#6de0a5", fontSize:12, fontWeight:850 } }, "✓ Unlocked forever"))
        ),
        React.createElement("div", { style:{ width:"min(300px,100%)", minWidth:240, padding:16, borderRadius:17, background:"linear-gradient(145deg,rgba(245,197,24,.13),rgba(20,18,12,.9))", border:"1px solid rgba(245,197,24,.24)", boxShadow:"inset 0 1px 0 rgba(255,255,255,.05),0 14px 35px rgba(0,0,0,.2)" } },
          React.createElement("div", { style:{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:10 } },
            React.createElement("div", null, React.createElement("div", { style:{ fontSize:10, fontWeight:950, letterSpacing:".12em", textTransform:"uppercase", color:"#f5d45b" } }, "WEEKLY REWARD"), React.createElement("div", { style:{ marginTop:4, fontSize:18, fontWeight:950 } }, "+5 Coins")),
            React.createElement("div", { style:{ width:38, height:38, display:"grid", placeItems:"center", borderRadius:12, background:"rgba(245,197,24,.12)", border:"1px solid rgba(245,197,24,.2)", fontSize:19 } }, "🪙")
          ),
          React.createElement("div", { style:{ marginTop:8, color:"#9e9a87", fontSize:11, lineHeight:1.45 } }, account ? (account.weekly_claimed ? "Your weekly Coins are already claimed. Come back next week." : "Claim your weekly Coins from this panel. Premium is not required.") : "Sign in to claim your weekly Coins. Premium is not required."),
          React.createElement("button", { type:"button", onClick:account?onClaimWeekly:onLogin, disabled:account?!!account.weekly_claimed||!!claimingWeekly:false, style:{ width:"100%", marginTop:12, padding:"11px 13px", borderRadius:11, border:"1px solid rgba(255,255,255,.12)", background:account?.weekly_claimed?"linear-gradient(180deg,#31352b,#23271f)":"linear-gradient(135deg,#f5c518,#dcae08)", color:account?.weekly_claimed?"#939987":"#17130a", fontWeight:950, boxShadow:account?.weekly_claimed?"none":"0 10px 24px rgba(245,197,24,.2)" } }, account?.weekly_claimed ? "✓ Claimed this week" : claimingWeekly ? "Claiming…" : account ? "🎁 Claim 5 Coins" : "↪ Sign in to claim")
        )
      ),
      React.createElement("div", { style:{ marginTop:20, display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, flexWrap:"wrap" } },
        React.createElement("div", null,React.createElement("div",{style:{fontWeight:900,fontSize:15}},"Premium library"),React.createElement("div",{style:{color:"var(--muted)",fontSize:11,marginTop:3}},premiumFiles.length+" assets · categories shown per asset")),
        React.createElement("span", { style:{ fontSize:11, color:unlocked?"#6de0a5":"#aeb7c4", fontWeight:800, padding:"6px 9px", borderRadius:999, background:"rgba(255,255,255,.04)", border:"1px solid rgba(255,255,255,.07)" } }, unlocked?"Ready to download":"Locked until Premium is unlocked")
      ),
      React.createElement("div", { style:{ marginTop:11, display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(205px,1fr))", gap:11 } }, premiumFiles.map((file)=>{ const status=getDisabled(file); const disabled=status.disabled; const managed=String(file.id).startsWith("managed-"); const cats=String(file.category_name||file.category||"Everything").split(",").map(v=>v.trim()).filter(Boolean); return React.createElement("div",{key:file.id,style:{padding:13,borderRadius:15,border:"1px solid "+(disabled?"rgba(255,69,58,.2)":"rgba(255,255,255,.08)"),background:"linear-gradient(180deg,rgba(255,255,255,.045),rgba(255,255,255,.018))",display:"flex",flexDirection:"column",gap:8,minHeight:145}},React.createElement("div",{style:{display:"flex",justifyContent:"space-between",gap:8,alignItems:"start"}},React.createElement("strong",{style:{fontSize:13,lineHeight:1.3,wordBreak:"break-word"}},!unlocked?"🔒 ":disabled?"⛔ ":"◆ ",premiumName(file)),React.createElement("span",{style:{fontSize:10,fontWeight:850,color:disabled?"#ffaaa4":"#9da7b5"}},disabled?"Disabled":unlocked?"Available":"Locked")),React.createElement("div",{style:{display:"flex",gap:5,flexWrap:"wrap"}},cats.map((c,i)=>React.createElement("span",{key:i,style:{fontSize:10,padding:"4px 7px",borderRadius:999,background:"rgba(255,255,255,.045)",border:"1px solid rgba(255,255,255,.07)",color:"#aeb7c4"}},c))),unlocked&&disabled&&React.createElement("div",{style:{fontSize:11,color:"#ffb0aa",lineHeight:1.4}},status.reason),unlocked&&!disabled&&React.createElement("button",{onClick:()=>{if(detectIsMobileOrTablet())window.dispatchEvent(new CustomEvent("rbx-mobile-download-warning",{detail:{file}}));else{const url=managed?"/api/assets/download?id="+encodeURIComponent(String(file.id).slice(8)):"/api/premium/download/"+encodeURIComponent(file.id);window.open(url,"_blank","noopener");window.dispatchEvent(new CustomEvent("rbx-download-success",{detail:{file}}));}},style:{marginTop:"auto",alignSelf:"flex-start",background:"var(--success)",color:"#06140a",border:0,borderRadius:9,padding:"7px 10px",fontWeight:900,fontSize:11}},"↓ "+ui("Download","Download"))) }))
    )
  );
}

// ---------------------------------------------------------------------------
// Risk modal (mobile/tablet)
// ---------------------------------------------------------------------------
function RiskModal({ t, lang, file, onCancel, onProceed }) {
  const displayName = file ? displayFileName(file, lang) : "";
  const choices = {
    en: ["No", "Yes"], es: ["No", "Sí"], fr: ["Non", "Oui"], de: ["Nein", "Ja"],
    pt: ["Não", "Sim"], ar: ["لا", "نعم"], ja: ["いいえ", "はい"], zh: ["否", "是"],
    ru: ["Нет", "Да"], tr: ["Hayır", "Evet"], it: ["No", "Sì"],
  }[lang] || ["No", "Yes"];
  return React.createElement(
    "div",
    {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 100,
        padding: 14,
        backdropFilter: "blur(18px)",
        WebkitBackdropFilter: "blur(18px)",
        animation: "fadeIn 0.22s ease",
      },
      onClick: onCancel,
    },
    React.createElement(
      "div",
      {
        onClick: (e) => e.stopPropagation(),
        style: {
          position: "relative",
          overflow: "hidden",
          background: "radial-gradient(circle at 100% 0%,rgba(226,35,26,.15),transparent 35%),linear-gradient(180deg,#171c24,#0b1016)",
          border: "1px solid rgba(255,255,255,.11)",
          borderRadius: 24,
          padding: 20,
          maxWidth: 470,
          width: "100%",
          maxHeight: "calc(100vh - 28px)",
          overflowY: "auto",
          animation: "scaleIn 0.25s cubic-bezier(.2,.8,.2,1)",
          boxShadow: "0 35px 110px rgba(0,0,0,.72),0 0 0 1px rgba(226,35,26,.04)",
        },
      },
      React.createElement("div", { style:{display:"flex",alignItems:"center",gap:12,marginBottom:16} },
        React.createElement("div", { style:{width:48,height:48,borderRadius:15,display:"grid",placeItems:"center",flex:"0 0 48px",fontSize:23,background:"linear-gradient(145deg,#ff5047,#8f1712)",border:"1px solid rgba(255,255,255,.12)",boxShadow:"0 12px 28px rgba(226,35,26,.24)"} }, "⚠️"),
        React.createElement("div", null,
          React.createElement("div", { style:{fontSize:9,fontWeight:950,letterSpacing:".16em",textTransform:"uppercase",color:"#ff8f88"} }, "DEVICE COMPATIBILITY"),
          React.createElement("div", { style:{fontSize:20,fontWeight:950,lineHeight:1.12,marginTop:3,letterSpacing:"-.4px"} }, t.modalTitleRisk)
        )
      ),
      React.createElement("div", { style:{fontSize:13,color:"#aeb7c4",lineHeight:1.65,marginBottom:14} }, t.modalBodyRisk),
      React.createElement("div", { style:{display:"flex",gap:8,alignItems:"center",padding:"10px 11px",borderRadius:13,background:"rgba(255,255,255,.035)",border:"1px solid rgba(255,255,255,.08)",marginBottom:14} },
        React.createElement("span", { style:{fontSize:16} }, "📱"),
        React.createElement("div", { style:{minWidth:0} },
          React.createElement("div", { style:{fontSize:10,fontWeight:900,color:"#dfe5ec"} }, "CURRENT DEVICE"),
          React.createElement("div", { style:{fontSize:11,color:"#7f8b9a",marginTop:2} }, "Mobile or tablet · Roblox Studio is unavailable here")
        )
      ),
      file &&
        React.createElement(
          "div",
          {
            style: {
              fontSize: 12,
              background: "linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.02))",
              border: "1px solid rgba(255,255,255,.09)",
              borderRadius: 14,
              padding: "11px 12px",
              marginBottom: 18,
              wordBreak: "break-word",
              color: "#e6ebf1",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,.035)",
            },
          },
          "📄 ",
          displayName
        ),
      React.createElement(
        "div",
        { style: { display: "flex", gap: 10, flexWrap: "wrap" } },
        React.createElement(
          "button",
          {
            onClick: onCancel,
            style: {
              flex: 1,
              background: "transparent",
              border: "1px solid var(--border)",
              color: "var(--white)",
              borderRadius: 9,
              padding: "11px 14px",
              fontSize: 13.5,
              fontWeight: 600,
            },
          },
          choices[0]
        ),
        React.createElement(
          "button",
          {
            onClick: onProceed,
            style: {
              flex: 1,
              background: "var(--red)",
              border: "none",
              color: "#fff",
              borderRadius: 9,
              padding: "11px 14px",
              fontSize: 13.5,
              fontWeight: 700,
            },
          },
          choices[1]
        )
      )
    )
  );
}

// ---------------------------------------------------------------------------
// Result modal (success / failure)
// ---------------------------------------------------------------------------
function ResultModal({ t, result, onClose }) {
  if (!result) return null;
  const isDevice = result.status === "device";
  const isSuccess = result.status === "success";
  const title = isDevice ? "Download unavailable on this device" : (isSuccess ? t.downloadSuccessTitle : t.downloadFailTitle);
  const body = isDevice
    ? "This Roblox asset is made for Roblox Studio. Roblox Studio is not available on mobile phones or tablets, so this file cannot be used here. Open this site on a Windows or Mac computer to download and use the asset in Roblox Studio."
    : (isSuccess ? t.downloadSuccessBody : result.error);
  return React.createElement(
    "div",
    {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 100,
        padding: 20,
        animation: "fadeIn 0.2s ease",
      },
      onClick: onClose,
    },
    React.createElement(
      "div",
      {
        onClick: (e) => e.stopPropagation(),
        style: {
          position:"relative",
          overflow:"hidden",
          background: isDevice ? "radial-gradient(circle at 100% 0,rgba(226,35,26,.17),transparent 40%),linear-gradient(180deg,#171b23,#090c11)" : "var(--bg-elev-2)",
          border: `1px solid ${isSuccess ? "rgba(52,199,89,0.4)" : "rgba(255,69,58,0.35)"}`,
          borderRadius: 24,
          padding: 26,
          maxWidth: 470,
          width: "100%",
          animation: "scaleIn 0.25s cubic-bezier(.2,.8,.2,1)",
          boxShadow: "0 35px 120px rgba(0,0,0,.78),0 0 70px rgba(226,35,26,.10)",
          backdropFilter:"blur(22px)",
        },
      },
      React.createElement(
        "div",
        { style: { width:58,height:58,borderRadius:18,display:"grid",placeItems:"center",fontSize:27,marginBottom:15,background:isDevice?"linear-gradient(145deg,#ff5f56,#8e1712)":(isSuccess?"rgba(52,199,89,.12)":"rgba(255,69,58,.11)"),border:`1px solid ${isDevice?"rgba(255,255,255,.15)":(isSuccess?"rgba(52,199,89,.25)":"rgba(255,69,58,.25)")}`,boxShadow:isDevice?"0 16px 42px rgba(226,35,26,.28)":"none"} },
        isDevice ? "📱" : (isSuccess ? "✅" : "❌")
      ),
      React.createElement(
        "div",
        {
          style: {
            fontSize: 17,
            fontWeight: 800,
            marginBottom: 10,
            color: isSuccess ? "#8ef0a4" : "#ffb4ae",
          },
        },
        title
      ),
      body &&
        React.createElement(
          "div",
          {
            style: {
              fontSize: 13.5,
              color: "var(--muted)",
              lineHeight: 1.55,
              marginBottom: 20,
              background: "var(--bg-elev)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              padding: 12,
            },
          },
          body
        ),
      React.createElement(
        "button",
        {
          onClick: onClose,
          style: {
            width: "100%",
            marginTop: isSuccess ? 0 : 20,
            background: isSuccess ? "#1f7a37" : "var(--red)",
            border: "none",
            color: "#fff",
            borderRadius: 9,
            padding: "11px 14px",
            fontSize: 13.5,
            fontWeight: 700,
          },
        },
        t.close
      )
    )
  );
}

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------
function Toast({ toast, onDone }) {
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(onDone, 3600);
    return () => clearTimeout(timer);
  }, [toast]);

  if (!toast) return null;
  const isSuccess = toast.status === "success";
  return React.createElement(
    "div",
    {
      style: {
        position: "fixed",
        bottom: 22,
        insetInlineEnd: 22,
        zIndex: 200,
        background: "var(--bg-elev-2)",
        border: `1px solid ${isSuccess ? "rgba(52,199,89,0.5)" : "rgba(255,69,58,0.5)"}`,
        borderRadius: 12,
        padding: "14px 18px",
        maxWidth: 340,
        boxShadow: "0 16px 40px rgba(0,0,0,0.5)",
        animation: "toastIn 0.3s ease",
        display: "flex",
        gap: 10,
        alignItems: "flex-start",
      },
    },
    React.createElement("span", { style: { fontSize: 18 } }, isSuccess ? "✅" : "❌"),
    React.createElement(
      "span",
      { style: { fontSize: 13, lineHeight: 1.4 } },
      isSuccess ? toast.t.downloadSuccessTitle : toast.t.downloadFailTitle
    )
  );
}

function loadPageBanStatus(){return (async()=>{try{const auth=window.hatchable?.auth;const session=auth?await auth.getSession():null;const accountStatus=session?.user?await fetch('/api/user-ban-status?ts='+Date.now(),{cache:'no-store',credentials:'include'}):null;const accountData=accountStatus?.ok?await accountStatus.json():null;const ipStatus=await fetch('/api/ip-ban-status?ts='+Date.now(),{cache:'no-store'});if(!ipStatus.ok){if(accountData?.banned||accountData?.warning)return accountData;return null;}const ipData=await ipStatus.json();if(ipData?.banned){return {banned:true,reason:ipData.reason||'No reason provided',offensive_item:ipData.offensive_item||'',expires_at:ipData.expires_at||null,ban_type:'IB',attachment_key:ipData.attachment_key||'',attachment_name:ipData.attachment_name||'',attachment_type:ipData.attachment_type||'',warning:null};}if(accountData)return accountData;return {banned:false,warning:null};}catch(e){console.error('Ban status failed',e);return null;}})();}

// ---------------------------------------------------------------------------
// Main App
// ---------------------------------------------------------------------------
const rbxAutoTranslationOriginals=new Map();
const rbxAutoTranslationAttributes=new WeakMap();
let rbxAutoTranslationBusy=false;
let rbxAutoTranslationTimer=null;
let rbxAutoTranslationObserver=null;
function rbxShouldSkipTranslationNode(node){
  const el=node?.parentElement;
  if(!el)return true;
  if(['SCRIPT','STYLE','NOSCRIPT','TEMPLATE'].includes(el.tagName))return true;
  if(el.closest?.('[data-no-translate="true"],[contenteditable="true"]'))return true;
  const text=String(node.nodeValue||'').trim();
  if(!text||/^https?:\/\//i.test(text)||/^[\d\W_]+$/.test(text))return true;
  return false;
}
function rbxCollectTranslationUnits(){
  const textUnits=[];
  const attrUnits=[];
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  let node;
  while((node=walker.nextNode())){
    if(rbxShouldSkipTranslationNode(node))continue;
    const raw=String(node.nodeValue||'').trim();
    if(!raw)continue;
    let state=rbxAutoTranslationOriginals.get(node);
    if(!state){state={original:raw,last:''};rbxAutoTranslationOriginals.set(node,state);}
    textUnits.push({node,state,value:state.original});
  }
  document.body.querySelectorAll('*').forEach(el=>{
    if(['SCRIPT','STYLE','NOSCRIPT','TEMPLATE','INPUT','TEXTAREA'].includes(el.tagName))return;
    if(el.closest?.('[data-no-translate="true"]'))return;
    for(const attr of ['placeholder','title','aria-label','data-tooltip']){
      if(!el.hasAttribute(attr))continue;
      const raw=String(el.getAttribute(attr)||'').trim();
      if(!raw||/^https?:\/\//i.test(raw)||/^[\d\W_]+$/.test(raw))continue;
      let map=rbxAutoTranslationAttributes.get(el);
      if(!map){map=new Map();rbxAutoTranslationAttributes.set(el,map);}
      let state=map.get(attr);
      if(!state){state={original:raw,last:''};map.set(attr,state);}
      attrUnits.push({el,attr,state,value:state.original});
    }
  });
  return {textUnits,attrUnits};
}
async function rbxTranslateRenderedPage(lang){
  const langCode=String(lang||'en').split('-')[0].toLowerCase();
  if(!langCode||langCode==='en'||!document.body)return;
  if(rbxAutoTranslationBusy)return;
  rbxAutoTranslationBusy=true;
  try{
    const {textUnits,attrUnits}=rbxCollectTranslationUnits();
    const all=[...textUnits.map(x=>({kind:'text',...x})),...attrUnits.map(x=>({kind:'attr',...x}))];
    const sourceValues=[...new Set(all.map(x=>String(x.value||'')).filter(Boolean))];
    if(!sourceValues.length)return;
    const cacheKey='rbx-auto-ui-translations-'+langCode;
    let cache={};
    try{cache=JSON.parse(localStorage.getItem(cacheKey)||'{}')||{};}catch(_){cache={};}
    const missing=sourceValues.filter(v=>!Object.prototype.hasOwnProperty.call(cache,v));
    for(let i=0;i<missing.length;i+=40){
      const batch=missing.slice(i,i+40);
      try{
        const r=await fetch('/api/translate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:langCode,source:'en',texts:batch})});
        const d=await r.json().catch(()=>({}));
        const translated=Array.isArray(d.translations)?d.translations:batch;
        batch.forEach((value,index)=>{cache[value]=String(translated[index]??value);});
        try{localStorage.setItem(cacheKey,JSON.stringify(cache));}catch(_){ }
      }catch(_){batch.forEach(value=>{cache[value]=value;});}
    }
    for(const unit of all){
      const translated=String(cache[unit.value]??unit.value);
      if(unit.kind==='text'){
        if(unit.node.isConnected)unit.node.nodeValue=translated;
        unit.state.last=translated;
      }else if(unit.el.isConnected){
        unit.el.setAttribute(unit.attr,translated);
        unit.state.last=translated;
      }
    }
  }finally{rbxAutoTranslationBusy=false;}
}
function startRbxWholePageTranslation(){
  if(rbxAutoTranslationObserver){rbxAutoTranslationObserver.disconnect();rbxAutoTranslationObserver=null;}
  clearTimeout(rbxAutoTranslationTimer);
  rbxAutoTranslationBusy=false;
}
window.rbxTranslateRenderedPage=rbxTranslateRenderedPage;
window.startRbxWholePageTranslation=startRbxWholePageTranslation;

async function ensureAssetNameTranslations(code,files){
  const langCode=String(code||'en').split('-')[0].toLowerCase();
  if(!langCode||langCode==='en')return;
  const list=Array.isArray(files)?files.filter(f=>f&&f.id&&String(f.name||'').trim()):[];
  if(!list.length)return;
  window.ASSET_NAME_TRANSLATIONS=window.ASSET_NAME_TRANSLATIONS||{};
  window.ASSET_NAME_TRANSLATIONS[langCode]=window.ASSET_NAME_TRANSLATIONS[langCode]||{};
  const map=window.ASSET_NAME_TRANSLATIONS[langCode];
  const cacheKey='rbx-assets-asset-names-v2-'+langCode;
  try{
    const cached=JSON.parse(localStorage.getItem(cacheKey)||'null');
    if(cached&&typeof cached==='object')Object.assign(map,cached);
  }catch(_){ }
  const sourceName=(f)=>{
    const id=String(f.id);
    return String(LOCALIZED_FILE_TITLES?.en?.[id]||f.name||'').replace(/\\.rbxm$/i,'').trim();
  };
  const stillPending=list.filter(f=>!map[String(f.id)]||map[String(f.id)]===sourceName(f));
  if(!stillPending.length)return;
  try{
    for(let i=0;i<stillPending.length;i+=40){
      const batch=stillPending.slice(i,i+40);
      const sourceTexts=batch.map(sourceName);
      const r=await fetch('/api/translate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:langCode,texts:sourceTexts})});
      const d=await r.json().catch(()=>({}));
      const out=Array.isArray(d.translations)?d.translations:[];
      batch.forEach((f,j)=>{
        const source=sourceTexts[j];
        const text=String(out[j]||'').trim();
        if(text&&text!==source)map[String(f.id)]=text;
      });
    }
    try{localStorage.setItem(cacheKey,JSON.stringify(map));}catch(_){ }
  }catch(_){ }
}

async function ensureDynamicLanguage(code) {
  const langCode=String(code||'').trim();
  if(!langCode||langCode==='en'||window.TRANSLATIONS?.[langCode]?.__dynamicLoaded)return;
  const cachedKey='rbx-assets-dynamic-language-'+langCode;
  try{
    const cached=JSON.parse(localStorage.getItem(cachedKey)||'null');
    if(cached&&typeof cached==='object'){
      window.TRANSLATIONS[langCode]=cached.translations||cached;
      if(!window.TRANSLATIONS[langCode].dir)window.TRANSLATIONS[langCode].dir=['ar','fa','he','ur','ps','sd','ug','yi'].includes(langCode)?'rtl':'ltr';
      window.TRANSLATIONS[langCode].__dynamicLoaded=true;
      if(cached.ui)window.UI_STRINGS[langCode]=cached.ui;
      return;
    }
  }catch(_){ }
  try{
    const pageValues=Object.keys(window.TRANSLATIONS.en||{}).filter(k=>k!=='dir').map(k=>String(window.TRANSLATIONS.en[k]??''));
    const pageKeys=Object.keys(window.TRANSLATIONS.en||{}).filter(k=>k!=='dir');
    const uiValues=Object.keys(window.UI_STRINGS?.en||{}).map(k=>String(window.UI_STRINGS.en[k]??''));
    const uiKeys=Object.keys(window.UI_STRINGS?.en||{});
    const chunks=async(values)=>{
      const out=[];
      for(let i=0;i<values.length;i+=40){
        const r=await fetch('/api/translate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:langCode,texts:values.slice(i,i+40)})});
        const d=await r.json().catch(()=>({}));
        const part=Array.isArray(d.translations)?d.translations:values.slice(i,i+40);
        out.push(...part);
      }
      return out;
    };
    const [pageTranslated,uiTranslated]=await Promise.all([chunks(pageValues),chunks(uiValues)]);
    const page={dir:['ar','fa','he','ur','ps','sd','ug','yi'].includes(langCode)?'rtl':'ltr'};
    pageKeys.forEach((key,i)=>{page[key]=pageTranslated[i]||pageValues[i]||window.TRANSLATIONS.en[key];});
    const ui={}; uiKeys.forEach((key,i)=>{ui[key]=uiTranslated[i]||uiValues[i]||window.UI_STRINGS.en[key];});
    page.__dynamicLoaded=true;
    window.TRANSLATIONS[langCode]=page;
    window.UI_STRINGS[langCode]=ui;
    try{localStorage.setItem(cachedKey,JSON.stringify({translations:page,ui}));}catch(_){ }
  }catch(_){
    const fallback={...(window.TRANSLATIONS.en||{})}; fallback.dir=['ar','fa','he','ur','ps','sd','ug','yi'].includes(langCode)?'rtl':'ltr'; fallback.__dynamicLoaded=true;
    window.TRANSLATIONS[langCode]=fallback;
    window.UI_STRINGS[langCode]={...(window.UI_STRINGS?.en||{})};
  }
}
function App() {
  const lang = 'en';
  const [isMobile] = useState(() => detectIsMobileOrTablet());
  useEffect(() => {
    const mobileHandler = (event) => {
      if (detectIsMobileOrTablet() && event.detail?.file) setResultModal({ status: "device", file: event.detail.file });
    };
    const successHandler = () => setResultModal({ status: "success" });
    window.addEventListener("rbx-mobile-download-warning", mobileHandler);
    window.addEventListener("rbx-download-success", successHandler);
    return () => {
      window.removeEventListener("rbx-mobile-download-warning", mobileHandler);
      window.removeEventListener("rbx-download-success", successHandler);
    };
  }, []);
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const [category, setCategory] = useState("all");
  const [websiteCategories, setWebsiteCategories] = useState(CATEGORY_ORDER);
  const [categoryLabels, setCategoryLabels] = useState({});
  useEffect(() => { fetch('/api/categories/list').then(r => r.ok ? r.json() : []).then(list => { const slugs = ['all', ...list.map(x => String(x.slug || '').toLowerCase()).filter(Boolean)]; const labels = {}; list.forEach(x => { if (x.slug && x.name) labels[String(x.slug).toLowerCase()] = String(x.name); }); setCategoryLabels(labels); setWebsiteCategories([...new Set(slugs)]); }).catch(() => {}); }, []);
  const [search, setSearch] = useState("");
  const [sortMode, setSortMode] = useState("featured");
  const [favorites, setFavorites] = useState(() => {
    try { return new Set(JSON.parse(localStorage.getItem("rbx-assets-favorites") || "[]").map(String)); }
    catch (_) { return new Set(); }
  });
  const toggleFavorite = useCallback((id) => {
    setFavorites(current => {
      const next = new Set(current);
      const key = String(id);
      if (next.has(key)) next.delete(key); else next.add(key);
      try { localStorage.setItem("rbx-assets-favorites", JSON.stringify([...next])); } catch (_) {}
      window.rbxUISound?.click?.();
      return next;
    });
  }, []);
  const [downloadingId, setDownloadingId] = useState(null);
  const [resultModal, setResultModal] = useState(null);
  const [toast, setToast] = useState(null);
  const [account, setAccount] = useState(() => {
    try {
      const root = document.getElementById("account-root");
      if (root?.dataset?.ssrAuth === "1") {
        const username = root.dataset.ssrUsername || "";
        const userId = root.dataset.ssrUserId || "";
        return username || userId ? { username, id: userId, handle: username } : {};
      }
    } catch (_) {}
    return null;
  });
  const [accountLoading, setAccountLoading] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [releasingUpdate, setReleasingUpdate] = useState(false);
  const [releaseResult, setReleaseResult] = useState(null);
  const releaseRequestRef = useRef(false);
  const [pageBan, setPageBan] = useState(null);
  const [reportNotice, setReportNotice] = useState(null);
  const [reportNoticeAcking, setReportNoticeAcking] = useState(false);
  const [warningChecked, setWarningChecked] = useState(false);
  const [acknowledgingWarning, setAcknowledgingWarning] = useState(false);
  const [unlocking, setUnlocking] = useState(false);
  const [managedAssets, setManagedAssets] = useState(() => window.MANAGED_ASSETS || []);
  const [purchased, setPurchased] = useState(() => new Set());
  const [purchasingId, setPurchasingId] = useState(null);

  useEffect(() => {
    const onManaged = (event) => setManagedAssets(event.detail || []);
    window.addEventListener("managed-assets-ready", onManaged);
    if (window.MANAGED_ASSETS) setManagedAssets(window.MANAGED_ASSETS);
    return () => window.removeEventListener("managed-assets-ready", onManaged);
  }, []);

  const t = window.TRANSLATIONS[lang] || window.TRANSLATIONS.en;

  useEffect(() => {
    document.documentElement.lang = 'en';
    document.documentElement.dir = 'ltr';
    document.title = window.TRANSLATIONS?.en?.siteName || document.title;
  }, []);

  const refreshAccount = useCallback(async () => {
    const auth = window.hatchable?.auth;
    if (!auth) { setAccountLoading(false); return; }
    try {
      const session = await auth.getSession();
      if (!session?.user) {
        setAccount(null);
        setAccountLoading(false);
        return;
      }
      const sessionUser = session.user;
      setAccount((current) => ({
        ...(current || {}),
        username: sessionUser.username || sessionUser.handle || sessionUser.name || current?.username || sessionUser.email || "User",
        handle: current?.handle || sessionUser.handle,
        email: current?.email || sessionUser.email,
      }));
      const response = await fetch("/api/account/status", { cache: "no-store", credentials: "same-origin" });
      if (!response.ok) throw new Error("Could not load Coins");
      const accountData = await response.json();
      setAccount(current => ({
        ...(current || {}),
        ...accountData,
        username: accountData?.username || current?.username || sessionUser.username || sessionUser.handle || sessionUser.name || sessionUser.email || "User"
      }));
    } catch (error) {
      console.error("Coin account failed to load:", error);
      // Keep the SSR-loaded account/greeting visible when the account-status
      // request temporarily fails. A failed coins request must never erase
      // the signed-in user's greeting.
      setAccount((current) => current || (() => {
        try {
          const root = document.getElementById("account-root");
          if (root?.dataset?.ssrAuth === "1") {
            const username = root.dataset.ssrUsername || "";
            const userId = root.dataset.ssrUserId || "";
            if (username || userId) return { username, id: userId, handle: username };
          }
        } catch (_) {}
        return null;
      })());
    } finally {
      setAccountLoading(false);
    }
  }, []);

  useEffect(() => { refreshAccount(); }, [refreshAccount]);

  useEffect(() => {
    if (!account) {
      setIsAdmin(false);
      return;
    }
    let cancelled = false;
    fetch("/api/account/admin-status", { cache: "no-store", credentials: "same-origin" })
      .then(r => r.ok ? r.json() : { is_admin: false })
      .then(data => { if (!cancelled) setIsAdmin(data?.is_admin === true); })
      .catch(() => { if (!cancelled) setIsAdmin(false); });
    return () => { cancelled = true; };
  }, [account]);

  const triggerGlobalUpdate = useCallback(async () => {
    if (!isAdmin || releasingUpdate || releaseRequestRef.current) return;
    if (document.getElementById("release-update-overlay")) return;

    const overlay = document.createElement("div");
    overlay.id = "release-update-overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "release-update-heading");
    overlay.style.cssText = "position:fixed;inset:0;z-index:12000;display:grid;place-items:center;padding:18px;background:rgba(2,5,9,.82);backdrop-filter:blur(12px);";
    overlay.innerHTML = `
      <style>
        #release-update-overlay *{box-sizing:border-box}
        #release-update-overlay .ru-card{width:min(620px,100%);max-height:92vh;overflow:auto;border:1px solid #354150;border-radius:22px;background:linear-gradient(160deg,#171e28,#090e14);box-shadow:0 32px 110px rgba(0,0,0,.72);color:#f4f6f9}
        #release-update-overlay .ru-head{padding:22px 24px 18px;border-bottom:1px solid #28323e;background:radial-gradient(circle at 0 0,rgba(226,35,26,.19),transparent 48%)}
        #release-update-overlay .ru-kicker{font-size:10px;font-weight:950;letter-spacing:.16em;text-transform:uppercase;color:#ff8c85}
        #release-update-overlay h2{margin:7px 0 0;font-size:23px;letter-spacing:-.04em}
        #release-update-overlay .ru-sub{margin-top:7px;color:#96a2b1;font-size:12px;line-height:1.55}
        #release-update-overlay .ru-body{padding:20px 24px 23px;display:grid;gap:14px}
        #release-update-overlay label{display:block;margin-bottom:7px;color:#c6ced8;font-size:11px;font-weight:900}
        #release-update-overlay input,#release-update-overlay textarea,#release-update-overlay select{display:block;width:100%;min-height:42px;padding:11px 12px;border:1px solid #344150;border-radius:11px;outline:none;background:#080d13;color:#f4f6f9;font:inherit;font-size:13px}
        #release-update-overlay textarea{min-height:138px;resize:vertical;line-height:1.6;white-space:pre-wrap}
        #release-update-overlay input:focus,#release-update-overlay textarea:focus,#release-update-overlay select:focus{border-color:#e2231a;box-shadow:0 0 0 3px rgba(226,35,26,.12)}
        #release-update-overlay .ru-preview{padding:14px;border:1px solid rgba(226,35,26,.24);border-radius:13px;background:rgba(226,35,26,.055)}
        #release-update-overlay .ru-preview-label{font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#ff9d96;font-weight:950}
        #release-update-overlay .ru-preview-title{margin-top:7px;font-size:14px;font-weight:900;overflow-wrap:anywhere}
        #release-update-overlay .ru-preview-copy{margin-top:6px;color:#b3bdc9;font-size:12px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere}
        #release-update-overlay .ru-actions{display:flex;justify-content:flex-end;gap:9px;flex-wrap:wrap;margin-top:2px}
        #release-update-overlay .ru-btn{border:1px solid #374454;border-radius:10px;padding:11px 14px;background:#151d27;color:#e8edf3;font:850 12px/1.2 'Segoe UI',Inter,system-ui,sans-serif;cursor:pointer}
        #release-update-overlay .ru-primary{border-color:rgba(255,105,96,.45);background:linear-gradient(180deg,#ed3027,#a91610);color:#fff}
        #release-update-overlay .ru-btn:disabled{opacity:.55;cursor:wait}
        #release-update-overlay .ru-error{display:none;padding:10px 12px;border:1px solid rgba(255,80,72,.3);border-radius:10px;background:rgba(255,69,58,.08);color:#ffaaa4;font-size:12px;line-height:1.5}
        @media(max-width:520px){#release-update-overlay{padding:10px!important}#release-update-overlay .ru-head{padding:18px}#release-update-overlay .ru-body{padding:16px 18px 18px}#release-update-overlay h2{font-size:20px}#release-update-overlay .ru-actions .ru-btn{flex:1}}
      </style>
      <form class="ru-card">
        <div class="ru-head">
          <div class="ru-kicker">Release center · Preview before publishing</div>
          <h2 id="release-update-heading">What's new in this update?</h2>
          <div class="ru-sub">Tell members what changed before you release. These details will appear in the update popup and on the signed-in members' Update Logs page.</div>
        </div>
        <div class="ru-body">
          <div><label for="ru-title">Update title</label><input id="ru-title" maxlength="120" required placeholder="Example: New moderation controls" autocomplete="off"></div>
          <div><label for="ru-kind">Update type</label><select id="ru-kind"><option>Feature</option><option>Improvement</option><option>Fix</option><option>Security</option><option>Maintenance</option><option selected>Update</option></select></div>
          <div><label for="ru-summary">What's new? (shown to users)</label><textarea id="ru-summary" maxlength="2000" required placeholder="Describe the new features, changes, and fixes in plain language…"></textarea><div class="ru-sub" style="margin-top:6px">Be specific. This message is shown to everyone when you release the update.</div></div>
          <div class="ru-preview"><div class="ru-preview-label">Member popup preview</div><div class="ru-preview-title" id="ru-preview-title">Your update title</div><div class="ru-preview-copy" id="ru-preview-copy">Your What's new description will appear here.</div></div>
          <div class="ru-error" id="ru-error" role="alert"></div>
          <div class="ru-actions"><button type="button" class="ru-btn" id="ru-cancel">Cancel</button><button type="submit" class="ru-btn ru-primary" id="ru-publish">Release update to everyone</button></div>
        </div>
      </form>`;
    document.body.appendChild(overlay);
    const form = overlay.querySelector("form");
    const titleInput = overlay.querySelector("#ru-title");
    const summaryInput = overlay.querySelector("#ru-summary");
    const kindInput = overlay.querySelector("#ru-kind");
    const previewTitle = overlay.querySelector("#ru-preview-title");
    const previewCopy = overlay.querySelector("#ru-preview-copy");
    const publishButton = overlay.querySelector("#ru-publish");
    const errorBox = overlay.querySelector("#ru-error");
    const close = () => overlay.remove();
    overlay.querySelector("#ru-cancel").onclick = close;
    overlay.addEventListener("keydown", event => { if (event.key === "Escape" && !publishButton.disabled) close(); });
    titleInput.addEventListener("input", () => { previewTitle.textContent = titleInput.value.trim() || "Your update title"; });
    summaryInput.addEventListener("input", () => { previewCopy.textContent = summaryInput.value.trim() || "Your What's new description will appear here."; });
    kindInput.addEventListener("change", () => { previewTitle.textContent = (titleInput.value.trim() || "Your update title") + " · " + kindInput.value; });
    titleInput.addEventListener("input", () => { previewTitle.textContent = (titleInput.value.trim() || "Your update title") + " · " + kindInput.value; });
    previewTitle.textContent = "Your update title · " + kindInput.value;
    titleInput.focus();

    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (!isAdmin || releasingUpdate || releaseRequestRef.current) return;
      const title = titleInput.value.trim();
      const summary = summaryInput.value.trim();
      if (!title || !summary) {
        errorBox.textContent = "Add an update title and describe what's new before releasing.";
        errorBox.style.display = "block";
        return;
      }
      releaseRequestRef.current = true;
      setReleasingUpdate(true);
      publishButton.disabled = true;
      publishButton.textContent = "Releasing…";
      overlay.querySelector("#ru-cancel").disabled = true;
      errorBox.style.display = "none";
      try {
        const response = await fetch("/api/admin/release-update", {
          method: "POST",
          credentials: "same-origin",
          cache: "no-store",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, summary, kind: kindInput.value })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data?.error || "Could not release update");
        close();
        setReleaseResult({ ok: true, text: "Released to everyone · added to Update Logs" });
        window.setTimeout(() => setReleaseResult(null), 4000);
      } catch (error) {
        errorBox.textContent = error?.message || "Could not release the update.";
        errorBox.style.display = "block";
        publishButton.disabled = false;
        publishButton.textContent = "Try release again";
        overlay.querySelector("#ru-cancel").disabled = false;
        setReleaseResult({ ok: false, text: error?.message || "Could not release the update." });
        window.setTimeout(() => setReleaseResult(null), 4000);
      } finally {
        setReleasingUpdate(false);
        releaseRequestRef.current = false;
      }
    });
  }, [isAdmin, releasingUpdate, t]);

  useEffect(() => {
    if (!account) return;
    let alive = true;
    const checkSupportNotifications = async () => {
      if (window.rbxAppMinimized) return;
      try {
        const response = await fetch('/api/support/notifications?ts=' + Date.now(), { cache: 'no-store', credentials: 'include' });
        const data = response.ok ? await response.json() : { notifications: [] };
        const notices = Array.isArray(data.notifications) ? data.notifications : [];
        const unseen = notices.filter(n => !n.seen_at);
        if (!alive || !unseen.length) return;
        const notice = unseen[0];
        window.showPrestigeNotice?.(notice.title || 'Support ticket resolved', notice.message || 'Your support ticket has been resolved.', false, true);
        await fetch('/api/support/notifications', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: notice.id })
        }).catch(() => {});
      } catch (_) {
        // Keep the site usable if notification polling is unavailable.
      }
    };
    // Wait until the assets page has finished its initial load before showing
    // support notifications, so the notice cannot flash and disappear during navigation.
    const startAfterLoad = () => {
      if (document.readyState === 'complete') {
        checkSupportNotifications();
        return;
      }
      window.addEventListener('load', checkSupportNotifications, { once: true });
    };
    startAfterLoad();
    const timer = setInterval(checkSupportNotifications, 20000);
    return () => { alive = false; clearInterval(timer); };
  }, [account]);

  useEffect(() => {
    if (!account) return;
    let alive = true;
    const checkTrollNotifications = async () => {
      if (window.rbxAppMinimized) return;
      try {
        const response = await fetch('/api/troll/notifications?ts=' + Date.now(), { cache: 'no-store', credentials: 'include' });
        const data = response.ok ? await response.json() : { notifications: [] };
        const notices = Array.isArray(data.notifications) ? data.notifications : [];
        const unseen = notices.filter(n => !n.seen_at);
        if (!alive || !unseen.length) return;
        const troll = unseen[0];
        window.showPrestigeTroll?.(troll.title || 'Account Notice', troll.message || '', troll.button_text || 'Got it');
        await fetch('/api/troll/notifications', {
          method: 'POST', credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: troll.id })
        }).catch(() => {});
      } catch (_) {
        // Keep the site usable if Troll polling is unavailable.
      }
    };
    checkTrollNotifications();
    const timer = setInterval(checkTrollNotifications, 20000);
    return () => { alive = false; clearInterval(timer); };
  }, [account]);

  useEffect(() => {
    let alive = true;
    const check = async () => {
      if (window.rbxAppMinimized) return;
      const status = await loadPageBanStatus();
      if (!alive || !status) return;
      const active = status?.banned || status?.warning;
      if (active) {
        document.querySelectorAll('.community-overlay.open, .cm-overlay.open, .modal.open, [data-modal-root]').forEach(el => el.remove());
        setPageBan(() => status);
      }
      // Do not let a transient/non-authoritative status response unlock a user.
      // The active lock is replaced only when a later authoritative response has
      // actually been confirmed by both account and IP checks.
      // A successful status response is authoritative. Do not keep an older ban/warning
      // on screen after the server has moved the user to the next escalation stage.
      // Only preserve the current lock when the status check itself failed (returns null).
      setPageBan(status);
    };
    check();
    const immediate = () => { if (alive) check(); };
    window.addEventListener('rbx-moderation-active', immediate);
    const timer = setInterval(check, 20000);
    return () => { alive = false; clearInterval(timer); window.removeEventListener('rbx-moderation-active', immediate); };
  }, []);

  useEffect(() => {
    if (!(pageBan?.banned || pageBan?.warning)) return;
    document.querySelectorAll('.community-overlay.open, .cm-overlay.open, .modal.open, [data-modal-root]').forEach(el => {
      if (!el.closest('[data-moderation-lock]')) el.remove();
    });
    document.body.style.overflow = 'hidden';
    document.body.setAttribute('data-moderation-lock','1');
    return () => {
      document.body.style.overflow = '';
      document.body.removeAttribute('data-moderation-lock');
    };
  }, [pageBan?.banned, pageBan?.warning?.id]);

  useEffect(() => {
    if (!account) { setReportNotice(null); return; }
    let alive = true;
    const check = async () => {
      if (window.rbxAppMinimized) return;
      try {
        const r = await fetch('/api/account/report-notice?ts='+Date.now(), {cache:'no-store'});
        const d = r.ok ? await r.json() : {notice:null};
        if (alive) setReportNotice(d.notice || null);
      } catch (_) {
        // Keep the current notice during transient network failures.
      }
    };
    check();
    const timer = setInterval(check, 30000);
    return () => { alive = false; clearInterval(timer); };
  }, [account]);

  useEffect(() => {
    if (!reportNotice) return;
    const onKey = (e) => { if (e.key === 'Escape' && !reportNoticeAcking) setReportNotice(null); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [reportNotice, reportNoticeAcking]);

  useEffect(() => {
    if (!account) { setPurchased(new Set()); return; }
    fetch("/api/account/purchases").then(r => r.ok ? r.json() : { purchases: [] }).then(d => setPurchased(new Set((d.purchases || []).map(String)))).catch(() => {});
  }, [account]);

  const purchaseAsset = useCallback(async (file) => {
    if (!account) { window.location.href = "/login?next=/"; return; }
    if (purchasingId) return;
    setPurchasingId(file.id);
    try {
      const response = await fetch("/api/assets/purchase", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: file.id }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Purchase failed.");
      setPurchased(current => new Set([...current, String(file.id)]));
      if (typeof data.coins === "number") setAccount(current => ({ ...(current || {}), coins: data.coins }));
      setToast({ status: "success", t: { ...t, downloadSuccessTitle: "Purchased!", downloadFailTitle: "Purchased!" } });
    } catch (error) {
      setToast({ status: "error", t: { ...t, downloadSuccessTitle: "Purchase failed", downloadFailTitle: error.message || "You don't have enough Coins." } });
    } finally { setPurchasingId(null); }
  }, [account, purchasingId, t]);

  const [claimingWeekly, setClaimingWeekly] = useState(false);
  const claimWeeklyReward = useCallback(async () => {
    if (!account || account.weekly_claimed || claimingWeekly) return;
    setClaimingWeekly(true);
    try {
      const response = await fetch("/api/rewards/weekly-claim", { method: "POST" });
      const data = await response.json().catch(() => ({}));
      if (!response.ok && response.status !== 409) throw new Error(data.error || "Could not claim weekly reward.");
      setAccount((current) => ({ ...(current || {}), coins: Number(data.coins ?? current?.coins ?? 0), weekly_claimed: true }));
      if (data.streak != null) setAccount((current) => ({ ...(current || {}), streak: Number(data.streak) }));
      setToast({ status: "success", t: { ...t, downloadSuccessTitle: response.status === 409 ? "Already claimed" : "Coins claimed!", downloadFailTitle: "Could not claim Coins." } });
    } catch (error) {
      setToast({ status: "error", t: { ...t, downloadSuccessTitle: "Coins claim failed", downloadFailTitle: error.message || "Could not claim Coins." } });
    } finally {
      setClaimingWeekly(false);
    }
  }, [account, claimingWeekly, t]);

  const unlockPremium = useCallback(async () => {
    setUnlocking(true);
    try {
      const response = await fetch("/api/premium/unlock", { method: "POST" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Premium could not be unlocked.");
      setAccount((current) => ({ ...(current || {}), ...data }));
      setToast({ status: "success", t: { ...t, downloadSuccessTitle: "Premium unlocked!", downloadFailTitle: "Premium could not be unlocked." } });
    } catch (error) {
      setToast({ status: "error", t: { ...t, downloadSuccessTitle: "Premium unlocked!", downloadFailTitle: error.message || "Premium could not be unlocked." } });
    } finally {
      setUnlocking(false);
    }
  }, [t]);

  useEffect(() => {
    document.documentElement.setAttribute("dir", t.dir);
    document.documentElement.setAttribute("lang", lang);
    document.title = t.siteName;
  }, [t.siteName]);

  const allFiles = useMemo(() => {
    const managedByName = new Map(managedAssets.map((a) => [a.name, a]));
    const managedLegacyById = new Map(managedAssets.filter((a) => a.legacy_id).map((a) => [a.legacy_id, a]));
    const categoryAlias = new Map(Object.entries(categoryLabels).map(([slug, name]) => [String(name).trim().toLowerCase(), slug]));
    Object.keys(categoryLabels).forEach(slug => categoryAlias.set(String(slug).trim().toLowerCase(), String(slug).trim().toLowerCase()));
    const normalizeCategory = raw => String(raw || 'everything').split(',').map(v => categoryAlias.get(v.trim().toLowerCase()) || v.trim().toLowerCase()).filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(',');
    const legacy = FILES.map((f) => {
      const m = managedLegacyById.get(f.id) || managedByName.get(f.name);
      if (!m) return f;
      const merged = { ...f, ...m, id: m.id.startsWith("legacy-") ? m.id : `managed-${m.id}` };
      merged.category = normalizeCategory(merged.category_name || merged.category);
      return merged;
    }).filter((f) => !f.removed);
    const added = managedAssets.filter((a) => !a.legacy_id && !FILES.some((f) => f.name === a.name) && !a.removed).map((a) => ({ ...a, id: `managed-${a.id}`, category: normalizeCategory(a.category_name || a.category) }));
    return [...legacy, ...added];
  }, [managedAssets, categoryLabels]);

  const [assetTranslationVersion,setAssetTranslationVersion]=useState(0);
  useEffect(()=>{
    let alive=true;
    if(lang==='en'){return()=>{alive=false;};}
    ensureAssetNameTranslations(lang,allFiles).finally(()=>{if(alive)setAssetTranslationVersion(v=>v+1);});
    return()=>{alive=false;};
  },[lang,allFiles]);
  void assetTranslationVersion;

  const filtered = useMemo(() => {
    const result = allFiles.filter((f) => {
      const fileCategories = String(f.category || '').split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
      const matchesCategory = category === "all" || category === "favorites" ? (category === "favorites" ? favorites.has(String(f.id)) : true) : fileCategories.includes(String(category).toLowerCase());
      const query = search.trim().toLowerCase();
      const matchesSearch = !query || (f.name + " " + displayFileName(f, lang) + " " + String(f.description || "")).toLowerCase().includes(query);
      return matchesCategory && matchesSearch;
    });
    return result.sort((a,b) => {
      if (sortMode === "favorites") return Number(favorites.has(String(b.id))) - Number(favorites.has(String(a.id)));
      if (sortMode === "premium") return Number(!!b.premium) - Number(!!a.premium);
      if (sortMode === "price-low") return Number(a.basic_price ?? a.premium_price ?? 0) - Number(b.basic_price ?? b.premium_price ?? 0);
      if (sortMode === "price-high") return Number(b.basic_price ?? b.premium_price ?? 0) - Number(a.basic_price ?? a.premium_price ?? 0);
      if (sortMode === "newest") return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
      return Number(!!b.premium) - Number(!!a.premium);
    });
  }, [allFiles, category, search, lang, sortMode, favorites]);

  const counts = useMemo(() => {
    const c = { all: allFiles.length, favorites: [...favorites].filter(id => allFiles.some(f => String(f.id) === String(id))).length };
    for (const cat of websiteCategories.filter(x => x !== 'all')) {
      c[cat] = allFiles.filter((f) => String(f.category || '').split(',').map(v => v.trim().toLowerCase()).includes(String(cat).toLowerCase())).length;
    }
    return c;
  }, [allFiles, websiteCategories, favorites]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "/" && !/input|textarea|select/i.test(e.target?.tagName || "")) {
        e.preventDefault(); document.querySelector('input[placeholder*="Search"], input[placeholder*="search"]')?.focus();
      }
      if (e.key.toLowerCase() === "f" && !/input|textarea|select/i.test(e.target?.tagName || "")) {
        setCategory("favorites"); document.getElementById("asset-library")?.scrollIntoView({behavior:"smooth", block:"start"});
      }
      if (e.key === "Escape" && document.activeElement?.tagName === "INPUT") document.activeElement.blur();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Download the original .rbxm bytes stored as Base64, preserving every binary byte.
  const performDownload = useCallback(
    async (file) => {
      if (file.disabled) {
        window.showPrestigeNotice?.('Asset disabled', `Disabled${file.disabled_reason ? ` — ${file.disabled_reason}` : ""}. Press again to re-enable from Page admin.`);
        return;
      }
      setDownloadingId(file.id);
      let outcome = { status: "error" };
      try {
        const premiumLegacyIds = new Set(["legacy-gamble","legacy-door","legacy-gui","legacy-run","legacy-settings","legacy-shop"]);
        const response = file.id.startsWith("managed-")
          ? await fetch("/api/assets/download?id=" + encodeURIComponent(file.id.slice("managed-".length)) + "&v=" + encodeURIComponent(String(file.updated_at || Date.now())))
          : premiumLegacyIds.has(String(file.id))
            ? await fetch("/api/premium/download/" + encodeURIComponent(String(file.id).slice(7)))
            : await fetch("/api/assets/download-legacy?id=" + encodeURIComponent(file.id.slice(7)));
        if (!response.ok) {
          const data = await response.json().catch(() => ({}));
          throw new Error(String(data.reason || data.error || "Asset could not be loaded"));
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const disposition=response.headers.get("Content-Disposition")||"";
        const filenameMatch=disposition.match(/filename="([^"]+)"/i);
        a.download=filenameMatch?.[1]||file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        outcome = { status: "success" };
      } catch (error) {
        console.error("Download failed:", error);
        outcome = { status: "error", error: error?.message || "Asset could not be loaded." };
      }
      setDownloadingId(null);
      setResultModal(outcome);
      setToast({ status: outcome.status, t });
    },
    [t]
  );

  const handleDownloadClick = useCallback(
    (file) => {
      if (isMobile) {
        setResultModal({ status: "device", file });
      } else {
        performDownload(file);
      }
    },
    [isMobile, performDownload]
  );

  // Moderation priority: active ban > unacknowledged warning > report update.
  // A report notice must never hide a stronger active moderation action.
  if (reportNotice && !pageBan?.banned && !pageBan?.warning) {
    const acknowledgeReportNotice = async () => {
      if (reportNoticeAcking) return;
      setReportNoticeAcking(true);
      try {
        const r = await fetch('/api/account/report-notice', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:reportNotice.id})});
        if(!r.ok) throw new Error('Could not acknowledge report notice.');
        setReportNotice(null);
      } catch(e) { console.error(e); } finally { setReportNoticeAcking(false); }
    };
    return React.createElement("div", {style:{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:24,background:"radial-gradient(circle at 50% 0%,rgba(53,208,127,.09),transparent 38%),var(--bg)"}},
      React.createElement("div", {style:{maxWidth:620,width:"100%",background:"linear-gradient(180deg,#1a2029,#0d1218)",border:"1px solid rgba(53,208,127,.28)",borderRadius:24,padding:28,boxShadow:"0 35px 120px rgba(0,0,0,.62)"}},
        React.createElement("div", {style:{display:"flex",alignItems:"center",gap:12,marginBottom:20}},
          React.createElement("div", {style:{width:50,height:50,borderRadius:15,display:"grid",placeItems:"center",fontSize:24,background:reportNotice.status==='denied'?"rgba(255,69,58,.10)":"rgba(53,208,127,.10)",border:reportNotice.status==='denied'?"1px solid rgba(255,69,58,.20)":"1px solid rgba(53,208,127,.20)"}}, reportNotice.status==='denied'?"×":"✓"),
          React.createElement("div", null, React.createElement("div", {style:{fontSize:10,textTransform:"uppercase",letterSpacing:".16em",fontWeight:950,color:reportNotice.status==='denied'?"#ff766d":"#69e9a2"}}, reportNotice.status==='denied'?"MODERATION UPDATE":"REPORT RESOLVED"), React.createElement("h1", {style:{margin:"4px 0 0",fontSize:"clamp(25px,5vw,34px)",letterSpacing:"-.7px"}}, reportNotice.status==='denied'?"Report reviewed":"Report resolved"), React.createElement("div", {style:{marginTop:5,color:"#8792a1",fontSize:11,fontWeight:700}}, "Your moderation dashboard has a new update."))
        ),
        React.createElement("div", {style:{padding:16,borderRadius:15,background:"rgba(53,208,127,.05)",border:"1px solid rgba(53,208,127,.16)"}},
          React.createElement("div", {style:{fontWeight:900,fontSize:13}}, reportNotice.status==='denied'?"Your report was reviewed by the moderation team.":"Thank you for helping keep the community safe."),
          React.createElement("div", {style:{marginTop:6,color:"var(--muted)",fontSize:12,lineHeight:1.5}}, reportNotice.status==='denied'?"We reviewed the report and decided it did not meet the requirements for moderation action.":"Our moderation team reviewed the report you submitted. This is a report update only and does not mean your account was banned or restricted.")
        ),
        React.createElement("div", {style:{marginTop:14,padding:16,borderRadius:15,background:"#0a1016",border:"1px solid rgba(255,255,255,.08)"}},
          React.createElement("div", {style:{fontSize:10,textTransform:"uppercase",letterSpacing:".1em",fontWeight:900,color:"#7f8998"}}, "Report"),
          React.createElement("div", {style:{marginTop:7,color:"#e3e7ec",fontSize:14,fontWeight:800}}, String(reportNotice.category||'Other')),
          React.createElement("div", {style:{marginTop:7,color:"#9da7b5",fontSize:12,lineHeight:1.5}}, String(reportNotice.details||'No additional details were provided.')),
          React.createElement("div", {style:{marginTop:14,paddingTop:12,borderTop:"1px solid rgba(255,255,255,.08)"}},
            React.createElement("div", {style:{fontSize:10,textTransform:"uppercase",letterSpacing:".1em",fontWeight:900,color:"#7f8998"}}, reportNotice.status==='denied'?"Denial reason":"What happened"),
            React.createElement("div", {style:{marginTop:7,color:"#e3e7ec",fontSize:13,lineHeight:1.55,whiteSpace:"pre-wrap"}}, String(reportNotice.resolution_outcome||'The moderation team resolved the report.'))
          )
        ),
        React.createElement("button", {onClick:acknowledgeReportNotice,disabled:reportNoticeAcking,style:{width:"100%",marginTop:16}}, reportNoticeAcking?"Closing…":"Continue")
      )
    );
  }

  if (pageBan?.warning) {
    const acknowledgeWarning = async () => {
      if (!warningChecked || acknowledgingWarning) return;
      setAcknowledgingWarning(true);
      try {
        const r = await fetch('/api/account/ack-warning', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:pageBan.warning.id})});
        if(!r.ok) throw new Error('Could not acknowledge warning.');
        setPageBan(current => ({...(current||{}), warning:null}));
        setWarningChecked(false);
      } catch(e) { console.error(e); } finally { setAcknowledgingWarning(false); }
    };
    return React.createElement("div", { style: { minHeight: "100vh", position:"relative", overflow:"hidden", display: "flex", alignItems: "center", justifyContent: "center", padding: "34px 18px", background: "radial-gradient(circle at 16% 12%, rgba(245,197,24,.18), transparent 28%), radial-gradient(circle at 86% 88%, rgba(226,35,26,.11), transparent 32%), #090b0f" } },
      React.createElement("div", { style: { maxWidth: 720, width: "100%", background: "linear-gradient(180deg,#181b22,#0b0e13 72%)", border: "1px solid rgba(245,197,24,.34)", borderRadius: 28, padding: 30, boxShadow: "0 40px 140px rgba(0,0,0,.72), 0 0 70px rgba(245,197,24,.08)", position:"relative", overflow:"hidden" } },
        React.createElement("div", { style: { display:"flex", alignItems:"center", justifyContent:"space-between", gap:12, marginBottom:22 } },
          React.createElement("div", { style:{display:"flex",alignItems:"center",gap:12} },
            React.createElement("div", { style:{width:48,height:48,borderRadius:14,display:"grid",placeItems:"center",fontSize:24,background:"rgba(245,197,24,.12)",border:"1px solid rgba(245,197,24,.22)"} }, "⚠️"),
            React.createElement("div", null, React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".18em",fontWeight:950,color:"#f5d45b"} }, "MODERATION CASE // WARNING 2.0"), React.createElement("h1", { style:{margin:"4px 0 0",fontSize:"clamp(27px,5vw,38px)",letterSpacing:"-1px"} }, "A warning was issued"), React.createElement("div", { style:{marginTop:5,color:"#858f9d",fontSize:11,fontWeight:700} }, "Read the case details, review your account standing, then acknowledge the notice."))
          ),
          null
        ),
        React.createElement("div", { style:{padding:16,borderRadius:15,background:"rgba(245,197,24,.055)",border:"1px solid rgba(245,197,24,.16)"} },
          React.createElement("div", { style:{fontWeight:900,fontSize:13} }, "Your account has received a warning."),
          React.createElement("div", { style:{marginTop:5,color:"var(--muted)",fontSize:12,lineHeight:1.5} }, "You can continue using the site after acknowledging this notice. Please review the reason below."),
          React.createElement("div", { style:{display:"none"} })
        ),
        React.createElement("div", { style:{display:"none"} }),
        React.createElement("div", { style:{marginTop:14,padding:14,borderRadius:16,background:"linear-gradient(135deg,rgba(245,197,24,.075),rgba(226,35,26,.025))",border:"1px solid rgba(245,197,24,.16)",boxShadow:"inset 0 1px 0 rgba(255,255,255,.025)"} },
          React.createElement("div", { style:{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",flexWrap:"wrap"} },
            React.createElement("div", { style:{display:"flex",alignItems:"center",gap:10} },
              React.createElement("div", { style:{width:36,height:36,borderRadius:11,display:"grid",placeItems:"center",background:"linear-gradient(145deg,#f5c518,#c99300)",color:"#17130a",fontSize:18,fontWeight:950,boxShadow:"0 8px 22px rgba(245,197,24,.16)"} }, "!"),
              React.createElement("div", null,
                React.createElement("div", { style:{fontSize:9,textTransform:"uppercase",letterSpacing:".15em",fontWeight:950,color:"#f1ce57"} }, "ACCOUNT STANDING"),
                React.createElement("div", { style:{marginTop:3,fontSize:12,fontWeight:850,color:"#eef1f5"} }, "This warning is part of your moderation record.")
              )
            ),
            React.createElement("span", { style:{padding:"5px 8px",borderRadius:999,background:"rgba(255,255,255,.045)",border:"1px solid rgba(255,255,255,.08)",color:"#9ea9b8",fontSize:9,fontWeight:900} }, String(pageBan.warning.filter_term||"General rule"))
          )
        ),
        React.createElement("div", { style:{marginTop:12,padding:17,borderRadius:17,background:"#0a0d12",border:"1px solid rgba(255,255,255,.08)",boxShadow:"inset 0 1px 0 rgba(255,255,255,.025)"} },
          React.createElement("div", { style:{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",flexWrap:"wrap"} },
            React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".12em",fontWeight:950,color:"#7f8998"} }, "WHAT HAPPENED"),
            React.createElement("span", { style:{padding:"5px 8px",borderRadius:999,background:"rgba(245,197,24,.10)",border:"1px solid rgba(245,197,24,.22)",color:"#f5d45b",fontSize:10,fontWeight:950} }, "WARNING")
          ),
          React.createElement("div", { style:{marginTop:9,color:"#f1f3f6",fontSize:14,lineHeight:1.7,whiteSpace:"pre-wrap"} }, pageBan.warning.reason||"No reason provided"),
          React.createElement("div", { style:{display:"grid",gridTemplateColumns:"1fr",gap:9,marginTop:16} },
            React.createElement("div", { style:{padding:12,borderRadius:13,background:"#10151c",border:"1px solid rgba(255,255,255,.06)"} },React.createElement("div",{style:{fontSize:9,color:"#707b8a",fontWeight:900,letterSpacing:".10em"}},"NEXT ACTION"),React.createElement("div",{style:{marginTop:4,fontSize:13,fontWeight:950,textTransform:"capitalize"}},String(pageBan.warning.next_action||"Review")))
          ),
          React.createElement("div", { style:{marginTop:14,paddingTop:12,borderTop:"1px solid rgba(255,255,255,.08)"} },
            React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".1em",fontWeight:900,color:"#7f8998"} }, "Offensive item"),
            React.createElement("div", { style:{marginTop:7,color:"#e3e7ec",fontSize:14,lineHeight:1.6,whiteSpace:"pre-wrap"} }, pageBan.warning.offensive_item||"Not specified"),
            pageBan.warning.attachment_key&&React.createElement("a",{href:'/api/moderation-attachment?key='+encodeURIComponent(pageBan.warning.attachment_key),target:'_blank',rel:'noopener',style:{display:'inline-flex',alignItems:'center',gap:8,marginTop:12,padding:'10px 13px',borderRadius:11,border:'1px solid rgba(245,197,24,.24)',background:'rgba(245,197,24,.06)',color:'#f5d45b',fontSize:12,fontWeight:800,textDecoration:'none'}},'📎 View moderation attachment'+(pageBan.warning.attachment_name?' · '+pageBan.warning.attachment_name:''))
          )
        ),
        React.createElement("label", { style:{display:"flex",alignItems:"flex-start",gap:10,marginTop:16,padding:13,borderRadius:13,border:"1px solid rgba(255,255,255,.08)",background:"rgba(255,255,255,.02)",cursor:"pointer",fontSize:12,lineHeight:1.45} },
          React.createElement("input", { type:"checkbox", checked:warningChecked, onChange:e=>setWarningChecked(e.target.checked), style:{marginTop:2,accentColor:"#f5c518"} }),
          React.createElement("span", null, "I understand this warning and will avoid repeating the behavior described above.")
        ),
        React.createElement("button", { onClick:acknowledgeWarning, disabled:!warningChecked||acknowledgingWarning, style:{width:"100%",marginTop:14,minHeight:50,borderRadius:14,border:"1px solid rgba(245,197,24,.38)",background:warningChecked?"linear-gradient(135deg,#f5c518,#d9a900)":"linear-gradient(135deg,#4b4325,#332f20)",color:warningChecked?"#17130a":"#8f865d",fontSize:13,fontWeight:900,letterSpacing:.1,boxShadow:warningChecked?"0 8px 28px rgba(245,197,24,.18),inset 0 1px 0 rgba(255,255,255,.3)":"none",opacity:warningChecked?1:.55,cursor:warningChecked?"pointer":"not-allowed",transition:"all .18s ease"} }, acknowledgingWarning?"✓  Acknowledging…":"✓  Acknowledge warning")
      )
    );
  }

  if (pageBan?.banned) {
    const until = pageBan.expires_at ? new Date(pageBan.expires_at) : null;
    const type = String(pageBan.ban_type||'BAN').toUpperCase();
    const typeLabel = type==='IB' ? 'IP restriction' : type==='P' ? 'Permanent account restriction' : 'Account restriction';
    const isPermanent = !until;
    const now = new Date();
    const remainingMs = until ? Math.max(0, until.getTime() - now.getTime()) : 0;
    const remainingDays = until ? Math.floor(remainingMs / 86400000) : 0;
    const remainingHours = until ? Math.floor((remainingMs % 86400000) / 3600000) : 0;
    const countdown = isPermanent ? 'Permanent' : `${remainingDays}d ${remainingHours}h remaining`;
    const accountName = account?.username || account?.handle || 'Roblox Assets player';
    return React.createElement("div", { style:{minHeight:"100vh",position:"relative",overflow:"hidden",background:"#090b0f",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",padding:"28px 18px"} },
      React.createElement("div", { style:{position:"absolute",inset:0,background:"linear-gradient(135deg,rgba(226,35,26,.22),transparent 28%,transparent 70%,rgba(88,101,242,.12))",pointerEvents:"none"} }),
      React.createElement("div", { style:{position:"absolute",width:520,height:520,borderRadius:"50%",right:"-180px",top:"-230px",background:"rgba(226,35,26,.13)",filter:"blur(8px)",pointerEvents:"none"} }),
      React.createElement("div", { style:{position:"absolute",width:420,height:420,borderRadius:"50%",left:"-220px",bottom:"-240px",background:"rgba(75,91,255,.09)",filter:"blur(20px)",pointerEvents:"none"} }),
      React.createElement("div", { style:{position:"relative",width:"min(760px,100%)",borderRadius:26,overflow:"hidden",background:"linear-gradient(180deg,#171a21,#0e1117 62%,#0b0e13)",border:"1px solid rgba(255,255,255,.10)",boxShadow:"0 40px 120px rgba(0,0,0,.68)"} },
        React.createElement("div", { style:{height:8,background:"linear-gradient(90deg,#e2231a 0%,#ff4b3e 45%,#e2231a 100%)",boxShadow:"0 0 34px rgba(226,35,26,.65)"} }),
        React.createElement("div", { style:{padding:"24px 24px 26px"} },
          React.createElement("div", { style:{display:"flex",justifyContent:"space-between",gap:14,alignItems:"flex-start",flexWrap:"wrap"} },
            React.createElement("div", { style:{display:"flex",gap:14,alignItems:"center"} },
              React.createElement("div", { style:{width:64,height:64,borderRadius:16,display:"grid",placeItems:"center",fontSize:31,background:"linear-gradient(145deg,#282d38,#141820)",border:"1px solid rgba(255,255,255,.12)",boxShadow:"inset 0 1px 0 rgba(255,255,255,.07),0 14px 30px rgba(0,0,0,.3)"} }, "🚫"),
              React.createElement("div", null,
                React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".16em",fontWeight:950,color:"#ff7268"} }, "MODERATION NOTICE"),
                React.createElement("h1", { style:{margin:"3px 0 0",fontSize:"clamp(26px,5vw,36px)",lineHeight:1.05,letterSpacing:"-1px"} }, "Account Restricted")
              )
            ),
            null
          ),
          React.createElement("div", { style:{marginTop:22,padding:"14px 15px",borderRadius:14,background:"linear-gradient(135deg,rgba(226,35,26,.13),rgba(226,35,26,.035))",border:"1px solid rgba(226,35,26,.24)",color:"#ffd2ce",fontSize:13,lineHeight:1.55} },
            t.banBody||"Your access to this website is currently restricted due to a moderation action. Review the details below for more information."
          ),
          React.createElement("div", { style:{display:"grid",gridTemplateColumns:"minmax(0,1.2fr) minmax(0,.8fr)",gap:12,marginTop:14} },
            React.createElement("div", { style:{padding:16,borderRadius:16,background:"#0a0d12",border:"1px solid rgba(255,255,255,.08)"} },
              React.createElement("div", { style:{display:"flex",alignItems:"center",gap:10} },
                React.createElement("div", { style:{width:42,height:42,borderRadius:12,display:"grid",placeItems:"center",background:"linear-gradient(145deg,#303743,#171b22)",border:"1px solid rgba(255,255,255,.09)",fontWeight:950,fontSize:16} }, String(accountName).slice(0,1).toUpperCase()),
                React.createElement("div", null,
                  React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".10em",color:"#7f8998",fontWeight:900} }, "ACCOUNT"),
                  React.createElement("div", { style:{marginTop:3,fontWeight:900,fontSize:15} }, accountName)
                )
              ),
              React.createElement("div", { style:{marginTop:16,paddingTop:13,borderTop:"1px solid rgba(255,255,255,.07)"} },
                React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".10em",color:"#7f8998",fontWeight:900} }, "RESTRICTION TYPE"),
                React.createElement("div", { style:{marginTop:5,fontWeight:850} }, typeLabel)
              )
            ),
            React.createElement("div", { style:{padding:16,borderRadius:16,background:"linear-gradient(180deg,#10141b,#0b0e13)",border:"1px solid rgba(255,255,255,.08)"} },
              React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".10em",color:"#7f8998",fontWeight:900} }, t.banEnds||"RESTRICTION ENDS"),
              React.createElement("div", { style:{marginTop:8,fontSize:20,fontWeight:950,color:isPermanent?"#ff746a":"#fff"} }, isPermanent ? "Never" : until.toLocaleString()),
              React.createElement("div", { style:{marginTop:6,fontSize:11,color:isPermanent?"#ffaaa4":"#9da7b5",fontWeight:800} }, countdown)
            )
          ),
          React.createElement("div", { style:{marginTop:12,padding:17,borderRadius:16,background:"#0a0d12",border:"1px solid rgba(255,255,255,.08)"} },
            React.createElement("div", { style:{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",flexWrap:"wrap"} },
              React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".11em",fontWeight:950,color:"#7f8998"} }, t.banReason||"WHY THIS HAPPENED"),
              React.createElement("span", { style:{padding:"5px 8px",borderRadius:999,background:"rgba(226,35,26,.10)",border:"1px solid rgba(226,35,26,.22)",color:"#ffaaa4",fontSize:10,fontWeight:950} }, type)
            ),
            React.createElement("div", { style:{marginTop:8,color:"#eef1f5",fontSize:14,lineHeight:1.65,whiteSpace:"pre-wrap"}},pageBan.reason||"No reason provided"),
            React.createElement("div", { style:{marginTop:15,paddingTop:13,borderTop:"1px solid rgba(255,255,255,.07)"} },
              React.createElement("div", { style:{fontSize:10,textTransform:"uppercase",letterSpacing:".10em",fontWeight:900,color:"#7f8998"}}, "Moderated content"),
              React.createElement("div", { style:{marginTop:6,color:"#cfd5de",fontSize:13,lineHeight:1.55,whiteSpace:"pre-wrap"}},pageBan.offensive_item||"No specific item was recorded."),
              pageBan.attachment_key&&React.createElement("a",{href:'/api/moderation-attachment?key='+encodeURIComponent(pageBan.attachment_key),target:'_blank',rel:'noopener',style:{display:'inline-flex',alignItems:'center',gap:8,marginTop:13,padding:'10px 12px',borderRadius:10,border:'1px solid rgba(255,255,255,.10)',background:'#11161e',color:'#fff',fontSize:12,fontWeight:900,textDecoration:'none'}},'📎 View evidence'+(pageBan.attachment_name?' · '+pageBan.attachment_name:''))
            )
          ),
          React.createElement("div", { style:{display:"flex",gap:10,marginTop:14,flexWrap:"wrap"} },
            React.createElement("a", { href:"/support/", onClick:()=>window.rbxUISound?.open?.(), style:{flex:"1 1 220px",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:8,textDecoration:"none",padding:"12px 15px",borderRadius:11,background:"linear-gradient(180deg,#e2231a,#a91610)",border:"1px solid rgba(255,119,110,.32)",color:"#fff",fontWeight:950,fontSize:13,boxShadow:"0 12px 28px rgba(226,35,26,.22)"} },"💬 Contact Customer Support"),
            React.createElement("button", { type:"button", onClick:()=>{window.dispatchEvent(new Event('rbx-moderation-active'));}, style:{flex:"0 1 170px",padding:"12px 15px",borderRadius:11,background:"#151b23",border:"1px solid rgba(255,255,255,.10)",color:"#fff",fontWeight:850,fontSize:13} },"↻ Check status again")
          ),
          React.createElement("div", { style:{marginTop:15,padding:"11px 13px",borderRadius:12,background:"rgba(255,255,255,.025)",border:"1px solid rgba(255,255,255,.06)",textAlign:"center",fontSize:11,color:"#7b8695",lineHeight:1.55} },"Need to dispute this action? Open Customer Support and create a Ban Appeal ticket. Include your case details so the moderation team can review them."),
          React.createElement("div", { style:{marginTop:10,textAlign:"center",fontSize:10,color:"#4f5967",fontWeight:800,letterSpacing:".08em",textTransform:"uppercase"} },"Case state · active moderation")
        )
      )
    );
  }

  return React.createElement(
    "div",
    { style: { minHeight: "100vh", display: "flex", flexDirection: "column" } },
    account && React.createElement("div", { style: { maxWidth: 1200, width: "calc(100% - 40px)", margin: "16px auto 0", padding: "12px 16px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" } },
      React.createElement("span", null, `Hello again, ${account.username || account.handle || account.email || "User"}!`),
      isAdmin && React.createElement("button", {
        type: "button",
        onClick: triggerGlobalUpdate,
        disabled: releasingUpdate,
        style: {
          border: "1px solid rgba(226,35,26,.45)",
          borderRadius: 10,
          padding: "8px 12px",
          background: releaseResult && releaseResult.ok ? "rgba(52,199,89,.14)" : "rgba(226,35,26,.12)",
          color: releaseResult && releaseResult.ok ? "#5ee58a" : "#ff8179",
          font: "800 12px/1 'Segoe UI',Inter,system-ui,sans-serif",
          cursor: releasingUpdate ? "wait" : "pointer",
          opacity: releasingUpdate ? .7 : 1,
          transition: "transform .15s ease, background .15s ease, border-color .15s ease"
        }
      }, releasingUpdate ? "Releasing…" : (releaseResult ? (releaseResult.ok ? "✓ Released to everyone" : "Release failed") : "Release update")),
      isAdmin && releaseResult && React.createElement("span", { style: { width: "100%", fontSize: 12, fontWeight: 700, color: releaseResult.ok ? "#5ee58a" : "#ff8179" } }, releaseResult.text)
    ),
    React.createElement(Header, { t, lang, search, setSearch }),
    isMobile && !bannerDismissed && React.createElement(MobileBanner, { t, onDismiss: () => setBannerDismissed(true) }),

    React.createElement(
      "section",
      {
        style: {
          maxWidth: 1200,
          margin: "0 auto",
          padding: "28px 20px 0",
          width: "100%",
        },
      },
      React.createElement(
        "div",
        {
          className: "home-hero",
          style: {
            position: "relative",
            overflow: "hidden",
            background: "radial-gradient(circle at 88% 18%,rgba(255,255,255,.08),transparent 22%),radial-gradient(circle at 8% 100%,rgba(226,35,26,.13),transparent 34%),linear-gradient(135deg, rgba(226,35,26,0.16), rgba(226,35,26,0.025))",
            border: "1px solid rgba(226,35,26,0.28)",
            borderRadius: 22,
            padding: "30px 28px 24px",
            animation: "slideUp 0.5s ease",
            boxShadow: "0 24px 80px rgba(0,0,0,.24), inset 0 1px 0 rgba(255,255,255,.04)",
          },
        },
        React.createElement("div", { style:{position:"absolute",width:260,height:260,borderRadius:"50%",right:-100,top:-120,background:"rgba(226,35,26,.12)",filter:"blur(16px)",pointerEvents:"none"} }),
        React.createElement("div", { style:{position:"relative",display:"flex",justifyContent:"space-between",gap:24,alignItems:"flex-end",flexWrap:"wrap"} },
          React.createElement("div", { style:{minWidth:0,flex:"1 1 520px"} },
            React.createElement("div", { style:{display:"inline-flex",alignItems:"center",gap:8,padding:"7px 10px",borderRadius:999,border:"1px solid rgba(255,255,255,.10)",background:"rgba(255,255,255,.055)",fontSize:10,fontWeight:950,letterSpacing:".12em",textTransform:"uppercase"} },
              React.createElement("span", { style:{width:7,height:7,borderRadius:"50%",background:"#34c759",boxShadow:"0 0 14px rgba(52,199,89,.6)"} }), "ROBLOX ASSET VAULT"
            ),
            React.createElement("h1", { style:{margin:"13px 0 8px",fontSize:"clamp(28px,5vw,44px)",lineHeight:1.02,fontWeight:950,letterSpacing:"-1.2px"} }, t.siteName),
            React.createElement("p", { style:{margin:0,color:"#aeb6c0",fontSize:14.5,maxWidth:700,lineHeight:1.65} }, t.tagline),
            React.createElement("div", { style:{display:"flex",gap:9,flexWrap:"wrap",marginTop:18} },
              React.createElement("button", { type:"button", onClick:()=>document.getElementById('asset-library')?.scrollIntoView({behavior:'smooth',block:'start'}), style:{margin:0,padding:"11px 15px",borderRadius:11,fontWeight:950,background:"linear-gradient(180deg,#ff4b40,#c51b14)",color:"#fff",border:"1px solid rgba(255,255,255,.12)",boxShadow:"0 12px 26px rgba(226,35,26,.22)"} }, (window.uiText?.(lang,"BrowseAssets","Browse assets")||"Browse assets")+" →"),
              React.createElement("a", { href:"/support/", style:{display:"inline-flex",alignItems:"center",justifyContent:"center",padding:"11px 15px",borderRadius:11,textDecoration:"none",fontWeight:900,background:"rgba(255,255,255,.045)",border:"1px solid rgba(255,255,255,.10)",color:"#fff"} }, "💬 "+(window.uiText?.(lang,"NeedHelp","Need help?")||"Need help?"))
            )
          ),
          React.createElement("div", { style:{display:"grid",gridTemplateColumns:"repeat(2,minmax(100px,1fr))",gap:8,minWidth:235} },
            React.createElement("div", { style:{padding:12,borderRadius:14,background:"rgba(8,11,15,.62)",border:"1px solid rgba(255,255,255,.08)",backdropFilter:"blur(8px)"} },React.createElement("b",{style:{display:"block",fontSize:20}},String(allFiles.length + PREMIUM_FILES.length)),React.createElement("span",{style:{fontSize:10,color:"#7f8998"}},"Assets")),
            React.createElement("div", { style:{padding:12,borderRadius:14,background:"rgba(8,11,15,.62)",border:"1px solid rgba(255,255,255,.08)",backdropFilter:"blur(8px)"} },React.createElement("b",{style:{display:"block",fontSize:20}},String(websiteCategories.length-1)),React.createElement("span",{style:{fontSize:10,color:"#7f8998"}},"Categories")),
            React.createElement("div", { style:{padding:12,borderRadius:14,background:"rgba(8,11,15,.62)",border:"1px solid rgba(255,255,255,.08)",backdropFilter:"blur(8px)"} },React.createElement("b",{style:{display:"block",fontSize:20}},String(PREMIUM_FILES.length)),React.createElement("span",{style:{fontSize:10,color:"#7f8998"}},"Premium")),
            React.createElement("div", { style:{padding:12,borderRadius:14,background:"rgba(8,11,15,.62)",border:"1px solid rgba(255,255,255,.08)",backdropFilter:"blur(8px)"} },React.createElement("b",{style:{display:"block",fontSize:20}},account?"✓":"○"),React.createElement("span",{style:{fontSize:10,color:"#7f8998"}},account?"Signed in":"Guest"))
          )
        )
      )
    ),

    React.createElement("section", { style:{maxWidth:1200,width:"100%",margin:"12px auto 0",padding:"0 20px"} },
      React.createElement("div", { className:"prestige-status-grid", style:{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:9} },
        React.createElement("button", { type:"button", onClick:()=>{setCategory("favorites");document.getElementById("asset-library")?.scrollIntoView({behavior:"smooth",block:"start"})}, style:{margin:0,textAlign:"left",padding:"13px 14px",borderRadius:14,border:"1px solid rgba(255,255,255,.08)",background:"linear-gradient(145deg,#121922,#0b1016)",color:"#fff"} }, React.createElement("span",{style:{fontSize:10,color:"#7f8998",fontWeight:900,textTransform:"uppercase",letterSpacing:".1em"}},"SAVED"), React.createElement("b",{style:{display:"block",fontSize:19,marginTop:3}},String(favorites.size)), React.createElement("span",{style:{fontSize:10,color:"#707b8b"}},"Favorites")),
        React.createElement("div", { style:{padding:"13px 14px",borderRadius:14,border:"1px solid rgba(255,255,255,.08)",background:"linear-gradient(145deg,#121922,#0b1016)"} }, React.createElement("span",{style:{fontSize:10,color:"#7f8998",fontWeight:900,textTransform:"uppercase",letterSpacing:".1em"}},"COINS"), React.createElement("b",{style:{display:"block",fontSize:19,marginTop:3}},account?Number(account.coins||0).toLocaleString():"—"), React.createElement("span",{style:{fontSize:10,color:"#707b8b"}},account?"Balance":"Sign in to track")),
        React.createElement("div", { style:{padding:"13px 14px",borderRadius:14,border:"1px solid rgba(255,255,255,.08)",background:"linear-gradient(145deg,#121922,#0b1016)"} }, React.createElement("span",{style:{fontSize:10,color:"#7f8998",fontWeight:900,textTransform:"uppercase",letterSpacing:".1em"}},"PREMIUM"), React.createElement("b",{style:{display:"block",fontSize:19,marginTop:3}},account?.premium_access?"ACTIVE":"LOCKED"), React.createElement("span",{style:{fontSize:10,color:account?.premium_access?"#6de0a5":"#707b8b"}},account?.premium_access?"All premium unlocked":"70 Coins to unlock")),
        React.createElement("div", { style:{padding:"13px 14px",borderRadius:14,border:"1px solid rgba(255,255,255,.08)",background:"linear-gradient(145deg,#121922,#0b1016)"} }, React.createElement("span",{style:{fontSize:10,color:"#7f8998",fontWeight:900,textTransform:"uppercase",letterSpacing:".1em"}},"STREAK"), React.createElement("b",{style:{display:"block",fontSize:19,marginTop:3}},account?String(account.streak||0):"—"), React.createElement("span",{style:{fontSize:10,color:"#707b8b"}},"Weekly claims"))
      )
    ),

    React.createElement(PremiumPanel, {
      account,
      accountLoading,
      unlocking,
      onLogin: () => { window.location.href = "/login?next=/"; },
      onUnlock: unlockPremium,
      onClaimWeekly: claimWeeklyReward,
      claimingWeekly,
      managedAssets,
    }),

    React.createElement(CategoryTabs, { t, active: category, setActive: setCategory, counts, categories: [...websiteCategories, "favorites"] }),
    React.createElement("div", { style:{maxWidth:1200,width:"100%",margin:"8px auto 0",padding:"0 20px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"} },
      React.createElement("div", { style:{fontSize:11,color:"#748091"} }, `${filtered.length} result${filtered.length===1?"":"s"}${favorites.size?` · ${favorites.size} saved`:""} · Press / to search · F for favorites`),
      React.createElement("select", { value:sortMode, onChange:e=>setSortMode(e.target.value), style:{background:"#10151c",color:"#fff",border:"1px solid var(--border)",borderRadius:10,padding:"9px 11px",fontSize:12,fontWeight:800} },
        React.createElement("option", {value:"featured"}, "Featured"),
        React.createElement("option", {value:"newest"}, "Newest"),
        React.createElement("option", {value:"premium"}, "Premium first"),
        React.createElement("option", {value:"price-low"}, "Price: low → high"),
        React.createElement("option", {value:"price-high"}, "Price: high → low"),
        React.createElement("option", {value:"favorites"}, "Favorites first")
      )
    ),

    React.createElement(
      "main",
      { id:"asset-library", style: { flex: 1, maxWidth: 1200, margin: "0 auto", padding: "16px 20px 40px", width: "100%" } },
      filtered.length === 0
        ? React.createElement(
            "div",
            {
              style: {
                textAlign: "center",
                color: "var(--muted)",
                padding: "60px 20px",
                fontSize: 14,
              },
            },
            t.noResults
          )
        : React.createElement(
            "div",
            {
              style: {
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
                gap: 16,
              },
            },
            filtered.map((f) =>
              React.createElement(FileCard, {
                key: f.id,
                t,
                lang,
                file: f,
                onDownload: handleDownloadClick,
                downloadingId,
                account,
                purchased,
                onPurchase: purchaseAsset,
                categoryLabels,
                favorite: favorites.has(String(f.id)),
                onToggleFavorite: toggleFavorite,
              })
            )
          )
    ),

    React.createElement(
      "footer",
      {
        style: {
          borderTop: "1px solid var(--border)",
          padding: "18px 20px",
          textAlign: "center",
          color: "var(--muted)",
          fontSize: 12.5,
        },
      },
      React.createElement(React.Fragment, null,
        React.createElement("span", null, t.footerText),
        React.createElement("button", {
          id: "rbx-install-app-button",
          type: "button",
          onClick: async () => {
            const promptEvent = window.__rbxInstallPrompt;
            if (promptEvent) {
              promptEvent.prompt();
              const choice = await promptEvent.userChoice.catch(() => null);
              if (choice?.outcome === "accepted") {
                window.__rbxInstallPrompt = null;
                const installButton = document.getElementById("rbx-install-app-button");
                if (installButton) installButton.style.display = "none";
              }
              return;
            }
            const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
            const isStandalone = window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone;
            if (isStandalone) {
              alert("The website is already installed as an app.");
            } else if (isIOS) {
              alert("To install the app on iPhone or iPad, tap Share, then choose 'Add to Home Screen'.");
            } else {
              alert("Your browser doesn't currently offer installation. Try opening the site in Chrome or Edge, then use the browser's Install option.");
            }
          },
          style: {
            display: ((window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone) ? "none" : "block"),
            margin: "12px auto 0",
            padding: "9px 16px",
            borderRadius: 9,
            border: "1px solid rgba(226,35,26,.55)",
            background: "linear-gradient(180deg,#e2231a,#b91913)",
            color: "#fff",
            fontWeight: 800,
            fontSize: 12,
            boxShadow: "0 8px 20px rgba(226,35,26,.18)",
          },
        }, "Install App")
      )
    ),

    /* Legacy RiskModal intentionally disabled; mobile downloads now use the Prestige device modal. */

    resultModal && React.createElement(ResultModal, { t, result: resultModal, onClose: () => setResultModal(null) }),

    React.createElement(Toast, { toast, onDone: () => setToast(null) })
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));

// Record the first time a signed-in user opens the installed app.
// The server makes this idempotent, so normal website visits never create an install event.
// In an installed PWA the auth session can finish restoring shortly after the
// page starts. Retry after startup so the install is attached to the signed-in
// account instead of being left as a guest install.
(()=>{
  const reportInstall=async()=>{
    try{
      const standalone=window.matchMedia?.('(display-mode: standalone)').matches||window.navigator.standalone;
      if(!standalone)return;
      const auth=window.hatchable?.auth;
      if(auth){try{await auth.getSession();}catch(_){}}
      await fetch('/api/account/app-install?ts='+Date.now(),{method:'POST',credentials:'include',cache:'no-store',headers:{'Content-Type':'application/json','Cache-Control':'no-cache'},body:'{}'});
    }catch(_){ }
  };
  reportInstall();
  setTimeout(reportInstall,1500);
  setTimeout(reportInstall,5000);
})();