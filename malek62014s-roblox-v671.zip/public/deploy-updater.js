(() => {
  if (window.__malekDeployUpdaterLoaded) return;
  window.__malekDeployUpdaterLoaded = true;

  const POLL_MS = 1000;
  const SESSION_STARTED_AT = Date.now();
  let lastSeen = null;
  let updateShown = false;
  const SEEN_KEY = 'malek-deploy-update-seen';
  const ACK_PARAM = '__update_ack';
  let latestRelease = { title: '', summary: '', kind: 'Update' };

  const getSeenUpdate = () => {
    try {
      return localStorage.getItem(SEEN_KEY) || '';
    } catch (_) {
      return '';
    }
  };

  const hasSeenUpdate = (version) => {
    const current = String(version || '');
    const seen = getSeenUpdate();
    if (!seen) return false;
    const currentNumber = Number(current);
    const seenNumber = Number(seen);
    if (Number.isFinite(currentNumber) && Number.isFinite(seenNumber)) return currentNumber <= seenNumber;
    return seen === current;
  };

  const markUpdateSeen = (version) => {
    try {
      localStorage.setItem(SEEN_KEY, String(version));
    } catch (_) {}
  };

  const css = `
    #malek-deploy-update{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:18px;background:rgba(3,6,10,.42);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);pointer-events:none;opacity:0;transform:none;transition:opacity .28s ease}
    #malek-deploy-update.is-visible{opacity:1;transform:scale(1);pointer-events:auto}
    #malek-deploy-update .malek-update-card{width:min(520px,calc(100vw - 36px));display:flex;align-items:center;gap:15px;padding:20px;border:1px solid rgba(255,255,255,.13);border-radius:20px;background:linear-gradient(135deg,rgba(21,26,34,.985),rgba(10,14,19,.985));box-shadow:0 28px 90px rgba(0,0,0,.68),0 0 0 1px rgba(226,35,26,.08);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);pointer-events:auto}
    #malek-deploy-update .malek-update-icon{width:44px;height:44px;flex:0 0 44px;border-radius:14px;display:grid;place-items:center;background:linear-gradient(145deg,#ff4b42,#b51d17);color:#fff;font-size:20px;font-weight:950;box-shadow:0 10px 28px rgba(226,35,26,.26)}
    #malek-deploy-update .malek-update-copy{min-width:0;flex:1}
    #malek-deploy-update .malek-update-title{font-size:14px;font-weight:950;color:#fff;letter-spacing:-.01em}
    #malek-deploy-update .malek-update-text{margin-top:4px;font-size:12px;line-height:1.5;color:#9ea8b7;white-space:pre-wrap;overflow-wrap:anywhere;max-height:48vh;overflow:auto}
    #malek-deploy-update .malek-update-btn{flex:0 0 auto;border:1px solid rgba(255,255,255,.08);border-radius:11px;padding:10px 14px;background:#e2231a;color:#fff;font:800 12px/1 'Segoe UI',Inter,system-ui,sans-serif;cursor:pointer;box-shadow:0 9px 22px rgba(226,35,26,.22);transition:transform .16s ease,filter .16s ease,box-shadow .16s ease}
    #malek-deploy-update .malek-update-btn:hover{filter:brightness(1.08);transform:translateY(-1px);box-shadow:0 12px 26px rgba(226,35,26,.3)}
    #malek-deploy-update .malek-update-btn:active{transform:translateY(0) scale(.97)}
    @media(max-width:620px){#malek-deploy-update{inset:0;padding:14px}#malek-deploy-update .malek-update-card{align-items:flex-start;padding:15px;flex-wrap:wrap}.malek-update-icon{margin-top:1px}#malek-deploy-update .malek-update-copy{flex:1 1 calc(100% - 60px)}#malek-deploy-update .malek-update-btn{flex:1 1 100%;width:100%;margin-left:59px;padding:12px}}
    @media(prefers-reduced-motion:reduce){#malek-deploy-update{transition:none}}
  `;

  const addStyles = () => {
    if (document.getElementById('malek-deploy-update-style')) return;
    const style = document.createElement('style');
    style.id = 'malek-deploy-update-style';
    style.textContent = css;
    document.head.appendChild(style);
  };

  const build = () => {
    if (document.getElementById('malek-deploy-update')) return document.getElementById('malek-deploy-update');
    addStyles();
    const wrap = document.createElement('div');
    wrap.id = 'malek-deploy-update';
    wrap.setAttribute('role', 'status');
    wrap.setAttribute('aria-live', 'polite');
    wrap.innerHTML = `
      <div class="malek-update-card">
        <div class="malek-update-icon">↻</div>
        <div class="malek-update-copy">
          <div class="malek-update-title">Update Released</div>
          <div class="malek-update-text">Refresh the website to apply the latest update.</div>
        </div>
        <button class="malek-update-btn" type="button">Refresh website</button>
      </div>
    `;
    const releaseTitle = wrap.querySelector('.malek-update-title');
    const releaseText = wrap.querySelector('.malek-update-text');
    if (releaseTitle) releaseTitle.textContent = latestRelease.title
      ? ((latestRelease.kind && latestRelease.kind !== 'Update' ? latestRelease.kind + ' · ' : '') + latestRelease.title)
      : 'Update Released';
    if (releaseText) releaseText.textContent = latestRelease.summary
      ? latestRelease.summary + '\n\nRefresh the website to apply this update.'
      : 'Refresh the website to apply the latest update.';
    wrap.querySelector('.malek-update-btn')?.addEventListener('click', () => {
      const acknowledged = String(lastSeen || getSeenUpdate() || '');
      if (acknowledged) markUpdateSeen(acknowledged);
      const url = new URL(window.location.href);
      url.searchParams.delete('__update_ack');
      if (acknowledged) url.searchParams.set(ACK_PARAM, acknowledged);
      url.searchParams.set('__update', Date.now().toString(36));
      window.location.replace(url.toString());
    });
    (document.body || document.documentElement).appendChild(wrap);
    return wrap;
  };

  const hide = () => {
    const el = document.getElementById('malek-deploy-update');
    if (el) el.classList.remove('is-visible');
  };

  const show = (version) => {
    if (document.body?.hasAttribute('data-moderation-lock')) return;
    if (updateShown || hasSeenUpdate(version)) return;
    updateShown = true;
    build();
    requestAnimationFrame(() => document.getElementById('malek-deploy-update')?.classList.add('is-visible'));
  };

  document.addEventListener('keydown', (event) => {
    const el = document.getElementById('malek-deploy-update');
    if (!el?.classList.contains('is-visible')) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);

  const check = async () => {
    try {
      if (document.body?.hasAttribute('data-moderation-lock')) {
        hide();
        return;
      }
      const r = await fetch(`/api/deploy-version?check=${Date.now()}`, {
        cache: 'no-store',
        credentials: 'same-origin',
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (!r.ok) return;
      const data = await r.json().catch(() => null);
      latestRelease = {
        title: String(data?.title || ''),
        summary: String(data?.summary || ''),
        kind: String(data?.kind || 'Update')
      };
      const version = String(data?.version || '');
      const releaseAt = Date.parse(String(data?.updated_at || ''));
      if (!version) return;
      const urlAck = new URL(window.location.href).searchParams.get(ACK_PARAM);
      const remembered = getSeenUpdate();
      if (urlAck && urlAck === version && remembered !== version) markUpdateSeen(version);
      if (lastSeen === null) {
        const rememberedNumber = Number(remembered);
        const versionNumber = Number(version);
        const missedWhileOffline = Boolean(remembered) && Number.isFinite(versionNumber) && Number.isFinite(rememberedNumber) && versionNumber > rememberedNumber;
        const releasedSinceOpen = !remembered && Number.isFinite(releaseAt) && releaseAt > SESSION_STARTED_AT;
        lastSeen = version;
        if (hasSeenUpdate(version)) return;
        // Show the latest release once when it was published after the user's
        // last acknowledged release, even if they were completely offline.
        if (missedWhileOffline || releasedSinceOpen) show(version);
        return;
      }
      if (version === lastSeen) return;
      if (hasSeenUpdate(version)) {
        lastSeen = version;
        return;
      }
      lastSeen = version;
      show(version);
    } catch (_) {}
  };

  const start = () => {
    check();
    window.setInterval(check, POLL_MS);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') check();
    });
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();