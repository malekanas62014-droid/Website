(function(){
  window.rbxNotificationSW={
    registration:null,
    async register(){
      if(!('serviceWorker' in navigator))return null;
      try{
        const reg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});
        await navigator.serviceWorker.ready;
        this.registration=reg;
        return reg;
      }catch(_){return null;}
    },
    async show(title,body,tag){
      if(!('Notification' in window)||Notification.permission!=='granted')return false;
      try{
        const reg=this.registration||await navigator.serviceWorker?.ready;
        if(reg?.showNotification){
          await reg.showNotification(String(title||"Malek62014's Roblox Assets"),{body:String(body||''),tag:String(tag||'malek-notification'),renotify:false});
          return true;
        }
      }catch(_){ }
      try{new Notification(String(title||"Malek62014's Roblox Assets"),{body:String(body||''),tag:String(tag||'malek-notification'),renotify:false});return true;}catch(_){return false;}
    }
  };
})();