(() => {
  'use strict';

  const SEEN_KEY = 'rbx-english-only-notice-version-v1';
  const DEFAULT_VERSION = 0;
  let open = false;

  function seenVersion(){
    try{return Number(localStorage.getItem(SEEN_KEY)||'-1');}catch(_){return -1;}
  }

  function saveSeen(version){
    try{localStorage.setItem(SEEN_KEY,String(version));}catch(_){ }
  }

  function showNotice(version){
    if(open)return;
    open=true;
    const old=document.getElementById('english-only-notice');
    if(old)old.remove();

    const style=document.createElement('style');
    style.id='english-only-notice-style';
    style.textContent=`
      @keyframes eonFade{from{opacity:0}to{opacity:1}}
      @keyframes eonIn{from{opacity:0;transform:translateY(14px) scale(.985)}to{opacity:1;transform:translateY(0) scale(1)}}
      #english-only-notice{position:fixed;inset:0;z-index:30000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.78);backdrop-filter:blur(16px);animation:eonFade .16s ease}
      #english-only-notice .eon-card{width:min(560px,100%);padding:26px;border-radius:22px;border:1px solid rgba(226,35,26,.28);background:radial-gradient(circle at 100% 0,rgba(226,35,26,.17),transparent 42%),linear-gradient(180deg,#171c24,#0b0f14);box-shadow:0 35px 120px rgba(0,0,0,.8),0 0 75px rgba(226,35,26,.15);animation:eonIn .2s ease}
      #english-only-notice .eon-badge{display:inline-flex;align-items:center;padding:6px 9px;border-radius:999px;background:rgba(226,35,26,.1);border:1px solid rgba(226,35,26,.24);color:#ffaaa4;font-size:9px;font-weight:950;letter-spacing:.1em}
      #english-only-notice h2{margin:13px 0 9px;font-size:28px;letter-spacing:-.7px;color:#fff}
      #english-only-notice p{margin:0;color:#a4adba;line-height:1.65;font-size:13px}
      #english-only-notice .eon-actions{display:flex;justify-content:flex-end;margin-top:20px}
      #english-only-notice button{border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px 15px;font-weight:900;cursor:pointer;background:linear-gradient(180deg,#ef3c33,#c21e17);color:#fff;box-shadow:0 10px 25px rgba(226,35,26,.2)}
    `;
    document.head.appendChild(style);

    const overlay=document.createElement('div');
    overlay.id='english-only-notice';
    overlay.setAttribute('role','dialog');
    overlay.setAttribute('aria-modal','true');
    overlay.innerHTML=`<div class="eon-card">
      <div class="eon-badge">WEBSITE NOTICE</div>
      <h2>English Only</h2>
      <p>This website is English-only. Members must use English when using the website and its community features.</p>
      <div class="eon-actions"><button type="button" id="english-only-notice-ok">Got it</button></div>
    </div>`;
    document.body.appendChild(overlay);

    const close=()=>{
      saveSeen(version);
      overlay.remove();
      open=false;
    };
    overlay.querySelector('#english-only-notice-ok').addEventListener('click',close);
    overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
  }

  async function check(){
    const local=seenVersion();
    let version=DEFAULT_VERSION;
    try{
      const r=await fetch('/api/english-only-notice?ts='+Date.now(),{cache:'no-store',credentials:'include',headers:{'Cache-Control':'no-cache'}});
      if(r.ok){const d=await r.json().catch(()=>({}));version=Math.max(DEFAULT_VERSION,Number(d.version||0));}
    }catch(_){ }
    if(local<version)showNotice(version);
  }

  function init(){
    try{
      localStorage.removeItem('rbx-assets-language');
      localStorage.removeItem('rbx-assets-locale');
      localStorage.removeItem('rbx-assets-dynamic-language');
    }catch(_){ }
    check();
    setInterval(check,20000);
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();