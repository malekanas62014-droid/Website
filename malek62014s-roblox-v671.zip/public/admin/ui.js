(()=>{
  if(window.__malekAdminUI)return;
  const esc=v=>String(v??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  function ensure(){
    if(document.getElementById('malek-ui-style'))return;
    const s=document.createElement('style');s.id='malek-ui-style';s.textContent=`
      .malek-ui-layer{position:fixed;inset:0;z-index:30000;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(0,0,0,.78);backdrop-filter:blur(14px)}
      .malek-ui-layer[hidden]{display:none}.malek-ui-card{width:min(470px,100%);background:radial-gradient(circle at 100% 0,rgba(226,35,26,.11),transparent 32%),linear-gradient(180deg,#171d26,#0b1016);border:1px solid rgba(255,255,255,.12);border-radius:22px;box-shadow:0 40px 140px rgba(0,0,0,.78),0 0 0 1px rgba(226,35,26,.04);padding:22px;animation:malekUiIn .18s ease}
      .malek-ui-icon{width:44px;height:44px;border-radius:13px;display:grid;place-items:center;background:rgba(226,35,26,.1);border:1px solid rgba(226,35,26,.22);font-size:20px;margin-bottom:12px}.malek-ui-icon.neutral{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.1)}
      .malek-ui-card h3{margin:0;font-size:20px;letter-spacing:-.3px}.malek-ui-card p{margin:6px 0 0;color:#8793a2;font-size:12px;line-height:1.5}.malek-ui-label{display:block;margin:16px 0 7px;color:#b4becb;font-size:11px;font-weight:850}.malek-ui-input{width:100%;padding:12px 13px;border-radius:11px;border:1px solid #344050;background:#080d12;color:#fff;outline:none;font:inherit}.malek-ui-input:focus{border-color:#e2231a;box-shadow:0 0 0 4px rgba(226,35,26,.1)}.malek-ui-error{display:none;margin-top:10px;padding:10px 12px;border-radius:11px;background:rgba(255,69,58,.08);border:1px solid rgba(255,69,58,.2);color:#ffb1ab;font-size:11px}.malek-ui-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:18px}.malek-ui-btn{border:1px solid #354252;border-radius:10px;padding:10px 13px;background:linear-gradient(180deg,#1c2530,#131922);color:#e7ecf2;font-weight:850;cursor:pointer}.malek-ui-btn.primary{background:linear-gradient(180deg,#f0443b,#c51e17);border-color:rgba(255,255,255,.08);color:#fff}.malek-ui-btn.danger{background:linear-gradient(180deg,#ff5149,#cc211a);color:#fff}.malek-ui-toast{position:fixed;right:18px;bottom:18px;z-index:31000;min-width:min(360px,calc(100vw - 36px));padding:13px 15px;border-radius:14px;background:linear-gradient(180deg,#171f29,#0d131a);border:1px solid #394858;color:#fff;box-shadow:0 22px 70px rgba(0,0,0,.55);animation:malekToastIn .18s ease;font-size:12px}.malek-ui-toast.error{border-color:rgba(255,69,58,.35);box-shadow:0 22px 70px rgba(255,69,58,.08),0 22px 70px rgba(0,0,0,.55)}.malek-ui-toast.success{border-color:rgba(53,208,127,.3)}
      @keyframes malekUiIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}@keyframes malekToastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
    `;document.head.appendChild(s);
  }
  const waitBody=fn=>document.body?fn():document.addEventListener('DOMContentLoaded',fn,{once:true});
  function dialog({title,message='',label='',value='',placeholder='',confirmText='Continue',cancelText='Cancel',danger=false,ask=false}){
    return new Promise(resolve=>waitBody(()=>{
      ensure();
      const ov=document.createElement('div');ov.className='malek-ui-layer';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');
      ov.innerHTML=`<div class="malek-ui-card"><div class="malek-ui-icon ${danger?'':'neutral'}">${danger?'⚠️':ask?'✎':'✓'}</div><h3>${esc(title)}</h3><p>${esc(message)}</p>${ask?`<label class="malek-ui-label">${esc(label||'Value')}</label><input class="malek-ui-input" id="malek-ui-input" value="${esc(value)}" placeholder="${esc(placeholder)}" autocomplete="off">`:''}<div class="malek-ui-error" id="malek-ui-error"></div><div class="malek-ui-actions"><button type="button" class="malek-ui-btn" data-cancel>${esc(cancelText)}</button><button type="button" class="malek-ui-btn ${danger?'danger':'primary'}" data-ok>${esc(confirmText)}</button></div></div>`;
      document.body.appendChild(ov);
      const finish=v=>{ov.remove();resolve(v)};
      ov.querySelector('[data-cancel]').onclick=()=>finish(ask?null:false);
      ov.querySelector('[data-ok]').onclick=()=>finish(ask?ov.querySelector('#malek-ui-input').value:true);
      ov.onclick=e=>{if(e.target===ov)finish(ask?null:false)};
      ov.addEventListener('keydown',e=>{if(e.key==='Escape')finish(ask?null:false);if(e.key==='Enter'&&ask)finish(ov.querySelector('#malek-ui-input').value) });
      ov.tabIndex=-1;ov.focus();
      if(ask)setTimeout(()=>{const i=ov.querySelector('#malek-ui-input');i.focus();i.select()},30);
    }));
  }
  const api={
    confirm:opts=>dialog({...opts}),
    prompt:opts=>dialog({...opts,ask:true,title:opts.title||'Enter a value'}),
    alert:opts=>dialog({title:opts.title||'Notice',message:opts.message||'',confirmText:opts.confirmText||'OK'}),
    error:(message,title='Something went wrong')=>{toast(message,'error',title)},
    success:(message,title='Done')=>{toast(message,'success',title)},
    toast:(message,type='info',title='')=>toast(message,type,title)
  };
  function toast(message,type='info',title=''){waitBody(()=>{ensure();const el=document.createElement('div');el.className='malek-ui-toast '+(type==='error'||type==='success'?type:'');el.innerHTML=(title?`<b style="display:block;margin-bottom:3px">${esc(title)}</b>`:'')+esc(message);document.body.appendChild(el);setTimeout(()=>el.remove(),3600)})}
  window.__malekAdminUI=true;window.adminDialog=api;
  const nativeAlert=window.alert;window.alert=(message)=>toast(String(message??''),'error','Notice');
  window.addEventListener('error',e=>{const m=String(e.message||'');if(/Cannot set properties of null.*onclick/i.test(m)){toast('A page control failed to initialize. The interface has protected itself from the error.','error','UI initialization error')}});
  ensure();
})();