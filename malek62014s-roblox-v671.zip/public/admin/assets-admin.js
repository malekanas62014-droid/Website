(()=>{
  const root=document.getElementById('admin-assets');
  if(!root)return;
  const esc=v=>String(v??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  const api=(p,o)=>fetch('/api/'+p,o).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d});
  let rows=[];let premiumPage=1,basicPage=1;const PAGE_SIZE=5;const collapsed={premium:false,basic:false};
  const isPremium=a=>{const v=a?.premium;return v===true||v===1||String(v).trim().toLowerCase()==='true'||String(v).trim()==='1'||String(v).trim().toLowerCase()==='premium'||String(a?.type||'').trim().toLowerCase()==='premium'||String(a?.asset_type||'').trim().toLowerCase()==='premium'};
  function ensureModalStyles(){
    if(document.getElementById('admin-tool-modal-style'))return;
    const s=document.createElement('style');s.id='admin-tool-modal-style';s.textContent=`
      .tool-overlay{position:fixed;inset:0;z-index:1200;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.74);backdrop-filter:blur(10px)}
      .tool-overlay.open{display:flex;animation:adminFade .16s ease}
      .tool-modal{width:min(600px,100%);max-height:min(760px,calc(100vh - 40px));overflow:auto;background:linear-gradient(180deg,#171c24,#10141a);border:1px solid #343e4c;border-radius:20px;box-shadow:0 30px 90px rgba(0,0,0,.58);padding:22px;animation:modalIn .2s ease}
      .tool-modal h3{margin:0;font-size:22px;letter-spacing:-.3px}.tool-modal .tool-sub{margin:6px 0 18px;color:var(--muted);font-size:13px;line-height:1.5}
      .tool-label{display:block;color:#aeb7c4;font-size:12px;font-weight:700;margin:0 0 7px}.tool-input,.tool-modal textarea{width:100%;background:#0b0f14;color:#fff;border:1px solid var(--border2);border-radius:11px;padding:12px;outline:none}.tool-input:focus,.tool-modal textarea:focus{border-color:rgba(226,35,26,.8);box-shadow:0 0 0 3px rgba(226,35,26,.12)}
      .tool-help{font-size:11px;color:#778293;line-height:1.45;margin-top:7px}.tool-preview{margin-top:14px;padding:12px;border-radius:12px;background:#0c1117;border:1px solid var(--border);color:#cbd2dc}.tool-preview strong{color:#fff}
      .tool-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}.tool-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:20px}.tool-error{display:none;margin-top:12px;padding:10px 12px;border-radius:10px;background:rgba(255,69,58,.08);border:1px solid rgba(255,69,58,.2);color:#ffb0aa;font-size:12px}
      .cat-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:10px}.cat-choice{display:flex;align-items:center;gap:9px;padding:10px 11px;border:1px solid var(--border2);border-radius:11px;background:#0c1117;cursor:pointer;transition:.15s ease}.cat-choice:hover{border-color:#4a5667;transform:translateY(-1px)}.cat-choice input{accent-color:var(--red)}.cat-choice span{font-size:12px}.switch-line{display:flex;align-items:center;justify-content:space-between;margin-top:15px;padding:12px;border:1px solid var(--border);border-radius:11px;background:#0c1117}.switch-line small{display:block;color:var(--muted);margin-top:3px}.switch-line input{width:18px;height:18px;accent-color:var(--red)}
      @media(max-width:620px){.tool-row,.cat-grid{grid-template-columns:1fr}}
    `;document.head.appendChild(s);
  }
  ensureModalStyles();
  const modalState={resolve:null};
  function closeTool(value=null){const o=document.getElementById('admin-tool-modal');if(o){o.classList.remove('open');o.setAttribute('aria-hidden','true')}if(modalState.resolve){const r=modalState.resolve;modalState.resolve=null;r(value)}}
  function openTool({title,sub,body,confirmText='Save',danger=false,validate,noChangeText,noChangeValue,afterRender}){
    let overlay=document.getElementById('admin-tool-modal');
    if(!overlay){overlay=document.createElement('div');overlay.id='admin-tool-modal';overlay.className='tool-overlay';overlay.setAttribute('aria-hidden','true');overlay.innerHTML='<div class="tool-modal" role="dialog" aria-modal="true"><h3 id="tool-title"></h3><div id="tool-sub" class="tool-sub"></div><div id="tool-body"></div><div id="tool-error" class="tool-error"></div><div class="tool-footer"><button type="button" class="secondary" id="tool-cancel">Cancel</button><button type="button" class="secondary" id="tool-nochange" style="display:none"></button><button type="button" id="tool-confirm"></button></div></div>';document.body.appendChild(overlay);overlay.addEventListener('click',e=>{if(e.target===overlay)closeTool(null)});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay.classList.contains('open'))closeTool(null)});}
    document.getElementById('tool-title').textContent=title;document.getElementById('tool-sub').textContent=sub||'';document.getElementById('tool-body').innerHTML=body;const err=document.getElementById('tool-error');err.style.display='none';err.textContent='';const confirm=document.getElementById('tool-confirm');confirm.textContent=confirmText;confirm.style.background=danger?'linear-gradient(180deg,#ff5a52,#d91f17)':'';
    const noChange=document.getElementById('tool-nochange');if(noChange){noChange.style.display=noChangeText?'inline-flex':'none';noChange.textContent=noChangeText||'';noChange.onclick=()=>closeTool(noChangeValue===undefined?{fileOnly:true}:noChangeValue)};
    const cancel=document.getElementById('tool-cancel');if(cancel)cancel.onclick=()=>closeTool(null);
    if(confirm)confirm.onclick=()=>{try{const value=validate?validate():{};if(value===false)return;closeTool(value)}catch(e){err.textContent=e.message||'Please check the fields.';err.style.display='block'}};
    overlay.classList.add('open');overlay.setAttribute('aria-hidden','false');
    if(typeof afterRender==='function'){try{afterRender(overlay)}catch(_e){}}
    const first=overlay.querySelector('input,textarea,select');if(first)setTimeout(()=>first.focus(),30);
    return new Promise(resolve=>{modalState.resolve=resolve});
  }
  const card=a=>`<div class="admin-asset"><div><b>${esc(a.name)}</b><div class="muted">${esc(a.category||'Everything')} · ${isPremium(a)?'💎 Premium':'Basic'} · ${isPremium(a)?'Premium price: '+esc(a.premium_price??0):'Basic price: '+esc(a.basic_price??0)}</div></div><div class="admin-actions"><button data-id="${a.id}" data-a="update">Update File</button><button data-id="${a.id}" data-a="${a.disabled?'enable':'disable'}">${a.disabled?'Enable':'Disable'}</button><button data-id="${a.id}" data-a="remove">Remove from page</button><button data-id="${a.id}" data-a="price">Change price</button><button data-id="${a.id}" data-a="category">Change category</button></div></div>`;
  const pager=(type,list,page)=>{const pages=Math.max(1,Math.ceil(list.length/PAGE_SIZE));return `<div style="display:flex;justify-content:center;align-items:center;gap:8px;margin:12px 0 4px"><button type="button" data-page="${type}" data-dir="-1" ${page<=1?'disabled':''}>‹ Previous</button><span class="muted">${page}/${pages}</span><button type="button" data-page="${type}" data-dir="1" ${page>=pages?'disabled':''}>Next ›</button></div>`};
  const renderGroup=(type,title,list,page)=>{const pages=Math.max(1,Math.ceil(list.length/PAGE_SIZE));const safePage=Math.min(page,pages);const start=(safePage-1)*PAGE_SIZE;const visible=list.slice(start,start+PAGE_SIZE);const isOpen=!collapsed[type];return `<div style="margin-top:18px"><button type="button" data-fold="${type}" style="width:100%;text-align:left;background:#1a1f27">${title} (${list.length}) ${isOpen?'▴':'▾'}</button><div id="group-${type}" style="display:${isOpen?'block':'none'};margin-top:8px">${visible.length?visible.map(card).join(''):'<div class="muted">No assets in this section.</div>'}${isOpen?pager(type,list,safePage):''}</div></div>`};
  async function load(){try{rows=await api('assets/list');const premium=rows.filter(isPremium),basic=rows.filter(a=>!isPremium(a));const premiumPages=Math.max(1,Math.ceil(premium.length/PAGE_SIZE)),basicPages=Math.max(1,Math.ceil(basic.length/PAGE_SIZE));premiumPage=Math.min(premiumPage,premiumPages);basicPage=Math.min(basicPage,basicPages);root.innerHTML='<h2>Assets</h2><div class="muted" style="margin-bottom:14px">All Premium assets already added to the website and all newly added Premium assets appear here.</div>'+renderGroup('premium','💎 Premium Assets',premium,premiumPage)+renderGroup('basic','📁 Basic Assets',basic,basicPage)}catch(e){root.textContent=e.message||'Request failed.'}}
  async function choosePrice(a){
    const premium=isPremium(a);const old=premium?Number(a.premium_price??0):Number(a.basic_price??0);
    const initialPrice=Number(old);      const value=await openTool({title:'Change price',sub:`Set the ${premium?'Premium':'Basic'} price for “${a.name}”. 0 means free.`,body:`<label class="tool-label" for="tool-price">Price in Coins</label><input class="tool-input" id="tool-price" type="number" min="0" step="1" value="${old}"><div class="tool-help">Use a whole number of Coins. The current price is ${old} Coins.</div><div class="tool-preview">New price: <strong id="tool-price-preview">${old} Coins</strong></div>`,validate:()=>{const n=Number(document.getElementById('tool-price').value);if(!Number.isFinite(n)||n<0||!Number.isInteger(n))throw Error('Enter a whole number of Coins (0 or higher).');return n}});
    if(value===null)return;const body={asset_id:a.id};if(premium)body.premium_price=value;else body.basic_price=value;await api('admin/asset-settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  }
  async function chooseCategory(a){
    const cats=await api('categories/list');const current=String(a.category||'Everything').split(',').map(v=>v.trim().toLowerCase()).filter(Boolean);const currentSlugs=current.map(s=>{const m=cats.find(c=>String(c.slug).toLowerCase()===s||String(c.name).toLowerCase()===s);return m?String(m.slug):s});
    const checks=cats.map(c=>`<label class="cat-choice"><input type="checkbox" name="tool-cat" value="${esc(c.slug)}" ${currentSlugs.includes(String(c.slug))?'checked':''}><span>${esc(c.name)}</span></label>`).join('');
    const value=await openTool({title:'Change category',sub:`Choose one or more categories for “${a.name}”. Multiple selections are saved together.`,body:`<div class="cat-grid">${checks||'<div class="muted">No categories have been added yet.</div>'}</div><div class="switch-line"><div><b>Has scripts</b><small>This is asset metadata, not a category.</small></div><input id="tool-has-scripts" type="checkbox" ${a.has_scripts?'checked':''}></div>`,confirmText:'Save category',validate:()=>{const selected=[...document.querySelectorAll('input[name="tool-cat"]:checked')].map(x=>x.value);if(!selected.length)throw Error('Select at least one category.');return {selected,hasScripts:document.getElementById('tool-has-scripts').checked}}});
    if(!value)return;
    await api('admin/website',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'asset_text',asset_id:a.id,name:a.name,description:a.description||'',category:[...new Set(value.selected)].join(',')})});
    await api('admin/asset-settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:a.id,has_scripts:value.hasScripts})});
  }
  async function updateFile(a){
    const f=document.createElement('input');f.type='file';f.accept='.rbxm,.rbxmx,.rbxlx,.rbxl';f.onchange=async()=>{
      const file=f.files?.[0];if(!file)return;
      const currentPremium=isPremium(a);
      const initialPrice=Number(currentPremium ? (a.premium_price??0) : (a.basic_price??0)) || 0;
      const value=await openTool({
        title:'Update asset',
        sub:`Replace “${a.name}” with the selected file. Settings are optional; use the file-only button to leave every other value untouched.`,
        body:`<label class="tool-label" for="tool-file-name">Display name</label><input class="tool-input" id="tool-file-name" value="${esc(a.name)}"><div class="switch-line"><div><b>Premium asset</b><small>Switching this also switches which price is editable.</small></div><input id="tool-premium" type="checkbox" ${currentPremium?'checked':''}></div><div id="tool-price-panel"><label class="tool-label" for="tool-active-price">${currentPremium?'Premium':'Basic'} price</label><input class="tool-input" id="tool-active-price" type="number" min="0" step="1" value="${initialPrice}"><div class="tool-help">Current ${currentPremium?'Premium':'Basic'} price. Change it here if needed.</div></div><div class="switch-line"><div><b>Has scripts</b><small>Metadata only; this does not create a category.</small></div><input id="tool-has-scripts" type="checkbox" ${a.has_scripts?'checked':''}></div><label class="tool-label" for="tool-category" style="margin-top:14px">Category</label><input class="tool-input" id="tool-category" value="${esc(a.category||'everything')}"><div class="tool-help">Multiple categories can be separated with commas. Selected file: ${esc(file.name)} · ${(file.size/1024).toFixed(1)} KB</div><div class="tool-preview"><strong>What will change</strong><div id="tool-change-summary" style="margin-top:5px;color:#aeb7c4"></div></div>`,
        confirmText:'Update asset',
        noChangeText:'I dont want to change anything',
        noChangeValue:{fileOnly:true},
        afterRender:()=>{
          window.__updateAssetPremiumPrice=Number(a.premium_price??0);
          window.__updateAssetBasicPrice=Number(a.basic_price??0);
          renderUpdatePriceField();
          const toggle=document.getElementById('tool-premium');
          if(toggle)toggle.onchange=renderUpdatePriceField;
        },
        validate:()=>{
          const nameEl=document.getElementById('tool-file-name');
          const premiumEl=document.getElementById('tool-premium');
          const categoryEl=document.getElementById('tool-category');
          const scriptsEl=document.getElementById('tool-has-scripts');
          if(!nameEl||!premiumEl||!categoryEl||!scriptsEl)throw Error('The Update form could not initialize correctly. Please close it and try again.');
          const name=String(nameEl.value||'').trim();
          const premium=!!premiumEl.checked;
          const priceEl=document.getElementById('tool-active-price');
          if(!priceEl)throw Error('The price field could not initialize. Please close the Update window and try again.');
          const price=Number(priceEl.value);
          const category=String(categoryEl.value||'').trim();
          if(!name)throw Error('Enter an asset name.');
          if(!Number.isInteger(price)||price<0)throw Error('Price must be a whole number of 0 or higher.');
          if(!category)throw Error('Enter at least one category.');
          return {name,price,premium,hasScripts:!!scriptsEl.checked,category};
        }
      });
      if(value===null)return;
      const fd=new FormData();fd.append('asset_id',a.id);fd.append('file',file);
      if(!value.fileOnly){
        fd.append('name',value.name);fd.append('premium',String(value.premium));fd.append('has_scripts',String(value.hasScripts));fd.append('category',value.category);
        if(value.premium)fd.append('premium_price',String(value.price));else fd.append('basic_price',String(value.price));
      }
      const result=await api('admin/asset-update',{method:'POST',body:fd});
      if(!result?.ok)throw Error(result?.error||'The asset was not updated.');
      window.location.reload();
    };
    f.click();
  }
  function renderUpdatePriceField(){
    const panel=document.getElementById('tool-price-panel');const toggle=document.getElementById('tool-premium');if(!panel||!toggle)return;
    const premium=toggle.checked;const old=Number((premium?window.__updateAssetPremiumPrice:window.__updateAssetBasicPrice)??0);panel.innerHTML=`<label class="tool-label" for="tool-active-price">${premium?'Premium':'Basic'} price</label><input class="tool-input" id="tool-active-price" type="number" min="0" step="1" value="${old}"><div class="tool-help">Current ${premium?'Premium':'Basic'} price. Change it here if needed.</div>`;
    const summary=document.getElementById('tool-change-summary');if(summary)summary.textContent=`File replacement · display name · ${premium?'Premium':'Basic'} price · Premium status · script metadata · category`;
  }
  root.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.fold){const type=b.dataset.fold;collapsed[type]=!collapsed[type];await load();return}if(b.dataset.page){const type=b.dataset.page;const dir=Number(b.dataset.dir)||0;if(type==='premium')premiumPage+=dir;else basicPage+=dir;await load();return}const id=b.dataset.id;try{if(b.dataset.a==='update'){const a=rows.find(x=>String(x.id)===String(id));if(!a)return;await updateFile(a)}else if(b.dataset.a==='remove'){const ok=await (window.adminDialog?.confirm?.({title:'Remove asset',message:'Remove this file from the public page? The stored asset will not be deleted.',danger:true,confirmText:'Remove from page'})??false);if(!ok)return;await api('admin/asset-remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:id})})}else if(b.dataset.a==='disable'){const reason=await (window.adminDialog?.prompt?.({title:'Disable asset',message:'Add a short reason. This will be shown where the asset is disabled.',label:'Reason',value:'Disabled by the owner.',placeholder:'Why is this asset disabled?',confirmText:'Disable asset'})??null);if(reason===null)return;await api('admin/asset-settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:id,disabled:true,reason})})}else if(b.dataset.a==='enable'){await api('admin/asset-settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:id,disabled:false})})}else if(b.dataset.a==='price'){const a=rows.find(x=>String(x.id)===String(id));if(!a)return;await choosePrice(a)}else if(b.dataset.a==='category'){const a=rows.find(x=>String(x.id)===String(id));if(!a)return;await chooseCategory(a)}await load()}catch(e){window.adminDialog?.error?.(e.message||'Request failed.','Asset action failed')}});
  load();
})();