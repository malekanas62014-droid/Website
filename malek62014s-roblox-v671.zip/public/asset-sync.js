(() => {
  const load = async () => {
    try {
      const r = await fetch('/api/assets/list');
      if (!r.ok) return;
      const assets = await r.json();
      // Normalize category names globally so admin values like "Everything"
      // and "Scripts" match the public catalog's lowercase category IDs.
      for (const a of assets) {
        if (typeof a.category === 'string') a.category = a.category.trim().toLowerCase();
        if (!['flashlights','scripts','models','tools','everything'].includes(a.category)) a.category = 'everything';
      }
      window.MANAGED_ASSETS = assets;
      window.dispatchEvent(new CustomEvent('managed-assets-ready', { detail: assets }));
    } catch (_) {}
  };
  load();
})();