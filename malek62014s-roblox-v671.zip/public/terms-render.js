(() => {
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);

  function formatBody(raw) {
    return String(raw ?? '').trim().split(/\n\s*\n/).filter(Boolean).map(block => {
      const lines = block.split(/\r?\n/);
      if (lines.length && lines.every(line => /^\s*-\s+/.test(line))) {
        return '<ul>' + lines.map(line => '<li>' + escapeHtml(line.replace(/^\s*-\s+/, '')) + '</li>').join('') + '</ul>';
      }
      return '<p>' + lines.map(escapeHtml).join('<br>') + '</p>';
    }).join('');
  }

  async function renderTerms() {
    const response = await fetch('/api/terms?ts=' + Date.now(), { cache: 'no-store' });
    if (!response.ok) return;
    const data = await response.json();
    const sections = Array.isArray(data.sections) ? data.sections : [];
    const stamp = data.updated_at;
    if (stamp) {
      document.querySelectorAll('.muted').forEach(el => {
        if (el.textContent.includes('Last updated:')) {
          el.textContent = 'Last updated: ' + new Date(stamp).toLocaleDateString(undefined, {
            year: 'numeric', month: 'long', day: 'numeric'
          }) + ' · Effective immediately';
        }
      });
    }

    const hero = document.querySelector('.hero');
    const overview = sections.find(section => Number(section.section_number) === 0);
    const overviewText = hero?.querySelector('.terms-overview-text');
    if (overviewText) overviewText.textContent = overview ? String(overview.body || '') : '';

    const nav = document.querySelector('.side');
    if (nav) {
      nav.querySelectorAll('a[href^="#"]').forEach(anchor => anchor.remove());
      const title = nav.querySelector('.side-title');
      const trust = nav.querySelector('.trust');
      sections.filter(section => Number(section.section_number) !== 0).forEach(section => {
        const link = document.createElement('a');
        link.href = '#tos-section-' + String(section.id);
        link.textContent = String(section.section_number) + ' · ' + String(section.title || '');
        nav.insertBefore(link, trust || null);
      });
      if (title && title.parentElement === nav) nav.insertBefore(title, nav.firstChild);
    }

    const content = document.querySelector('.content');
    if (!content) return;
    content.replaceChildren();
    for (const section of sections) {
      if (Number(section.section_number) === 0) continue;
      const isNote = String(section.title || '').toLowerCase() === 'a note on these terms';
      const card = document.createElement(isNote ? 'div' : 'section');
      card.className = isNote ? 'notice' : 'card';
      card.id = 'tos-section-' + String(section.id);
      if (isNote) {
        const heading = document.createElement('b');
        heading.textContent = String(section.title || '');
        card.appendChild(heading);
        const wrapper = document.createElement('div');
        wrapper.innerHTML = formatBody(section.body);
        card.appendChild(wrapper);
      } else {
        const kicker = document.createElement('div');
        kicker.className = 'section-kicker';
        kicker.textContent = String(section.kicker || ('Section ' + section.section_number));
        const heading = document.createElement('h2');
        heading.setAttribute('data-num', String(Number(section.section_number) || 0));
        heading.textContent = String(section.title || '');
        card.append(kicker, heading);
        const body = document.createElement('div');
        body.innerHTML = formatBody(section.body);
        card.appendChild(body);
      }
      content.appendChild(card);
    }
    if (!sections.some(section => Number(section.section_number) !== 0)) {
      const empty = document.createElement('p');
      empty.className = 'muted';
      empty.textContent = 'There are currently no published Terms sections.';
      content.appendChild(empty);
    }
  }

  renderTerms().catch(() => {});
})();