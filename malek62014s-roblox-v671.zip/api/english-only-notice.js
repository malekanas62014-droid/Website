import { db } from 'hatchable';

export const access = 'public';
export const methods = ['GET'];

export default async function(req,res){
  res.setHeader('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
  const identity=req.user||req.member||null;
  const authId=String(identity?.id||'').trim();
  const email=String(identity?.email||'').trim().toLowerCase();
  if(!authId&&!email)return res.json({version:0});

  // The site's users.id is the canonical ID used by admin/user-management.
  // Resolve the authenticated platform identity back to that row by ID first,
  // then by email, so the admin reset and the public notice endpoint always
  // operate on the same user_preferences row.
  const {rows:users}=await db.query(
    `SELECT id FROM users
     WHERE ($1<>'' AND id=$1) OR ($2<>'' AND lower(email)=lower($2))
     ORDER BY CASE WHEN id=$1 THEN 0 ELSE 1 END
     LIMIT 1`,
    [authId,email]
  );
  const userId=String(users[0]?.id||authId).trim();
  const {rows}=await db.query(
    'SELECT COALESCE(english_notice_version,0) AS version FROM user_preferences WHERE user_id=$1 LIMIT 1',
    [userId]
  );
  res.json({version:Number(rows[0]?.version||0)});
}