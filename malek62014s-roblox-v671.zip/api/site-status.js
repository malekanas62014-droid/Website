import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
 const {rows}=await db.query("SELECT key,value FROM site_settings WHERE key IN ('maintenance_enabled','maintenance_reason')");
 const settings=Object.fromEntries(rows.map(x=>[x.key,x.value]));
 res.setHeader('Cache-Control','no-store');
 res.json({maintenance:settings.maintenance_enabled==='1',reason:settings.maintenance_reason||''});
}