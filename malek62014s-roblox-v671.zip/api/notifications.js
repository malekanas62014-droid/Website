import { db } from "hatchable";
export const access="user";
export const methods=["GET"];

export default async function(req,res){
  const userId=String(req.user.id||'');
  const email=String(req.user.email||'').trim().toLowerCase();
  const {rows}=await db.query(`SELECT
    (SELECT row_to_json(p) FROM (
      SELECT COALESCE(up.notifications_enabled,true) AS notifications_enabled,
        COALESCE(up.notification_dm,true) AS notification_dm,
        COALESCE(up.notification_support,true) AS notification_support,
        COALESCE(up.notification_reports,true) AS notification_reports,
        COALESCE(up.notification_logins,true) AS notification_logins,
        COALESCE(up.notification_bans,true) AS notification_bans,
        COALESCE(up.notification_unbans,true) AS notification_unbans,
        COALESCE(up.notification_warnings,true) AS notification_warnings,
        COALESCE(up.notification_friend_requests,true) AS notification_friend_requests,
        COALESCE(up.notification_followers,true) AS notification_followers
      FROM user_preferences up WHERE up.user_id=$1 LIMIT 1
    ) p) AS settings,
    EXISTS(
      SELECT 1 FROM admin_user_directory a
      WHERE a.is_admin=true AND (a.user_id=$1 OR lower(a.email)=lower($2))
    ) OR lower($2)='robloxassetsowner@protonmail.com' AS is_admin,
    COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.id DESC) FROM (
      SELECT id,sender_user_id,sender_username,message,created_at
      FROM direct_messages
      WHERE recipient_user_id=$1 AND deleted_at IS NULL AND read_at IS NULL
      ORDER BY created_at DESC,id DESC LIMIT 25
    ) x),'[]'::json) AS dms,
    COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.id DESC) FROM (
      SELECT id,title,message,created_at,seen_at
      FROM support_notifications
      WHERE recipient_type='user' AND recipient_id=$1 AND title<>'New App Installation'
      ORDER BY created_at DESC,id DESC LIMIT 25
    ) x),'[]'::json) AS support,
    /* app-install notification feed removed */
    COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.id DESC) FROM (
      SELECT fr.id,fr.sender_user_id,fr.created_at,
        COALESCE(p.username,u.name,u.email,'User') AS sender_username,
        COALESCE(up.display_name,'') AS sender_display_name
      FROM friend_requests fr
      LEFT JOIN users u ON u.id=fr.sender_user_id
      LEFT JOIN profile_usernames p ON p.user_id=fr.sender_user_id
      LEFT JOIN user_profiles up ON up.user_id=fr.sender_user_id
      WHERE fr.recipient_user_id=$1 AND fr.status='pending'
      ORDER BY fr.created_at DESC,fr.id DESC LIMIT 25
    ) x),'[]'::json) AS friend_requests,
    COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.follow_id DESC) FROM (
      SELECT uf.followed_user_id,uf.follower_user_id,uf.created_at,uf.created_at AS followed_at,uf.follower_user_id AS follow_id,
        COALESCE(p.username,u.name,u.email,'User') AS follower_username,
        COALESCE(up.display_name,'') AS follower_display_name
      FROM user_follows uf
      LEFT JOIN users u ON u.id=uf.follower_user_id
      LEFT JOIN profile_usernames p ON p.user_id=uf.follower_user_id
      LEFT JOIN user_profiles up ON up.user_id=uf.follower_user_id
      WHERE uf.followed_user_id=$1
      ORDER BY uf.created_at DESC,uf.follower_user_id DESC LIMIT 25
    ) x),'[]'::json) AS followers,
    CASE WHEN (
      EXISTS(SELECT 1 FROM admin_user_directory a WHERE a.is_admin=true AND (a.user_id=$1 OR lower(a.email)=lower($2)))
      OR lower($2)='robloxassetsowner@protonmail.com'
    ) THEN COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.id DESC) FROM (
      SELECT id,reporter_username,reported_username,category,created_at,status
      FROM user_reports WHERE status='open'
      ORDER BY created_at DESC,id DESC LIMIT 25
    ) x),'[]'::json) ELSE '[]'::json END AS reports,
    CASE WHEN (
      EXISTS(SELECT 1 FROM admin_user_directory a WHERE a.is_admin=true AND (a.user_id=$1 OR lower(a.email)=lower($2)))
      OR lower($2)='robloxassetsowner@protonmail.com'
    ) THEN COALESCE((SELECT json_agg(x ORDER BY x.updated_at DESC,x.id DESC) FROM (
      SELECT id,username,subject,category,priority,status,updated_at,created_at
      FROM support_tickets WHERE status<>'closed'
      ORDER BY updated_at DESC,id DESC LIMIT 25
    ) x),'[]'::json) ELSE '[]'::json END AS tickets,
    CASE WHEN (
      EXISTS(SELECT 1 FROM admin_user_directory a WHERE a.is_admin=true AND (a.user_id=$1 OR lower(a.email)=lower($2)))
      OR lower($2)='robloxassetsowner@protonmail.com'
    ) THEN COALESCE((SELECT json_agg(x ORDER BY x.created_at DESC,x.id DESC) FROM (
      SELECT id,username,created_at
      FROM user_login_events
      ORDER BY created_at DESC,id DESC LIMIT 25
    ) x),'[]'::json) ELSE '[]'::json END AS logins`,[userId,email]);
  const r=rows[0]||{};
  const settings=r.settings||{};
  return res.json({
    settings:{
      notifications_enabled:settings.notifications_enabled!==false,
      notification_dm:settings.notification_dm!==false,
      notification_support:settings.notification_support!==false,
      notification_reports:settings.notification_reports!==false,
      notification_logins:settings.notification_logins!==false,
      notification_bans:settings.notification_bans!==false,
      notification_unbans:settings.notification_unbans!==false,
      notification_warnings:settings.notification_warnings!==false,
      notification_friend_requests:settings.notification_friend_requests!==false,
      notification_followers:settings.notification_followers!==false
    },
    is_admin:!!r.is_admin,
    dms:Array.isArray(r.dms)?r.dms:[],
    support:Array.isArray(r.support)?r.support:[],
    reports:Array.isArray(r.reports)?r.reports:[],
    tickets:Array.isArray(r.tickets)?r.tickets:[],
    logins:Array.isArray(r.logins)?r.logins:[],
    friend_requests:Array.isArray(r.friend_requests)?r.friend_requests:[],
    followers:Array.isArray(r.followers)?r.followers:[]
  });
}