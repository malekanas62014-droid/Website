import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
export default async function(req,res){const {rows}=await db.query("SELECT id,name,slug FROM website_categories ORDER BY CASE WHEN slug='everything' THEN 0 ELSE 1 END,name");res.json(rows);}