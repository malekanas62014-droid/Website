import { db, storage } from "hatchable";
import { PREMIUM_ASSETS } from "lib/premium-assets.js";
import { requireStudioDevice } from "lib/studio-device";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  if(!requireStudioDevice(req,res))return;
  const asset = PREMIUM_ASSETS[req.params.id];
  if (!asset) return res.status(404).json({ error: "Premium asset not found." });

  const { rows } = await db.query(
    "SELECT premium_access FROM premium_wallets WHERE user_id = $1",
    [String(req.user.id)]
  );
  if (!rows[0]?.premium_access) return res.status(403).json({ error: "Premium access is required." });

  // Page Admin can disable legacy Premium assets. Premium users are allowed to
  // download Premium files normally, but a disabled file must remain blocked.
  const { rows: overrides } = await db.query(
    "SELECT disabled, disabled_reason, storage_key FROM page_asset_overrides WHERE legacy_id = $1 LIMIT 1",
    [String(req.params.id)]
  );
  if (overrides[0]?.disabled) return res.status(403).json({ error: "Disabled", reason: overrides[0].disabled_reason || "Disabled by the owner." });

  const replacementKey = String(overrides[0]?.storage_key || "").trim();
  if (replacementKey) {
    const file = await storage.get(replacementKey);
    res.setHeader("Content-Type", file.contentType || "application/octet-stream");
    res.setHeader("Content-Disposition", 'attachment; filename="' + asset.name.replace(/"/g, "") + '"');
    res.setHeader("Cache-Control", "private, no-store");
    res.send(file.buffer);
    return;
  }

  const binary = atob(asset.data);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  res.setHeader("Content-Type", "application/octet-stream");
  res.setHeader("Content-Disposition", 'attachment; filename="' + asset.name.replace(/"/g, "") + '"');
  res.setHeader("Cache-Control", "private, no-store");
  res.send(bytes);
}