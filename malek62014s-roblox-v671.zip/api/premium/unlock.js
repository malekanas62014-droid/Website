import { db } from "hatchable";

export const access = "user";
export const methods = ["POST"];

export default async function (req, res) {
  const userId = String(req.user.id);
  await db.query(
    "INSERT INTO premium_wallets (user_id, coins) VALUES ($1, 5) ON CONFLICT (user_id) DO NOTHING",
    [userId]
  );
  const current = await db.query(
    "SELECT coins, premium_access FROM premium_wallets WHERE user_id = $1",
    [userId]
  );
  if (current.rows[0].premium_access) {
    return res.json({ ok: true, already_unlocked: true, coins: current.rows[0].coins, premium_access: true });
  }
  const updated = await db.query(
    "UPDATE premium_wallets SET coins = coins - 70, premium_access = true WHERE user_id = $1 AND coins >= 70 AND premium_access = false RETURNING coins, premium_access",
    [userId]
  );
  if (updated.rowCount === 0) {
    return res.status(409).json({ ok: false, error: "You need 70 Coins to unlock Premium.", coins: current.rows[0].coins, premium_access: false });
  }
  res.json({ ok: true, coins: updated.rows[0].coins, premium_access: true });
}