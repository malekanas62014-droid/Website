import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
  const page=Math.max(1,Number.parseInt(String(req.query?.page||'1'),10)||1);
  const pageSize=Math.min(50,Math.max(1,Number.parseInt(String(req.query?.pageSize||'6'),10)||6));
  const search=String(req.query?.search||'').trim().slice(0,50);
  const like=`%${search.toLowerCase()}%`;
  const includeId=Boolean(req.user?.id);
  const {rows}=await db.query("SELECT p.username,p.user_id,u.email,COALESCE(up.display_name,'') AS display_name,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin FROM profile_usernames p JOIN users u ON u.id=p.user_id LEFT JOIN user_profiles up ON up.user_id=u.id WHERE p.username<>'' AND NOT EXISTS (SELECT 1 FROM deleted_accounts d WHERE lower(COALESCE(d.email,''))=lower(COALESCE(u.email,''))) AND ($1='' OR lower(p.username) LIKE $2 OR lower(COALESCE(up.display_name,'')) LIKE $2) ORDER BY lower(COALESCE(NULLIF(up.display_name,''),p.username)),lower(p.username),p.username LIMIT $3 OFFSET $4",[search,like,pageSize,(page-1)*pageSize]);
  const {rows:countRows}=await db.query("SELECT COUNT(*)::int AS count FROM profile_usernames p JOIN users u ON u.id=p.user_id LEFT JOIN user_profiles up ON up.user_id=u.id WHERE p.username<>'' AND NOT EXISTS (SELECT 1 FROM deleted_accounts d WHERE lower(COALESCE(d.email,''))=lower(COALESCE(u.email,''))) AND ($1='' OR lower(p.username) LIKE $2 OR lower(COALESCE(up.display_name,'')) LIKE $2)",[search,like]);
  const total=Number(countRows[0]?.count||0);
  res.setHeader('Cache-Control','public, max-age=15');
  res.json({users:rows.map(r=>({username:String(r.username),display_name:String(r.display_name||''),user_id:includeId?String(r.user_id):undefined,creator:String(r.email||'').trim().toLowerCase()==='robloxassetsowner@protonmail.com',is_creator:String(r.email||'').trim().toLowerCase()==='robloxassetsowner@protonmail.com',is_verified:!!r.is_verified,is_admin:!!r.is_admin})),page,pageSize,total,totalPages:Math.max(1,Math.ceil(total/pageSize)),readOnly:true});
}