import { db, auth } from "hatchable";
export const access = "public";
export const methods = ["GET","POST"];
export default async function(req,res){
 const user=await auth.getUser(req);
 if(!user) return res.status(401).json({error:"Sign in required."});
 const forwarded=String(req.headers?.['x-forwarded-for']||'').split(',')[0].trim();
 const ip=forwarded||String(req.headers?.['x-real-ip']||'').trim();
 if(ip) await db.query("INSERT INTO user_last_ips (user_id,last_ip,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET last_ip=EXCLUDED.last_ip,updated_at=NOW()",[String(user.id),ip]);
 if(req.method==="GET"){
  const {rows}=await db.query("SELECT COALESCE(p.username,'') AS username,COALESCE(up.display_name,'') AS display_name,COALESCE(up.is_verified,false) AS is_verified,COALESCE(w.coins,0) AS coins,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id LEFT JOIN premium_wallets w ON w.user_id=u.id WHERE u.id=$1 LIMIT 1",[user.id]);
  if(rows.length) { const actual=String(rows[0].username||''); if(actual) return res.json({username:actual,display_name:String(rows[0].display_name||''),email:user.email||null,coins:Number(rows[0].coins||0),is_verified:!!rows[0].is_verified,is_admin:!!rows[0].is_admin,is_creator:String(user.email||'').trim().toLowerCase()==='robloxassetsowner@protonmail.com'}); }
  const platformHandle=String(user.handle||user.display_name||'').trim();
  const validHandle=/^[A-Za-z0-9_]{3,20}$/.test(platformHandle)?platformHandle:'';
  const base=validHandle||('User'+String(user.id).replace(/[^A-Za-z0-9]/g,'').slice(-6));
  let candidate=base.slice(0,20), n=1;
  while((await db.query("SELECT 1 FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1",[candidate])).rows.length){ candidate=(base.slice(0,17)+n++).slice(0,20); }
  await db.query("INSERT INTO profile_usernames (user_id,username) VALUES ($1,$2) ON CONFLICT DO NOTHING",[user.id,candidate]);
  return res.json({username:candidate,email:user.email||null,generated:!validHandle});
 }
 const username=String(req.body?.username||"").trim();
 if(!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({error:"Username must be 3-20 characters and use only letters, numbers, or _."});
 const currentRows=await db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[user.id]);
 const currentUsername=String(currentRows.rows[0]?.username||'');
 const {rows:existing}=await db.query("SELECT user_id FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1",[username]);
 if(existing.length && String(existing[0].user_id)!==String(user.id)) return res.status(409).json({error:"That username is already taken."});
 if(currentUsername.toLowerCase()===username.toLowerCase()) return res.json({ok:true,username:currentUsername,display_name:String((await db.query("SELECT COALESCE(display_name,'') AS display_name FROM user_profiles WHERE user_id=$1 LIMIT 1",[user.id])).rows[0]?.display_name||'')});
 try {
  await db.query("INSERT INTO premium_wallets (user_id,coins,premium_access) VALUES ($1,0,false) ON CONFLICT (user_id) DO NOTHING",[String(user.id)]);
  const tx=await db.query("WITH charged AS (UPDATE premium_wallets SET coins=coins-25 WHERE user_id=$1 AND coins>=25 RETURNING user_id,coins), updated AS (INSERT INTO profile_usernames (user_id,username) SELECT $1,$2 FROM charged ON CONFLICT (user_id) DO UPDATE SET username=EXCLUDED.username RETURNING username), directory AS (UPDATE admin_user_directory SET username=$2,updated_at=NOW() WHERE user_id=$1 AND EXISTS (SELECT 1 FROM updated) RETURNING user_id) SELECT c.coins,u.username FROM charged c CROSS JOIN updated u",[String(user.id),username]);
  if(!tx.rows?.length)return res.status(400).json({error:"You need 25 Coins to change your username."});
 } catch(error) {
  if(String(error?.message||'').toLowerCase().includes('unique')) return res.status(409).json({error:"That username is already taken."});
  throw error;
 }
 res.json({ok:true,username});
}