import { db } from "hatchable";
import { notifyAdminsOfModeration } from "lib/admin-moderation-notify";
export const access="user";
export const methods=["GET","POST"];

const blockedTerms=[
  'fuck','fucking','fucked','fucker','fuckin','motherfuck','shit','bullshit','sh1t','bitch','bi7ch','bitc','b1tch','asshole','arsehole','dick','dickhead','dih','dik','d1ck','d1h','penis','cock','piss','pissed','cunt','cnt','bastard','whore','slut','faggot','fag','nigger','nigga','n1gga','n1gger','retard','retarded',
  'porn','porno','pornography','pron','p0rn','rule34','hentai','ecchi','nsfw','nsfl','sex','seggs','sexual','seggsy','sexy','horny','nude','nudes','nudity','naked','send nudes','rape','rapist','molest','molestation','pedophile','pedo','predator','kys','kill yourself','go die',
  'masturbate','masturbating','masterbate','masterbating','jerkoff','jerking off','handjob','hand job','blowjob','blow job','cum','cumming','cummed','creampie','orgasm','anal','boobs','boob','tits','titty','milf','dildo','vibrator','thot','hoe','hoes','slutty','ussy','pussy','bussy','daddy','suck me','suck it',
  'dick pic','cock pic','nudes','onlyfans','fanvue','goon','gooner','gooning','goan','goaned','goaning','edging','edge me','coom','coomer','gyat','gyatt','hawk tuah','throat goat','deepthroat','fetish','bdsm','incest','step sis','stepbro','step mom','stepmom','stepsis','stepbro','sussy','sus','sext','sexting','hornypost','r34','r34r','nsfw','dingaling','ding-a-ling'
];
const blockedExact=['fuc','fck','fuk','fuq','dih','dik','bitc','sh1t','pron','pedo','gyat','gyatt','goon','coom','ussy','sus'];
const blockedStems=['dingaling','dong','dongalong','dongalang','donk','fuck','fuk','fck','fuq','shit','sh1t','bitch','bi7ch','bitc','asshole','arsehole','dick','dik','d1ck','dix','dixs','dixx','cock','c0ck','penis','p3nis','piss','cunt','cnt','bastard','whore','slut','faggot','fag','nigger','nigga','n1gga','retard','porn','porno','hentai','rule34','nsfw','sex','seggs','sexual','horny','nude','nudes','naked','rape','rapist','molest','pedo','pedophile','masturbat','masterbat','jerkoff','handjob','blowjob','cum','creampie','orgasm','boob','boobs','tits','titty','milf','dildo','vibrator','pussy','bussy','thot','slutty','goon','gooner','gooning','edg','coom','coomer','gyat','sext','sexting','fetish','bdsm','incest','stepmom','stepsis','stepbro','onlyfans','fanvue','deepthroat','hawk tuah','throat goat','hornypost','sussy','ussy','suckit','suckme','ballsack','ballsy','testicle','testicles','scrotum','boobies','titties','pornhub','xvideos','xnxx'];

function normalize(text){
  return String(text||'')
    .normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase()
    .replace(/[0]/g,'o').replace(/[1!]/g,'i').replace(/3/g,'e').replace(/[4@]/g,'a').replace(/[5$]/g,'s').replace(/7/g,'t').replace(/8/g,'b').replace(/9/g,'g')
    .replace(/ph/g,'f')
    // Preserve letters/digits from every writing system. The old ASCII-only cleanup
    // silently erased Arabic, Cyrillic, Greek, Indic, CJK, etc. before custom/native checks.
    .replace(/[^\p{L}\p{N}]+/gu,' ')
    .replace(/(.)\1{2,}/g,'$1$1')
    .trim();
}
function deSpace(text){return normalize(text).replace(/\s+/g,'');}
const OG_FILTER_GROUPS=[
  {name:'fuck',roots:['fuck']},{name:'shit',roots:['shit']},{name:'bitch',roots:['bitch','bitc']},{name:'dick',roots:['dick','dik','dix','dih']},{name:'penis',roots:['penis']},{name:'cock',roots:['cock']},{name:'piss',roots:['piss']},{name:'cunt',roots:['cunt']},{name:'bastard',roots:['bastard']},{name:'fag',roots:['fag']},{name:'nigger',roots:['nigg']},{name:'retard',roots:['retard']},{name:'porn',roots:['porn']},{name:'rule34',roots:['rule34','r34']},{name:'hentai',roots:['hentai']},{name:'sex',roots:['sex','segg']},{name:'horny',roots:['horny']},{name:'nude',roots:['nude']},{name:'rape',roots:['rape']},{name:'molest',roots:['molest']},{name:'pedo',roots:['pedo']},{name:'masturbate',roots:['masturb']},{name:'jerkoff',roots:['jerkoff']},{name:'handjob',roots:['handjob']},{name:'blowjob',roots:['blowjob']},{name:'cum',roots:['cum']},{name:'creampie',roots:['creampie']},{name:'orgasm',roots:['orgasm']},{name:'anal',roots:['anal']},{name:'boob',roots:['boob']},{name:'tits',roots:['tit']},{name:'milf',roots:['milf']},{name:'dildo',roots:['dildo']},{name:'vibrator',roots:['vibrator']},{name:'pussy',roots:['pussy']},{name:'thot',roots:['thot']},{name:'slut',roots:['slut']},{name:'whore',roots:['whore']},{name:'goon',roots:['goon']},{name:'coom',roots:['coom']},{name:'gyat',roots:['gyat']},{name:'sext',roots:['sext']},{name:'edging',roots:['edg']},{name:'fetish',roots:['fetish']},{name:'bdsm',roots:['bdsm']},{name:'incest',roots:['incest']},{name:'step',roots:['step']},{name:'onlyfans',roots:['onlyfans']},{name:'fanvue',roots:['fanvue']},{name:'dong',roots:['dong']},{name:'dingaling',roots:['dingaling']},{name:'balls',roots:['balls']},{name:'testicle',roots:['testicle']},{name:'scrotum',roots:['scrotum']},{name:'kys',roots:['kys']},{name:'ass',roots:['ass']},{name:'damn',roots:['damn']},{name:'hell',roots:['hell']},{name:'wtf',roots:['wtf']},{name:'wth',roots:['wth']},{name:'stfu',roots:['stfu']},{name:'omfg',roots:['omfg']},{name:'ffs',roots:['ffs']}
];
const OG_FILTER_ALIASES={
  fuck:['fucking','fucked','fucker','fuckin','motherfuck','fuk','fck','fuq'],
  shit:['bullshit','sh1t'],
  bitch:['bi7ch','bitc','b1tch'],
  dick:['dickhead','dih','dik','d1ck','d1h','dix','dixs','dixx','dixxx'],
  penis:['p3nis'],
  cock:['c0ck'],
  piss:['pissed'],
  cunt:['cnt'],
  nigger:['nigga','n1gga','n1gger'],
  retard:['retarded'],
  porn:['porno','pornography','pron','p0rn','pornhub'],
  rule34:['r34','r34r'],
  hentai:['ecchi'],
  sex:['seggs','sexual','seggsy','sexy'],
  horny:[], nude:['nudes','nudity','naked'], rape:['rapist'], molest:['molestation'],
  pedo:['pedophile','predator'], masturbate:['masturbating','masterbate','masterbating'],
  jerkoff:['jerking off'], handjob:['hand job'], blowjob:['blow job'], cum:['cumming','cummed'],
  tits:['titty','titties'], boob:['boobs','boobies'], slut:['slutty'], whore:[],
  pussy:['ussy','bussy'], goon:['gooner','gooning','goan','goaned','goaning'], coom:['coomer'],
  gyat:['gyatt'], edging:['edge me'], sext:['sexting'], incest:['step sis','stepbro','step mom','stepmom','stepsis'],
  onlyfans:[], fanvue:[], dong:['dongalong','dongalang'], dingaling:['ding-a-ling'], balls:['ballsack','ballsy'],
  testicle:['testicles'], ass:[], damn:[], hell:[], wtf:[], wth:[], stfu:[], omfg:[], ffs:[]
};
const MULTILINGUAL_FILTER_ALIASES={
  fuck:['لعنة','اللعنة','العنة','يلعن','يلعن ابو','فكس','كس','نيك','انكح','fuck'],
  shit:['خرا','الخراء','merde','mierda','scheisse','scheiße','miercoles'],
  bitch:['كلبة','قحبة','puta','putain','pute','bitch'],
  dick:['زب','زبر','قضيب','хуй','хуйня','polla','verga'],
  cunt:['كس','كسم','كسس','pizda','пизда','concha'],
  bastard:['ابن الكلب','ابن القحبة','bastard','bastardo','bâtard'],
  whore:['عاهرة','شرموطة','puta','whore','puttana'],
  slut:['شرموطة','slut','perra'],
  sex:['جنس','sexo','sex','sexe','sex','sexo'],
  porn:['اباحي','إباحي','جنسى','جنسي','porn','porno','pornografia','porno'],
  horny:['متحرش','مثار','caliente','horny'],
  rape:['اغتصاب','اغتصب','rapto','violación','viol','vergewaltigung'],
  pedo:['بيدو','بيدوفيل','pedofilo','pédophile','pedo'],
  masturbate:['استمناء','عادة سرية','masturbar','masturbación','masturbation'],
  blowjob:['مص','جنس فموي','sexo oral','fellation','blowjob'],
  cum:['مني','قذف','sperma','semen','sperme','cum'],
  boobs:['ثديين','اثداء','أثداء','tetas','seins','brüste'],
  pussy:['كس','مهبل','vagina','vaginal','vagin'],
  ass:['حمار','مؤخرة','culo','cul','arsch'],
  damn:['لعنة','اللعنة','العنة','damn','merde','maledizione'],
  hell:['جهنم','الجحيم','enfer','infierno','hölle'],
  stfu:['اخرس','اسكت','tais-toi','cállate','shut up'],
  kys:['اقتل نفسك','مت','انتحر','suicide','matarte','tue-toi']
};
const multilingualBlockedTerms=[...new Set(Object.values(MULTILINGUAL_FILTER_ALIASES).flat())];
const OG_ALIAS_TO_GROUP=new Map([
  ...Object.entries(OG_FILTER_ALIASES).flatMap(([group,aliases])=>aliases.map(alias=>[deSpace(alias),group])),
  ...Object.entries(MULTILINGUAL_FILTER_ALIASES).flatMap(([group,aliases])=>aliases.map(alias=>[deSpace(alias),group]))
]);
export function canonicalFilterTerm(term){
  const raw=String(term||'').trim();
  const lower=raw.toLowerCase();
  const n=deSpace(raw);
  const exactAlias=OG_ALIAS_TO_GROUP.get(n);
  if(exactAlias)return exactAlias;
  const group=OG_FILTER_GROUPS.find(g=>g.name===lower||g.roots.some(r=>n.startsWith(deSpace(r))));
  return group?.name||raw;
}
function editDistance(a,b){
  if(a===b)return 0;
  if(!a.length)return b.length;
  if(!b.length)return a.length;
  const prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++){
    const cur=[i];
    for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    for(let j=0;j<=b.length;j++)prev[j]=cur[j];
  }
  return prev[b.length];
}
function findBlockedTerms(text){
  const normalized=normalize(text), compact=deSpace(text);
  const hits=new Set();
  for(const term of blockedTerms){
    const t=term.replace(/\s+/g,'');
    if(t && compact.includes(t))hits.add(term);
  }
  for(const term of blockedExact){
    const t=term.replace(/\s+/g,'');
    if(t && compact.includes(t))hits.add(term);
  }
  for(const stem of blockedStems){
    const t=normalize(stem).replace(/[^a-z0-9]/g,'');
    if(t && compact.includes(t))hits.add(stem);
  }
  // Explicit multilingual terms are checked in their native scripts before translation,
  // so short slang/profanity is still caught when automatic language detection is weak.
  for(const term of multilingualBlockedTerms){
    const t=String(term||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'');
    if(t && String(text||'').normalize('NFKC').toLowerCase().replace(/\s+/g,'').includes(t))hits.add(term);
  }
  // Fuzzy root matching catches small misspellings and inserted/removed characters.
  const tokens=normalized.split(/\s+/).filter(Boolean);
  for(const root of blockedStems){
    const r=normalize(root).replace(/[^a-z0-9]/g,'');
    if(r.length<4)continue;
    for(const token of tokens){
      if(token.length<4)continue;
      if(token===r || (token.startsWith(r) && token.length-r.length<=10) || (editDistance(token,r)<=1 && Math.abs(token.length-r.length)<=1)){
        hits.add(root);
        break;
      }
    }
  }
  const shortVulgarExact=['ass','damn','hell','wtf','wth','stfu','omfg','ffs'];
  for(const word of shortVulgarExact)if(tokens.includes(word))hits.add(word);
  // Contextual sexual/slang patterns: catch variants such as "big d", "big dixs",
  // "dix", "dixs", and separated/obfuscated forms without blocking plain "d" or "di".
  const contextual=[
    /\bbig\s+d(?:ick|dik|d1ck|ix|ixs|ixx|icks?|ixxs?)?\b/i,
    /\bbig\s+d\b/i,
    /\bdi(?:ck|k|x|xx|cks?|xs?|xxs?)\b/i,
    /\bdong(?:along|alongs)\b/i,
    /\bbig\s+dong(?:s)?\b/i
  ];
  if(contextual.some(re=>re.test(normalized)))hits.add('contextual sexual slang');
  const severe=/nigg|fagg|pedo|rape|molest|incest|porn|sex|segg|masturb|dick|cock|pussy|dong|dingaling|goon|coom|slut|whore|cunt|blowjob|handjob|deepthroat|onlyfans|fetish|bdsm|kys|kill yourself|sexual/i;
  const mild=/damn|hell|ass|wtf|wth|stfu|omfg|ffs/i;
  const kindOf=t=>severe.test(String(t))?'severe':mild.test(String(t))?'mild':'strong';
  return [...hits];
}
function mask(text,terms){
  return terms.length?'***':String(text);
}
async function getUsername(user){
  const {rows}=await db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[String(user.id)]);
  return String(rows[0]?.username||user.handle||user.display_name||'User').slice(0,20);
}
export async function getFilterConfig(){
  // One SQL call instead of four parallel calls. Chat GET/POST can be hit very
  // frequently, so the filter snapshot must not multiply DB usage per request.
  const {rows}=await db.query(`
    SELECT
      COALESCE((SELECT json_agg(term ORDER BY lower(term)) FROM chat_filters WHERE enabled=true), '[]'::json) AS custom_terms,
      COALESCE((SELECT json_agg(json_build_object('term',term,'enabled',enabled,'is_custom',is_custom,'parent_term',parent_term) ORDER BY lower(term)) FROM core_filter_overrides), '[]'::json) AS overrides,
      COALESCE((SELECT json_agg(lower(term) ORDER BY lower(term)) FROM core_filter_deletions), '[]'::json) AS deleted_terms,
      COALESCE((SELECT json_agg(json_build_object('filter_term',filter_term,'punishment',punishment,'reason',reason,'ban_duration_seconds',ban_duration_seconds,'filter_dms',filter_dms,'tag_matches',tag_matches) ORDER BY lower(filter_term)) FROM chat_filter_punishments), '[]'::json) AS punishments,
      COALESCE((SELECT json_agg(json_build_object('filter_term',filter_term,'warning_count',warning_count,'action',action,'reason',reason,'enabled',enabled,'ban_duration_seconds',ban_duration_seconds,'order_index',order_index) ORDER BY lower(filter_term),order_index ASC,created_at ASC,id ASC) FROM warning_escalation_rules WHERE enabled=true), '[]'::json) AS warning_rules
  `);
  const snapshot=rows[0]||{};
  const custom=Array.isArray(snapshot.custom_terms)?snapshot.custom_terms:[];
  const overrides=Array.isArray(snapshot.overrides)?snapshot.overrides:[];
  const punishments=Array.isArray(snapshot.punishments)?snapshot.punishments:[];
  const warningRules=Array.isArray(snapshot.warning_rules)?snapshot.warning_rules:[];
  const deletedTerms=new Set((Array.isArray(snapshot.deleted_terms)?snapshot.deleted_terms:[]).map(r=>deSpace(r)));
  return {
    custom:[...custom.map(r=>String(r||'')),...overrides.filter(r=>r.is_custom&&r.enabled).map(r=>String(r.term||''))].filter(Boolean),
    disabled:new Set(overrides.filter(r=>!r.enabled).map(r=>deSpace(r.term))),
    deleted:deletedTerms,
    punishments:new Map(punishments.map(r=>[deSpace(r.filter_term),String(r.punishment||'mask') ])),
    punishmentReasons:new Map(punishments.map(r=>[deSpace(r.filter_term),String(r.reason||'').trim()])),
    dmFiltering:new Map(punishments.map(r=>[deSpace(r.filter_term),r.filter_dms===true])),
    dmTagging:new Map(punishments.map(r=>[deSpace(r.filter_term),r.tag_matches!==false])),
    banDurations:new Map(punishments.map(r=>[deSpace(r.filter_term),Number(r.ban_duration_seconds||604800)])),
    warningRules:warningRules.map(r=>({filter_term:String(r.filter_term||''),warning_count:Number(r.warning_count||0),action:String(r.action||'warn'),reason:String(r.reason||''),ban_duration_seconds:Number(r.ban_duration_seconds??604800)}))
  };
}
export function punishmentForTerms(terms,config){
  const rank={mask:1,warn:2,delete:3,ip_ban:4,ban:5};let best='mask';let bestRank=1;
  const punishmentMap=config?.punishments||new Map();
  for(const hit of terms){
    const isCustom=String(hit||'').startsWith('custom:');
    const raw=String(hit||'').replace(/^custom:/,'');
    const key=deSpace(isCustom?raw:canonicalFilterTerm(raw));
    let p=punishmentMap.get(key);
    if(!p&&!isCustom){
      const canonical=canonicalFilterTerm(raw);
      p=punishmentMap.get(deSpace(canonical));
    }
    p=p||'mask';
    if((rank[p]||1)>bestRank){best=p;bestRank=rank[p]||1;}
  }
  return best;
}
export function primaryMatchedWord(terms){
  const cleaned=(terms||[]).map(x=>{
    const raw=String(x||'').replace(/^custom:/,'').trim();
    return String(x||'').startsWith('custom:')?raw:canonicalFilterTerm(raw);
  }).filter(Boolean);
  return cleaned.sort((a,b)=>b.length-a.length)[0]||'filtered language';
}
export function automaticFilterReason(term){
  const raw=String(term||'filtered language').trim();
  const canonical=canonicalFilterTerm(raw).toLowerCase();
  const reasonByGroup={
    fuck:'Strong profanity was used.',
    shit:'Profane language was used.',
    bitch:'Insulting language was used.',
    dick:'Sexual anatomy was mentioned.',
    penis:'Explicit anatomy was mentioned.',
    cock:'Sexual anatomy was mentioned.',
    pussy:'Explicit sexual language.',
    porn:'Explicit sexual content.',
    sex:'Sexually explicit language.',
    horny:'Sexually suggestive language.',
    nude:'Nudity-related language.',
    rape:'Sexual violence was referenced.',
    molest:'Sexual abuse was referenced.',
    pedo:'Sexual abuse reference.',
    masturbation:'Explicit sexual language.',
    masturbate:'Explicit sexual language.',
    blowjob:'Explicit sexual language.',
    handjob:'Explicit sexual language.',
    cum:'Explicit sexual language.',
    creampie:'Explicit sexual language.',
    orgasm:'Explicit sexual language.',
    anal:'Explicit sexual language.',
    tits:'Sexual anatomy was mentioned.',
    boob:'Sexual anatomy was mentioned.',
    milf:'Sexually suggestive language.',
    dildo:'Explicit sexual content.',
    vibrator:'Explicit sexual content.',
    slut:'Sexual insult was used.',
    whore:'Sexual insult was used.',
    faggot:'Hateful slur was used.',
    fag:'Hateful slur was used.',
    nigger:'Hateful slur was used.',
    nigga:'Hateful slur was used.',
    retard:'Derogatory language was used.',
    bdsm:'Explicit sexual content.',
    fetish:'Explicit sexual content.',
    incest:'Sexual abuse reference.',
    sext:'Explicit sexual language.',
    edging:'Explicit sexual language.',
    goon:'Sexually suggestive language.',
    coom:'Explicit sexual language.',
    gyat:'Sexual slang was used.',
    dong:'Sexual anatomy was mentioned.',
    dingaling:'Sexual anatomy was mentioned.',
    cunt:'Offensive language was used.',
    bastard:'Offensive language was used.',
    whore:'Sexual insult was used.',
    piss:'Profane language was used.',
    balls:'Sexual anatomy was mentioned.',
    testicle:'Sexual anatomy was mentioned.',
    scrotum:'Sexual anatomy was mentioned.',
    kys:'Self-harm language was used.',
    ass:'Offensive language was used.',
    damn:'Profanity was used.',
    hell:'Profane language was used.',
    wtf:'Profanity was used.',
    wth:'Profanity was used.',
    stfu:'Hostile language was used.',
    omfg:'Strong profanity was used.',
    ffs:'Strong profanity was used.'
  };
  return reasonByGroup[canonical]||'Filtered language was used.';
}
export async function findAllBlockedTerms(text,config){
  const cfg=config||await getFilterConfig();
  const rawHits=findBlockedTerms(text);
  const hits=rawHits.filter(hit=>{
    const rawKey=deSpace(hit);
    const canonicalKey=deSpace(canonicalFilterTerm(hit));
    return !cfg.disabled.has(rawKey)&&!cfg.deleted?.has(rawKey)&&!cfg.deleted?.has(canonicalKey);
  });
  const compact=deSpace(text);
  for(const term of cfg.custom){
    const normalized=deSpace(term);
    if(normalized && compact.includes(normalized))hits.push('custom:'+term);
  }
  return [...new Set(hits)];
}
export function guessSourceLocale(text){
  const value=String(text||'');
  if(/[\u0600-\u06ff]/.test(value))return 'ar';
  if(/[\u0590-\u05ff]/.test(value))return 'he';
  if(/[\u0400-\u04ff]/.test(value))return 'ru';
  if(/[\u0370-\u03ff]/.test(value))return 'el';
  if(/[\u0900-\u097f]/.test(value))return 'hi';
  if(/[\u0980-\u09ff]/.test(value))return 'bn';
  if(/[\u0a00-\u0a7f]/.test(value))return 'pa';
  if(/[\u0b80-\u0bff]/.test(value))return 'ta';
  if(/[\u0c00-\u0c7f]/.test(value))return 'te';
  if(/[\u0d00-\u0d7f]/.test(value))return 'ml';
  if(/[\u0e00-\u0e7f]/.test(value))return 'th';
  if(/[\u3040-\u30ff]/.test(value))return 'ja';
  if(/[\uac00-\ud7af]/.test(value))return 'ko';
  if(/[\u4e00-\u9fff]/.test(value))return 'zh';
  return 'auto';
}
export async function translateText(text,target,source){
  const value=String(text||'').slice(0,500);
  const normalizeLocale=code=>{const raw=String(code||'en').trim();if(!raw)return'en';const p=raw.split('-');return p.length>1?p[0].toLowerCase()+'-'+p[1].toUpperCase():raw.toLowerCase()};
  const tl=normalizeLocale(target||'en').slice(0,12)||'en';
  const requestedSource=String(source||'auto').slice(0,12)||'auto';
  const sl=requestedSource==='auto'?guessSourceLocale(value):normalizeLocale(requestedSource);
  const providerTarget=tl.split('-')[0];
  if(!value)return '';
  if((sl==='en'||sl==='auto')&&providerTarget==='en'&&String(value).trim())return value;
  const tryGoogle=async()=>{
    const googleSource=sl==='auto'?'auto':sl.split('-')[0];
    const url='https://translate.googleapis.com/translate_a/single?client=gtx&sl='+encodeURIComponent(googleSource)+'&tl='+encodeURIComponent(providerTarget)+'&dt=t&q='+encodeURIComponent(value);
    const r=await fetch(url,{headers:{Accept:'application/json'}});
    if(!r.ok)return '';
    const data=await r.json();
    const translated=Array.isArray(data?.[0])?data[0].map(x=>String(x?.[0]||'')).join(''):'';
    return translated.trim();
  };
  const tryMemory=async()=>{
    const memorySource=sl==='auto'?'autodetect':sl;
    const url='https://api.mymemory.translated.net/get?q='+encodeURIComponent(value)+'&langpair='+encodeURIComponent(memorySource+'|'+tl);
    const r=await fetch(url,{headers:{Accept:'application/json'}});
    if(!r.ok)return '';
    const data=await r.json();
    const translated=String(data&&data.responseData&&data.responseData.translatedText||'');
    if(translated.toUpperCase().includes('PLEASE SELECT TWO DISTINCT LANGUAGES'))return '';
    return translated.trim();
  };
  try{
    const google=await tryGoogle();
    if(google&&google.toLowerCase()!==value.toLowerCase())return google;
  }catch(_){ }
  try{
    const memory=await tryMemory();
    if(memory)return memory;
  }catch(_){ }
  return value;
}
async function translatedChatMessage(message,targetLanguage,config){
  const target=String(targetLanguage||'en').trim().slice(0,12)||'en';
  const original=String(message&&message.message||'');
  if(!original)return '';
  const source=String(message&&message.source_language||'auto').trim().slice(0,12)||'auto';
  if(target==='en'&&source==='en')return original;
  const messageId=String(message&&message.id||'');
  if(messageId){
    const cached=await db.query('SELECT translated_message FROM chat_message_translations WHERE message_id=$1 AND target_language=$2 LIMIT 1',[messageId,target]);
    if(cached.rows[0]&&cached.rows[0].translated_message){
      const cachedText=String(cached.rows[0].translated_message);
      const cachedBlocked=await findAllBlockedTerms(cachedText,config);
      return cachedBlocked.length?'***':cachedText;
    }
  }
  const translated=await translateText(original,target,source);
  const translatedBlocked=await findAllBlockedTerms(translated,config);
  const safeTranslated=translatedBlocked.length?'***':translated;
  if(messageId&&translated&&translated!==original){
    await db.query('INSERT INTO chat_message_translations (message_id,target_language,translated_message,updated_at) VALUES ($1,$2,$3,NOW()) ON CONFLICT (message_id,target_language) DO UPDATE SET translated_message=EXCLUDED.translated_message,updated_at=NOW()',[messageId,target,safeTranslated]);
  }
  return safeTranslated;
}
export default async function(req,res){
  const user=req.user;
  if(!user)return res.status(401).json({error:'Sign in required to use chat.'});
  if(req.method==='GET'){
    const [{rows},filterConfig]=await Promise.all([
      db.query("SELECT c.id,c.user_id,c.username,COALESCE(up.display_name,'') AS display_name,c.message,c.created_at,c.message_type,c.edited_at,c.source_language,c.reply_to_id,rt.username AS reply_to_username,COALESCE(rp.display_name,rt.username,'User') AS reply_to_display_name,rt.message AS reply_to_message,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin FROM chat_messages c LEFT JOIN users u ON u.id=c.user_id LEFT JOIN user_profiles up ON up.user_id=c.user_id LEFT JOIN chat_messages rt ON rt.id=c.reply_to_id LEFT JOIN user_profiles rp ON rp.user_id=rt.user_id WHERE c.deleted_at IS NULL AND c.created_at>NOW()-INTERVAL '24 hours' AND NOT EXISTS (SELECT 1 FROM user_blocks b WHERE b.blocker_user_id=$1 AND b.blocked_user_id=c.user_id) ORDER BY c.created_at ASC LIMIT 100",[String(user.id)]),
      getFilterConfig()
    ]);
    const messages=[];
    for(const m of rows){
      if(m.message_type==='system'){messages.push({...m});continue;}
      const blocked=await findAllBlockedTerms(m.message,filterConfig);
      messages.push({...m,message:blocked.length?'***':m.message,translation_language:'en',translated:false,translation_pending:false,moderated:blocked.length>0});
    }
    return res.json({messages,language:'en',translation_pending:false});
  }
  const action=String(req.body?.action||'send');
  const id=String(req.body?.id||'').trim();
  if(action!=='delete'){
    const forwarded=String(req.headers?.['x-forwarded-for']||'').split(',')[0].trim();
    const requestIp=forwarded||String(req.headers?.['x-real-ip']||'').trim();
    const ipValue=requestIp||'';
    const [banResult,ipBanResult,warningResult]=await Promise.all([
      db.query("SELECT reason,expires_at,ban_type FROM banned_users WHERE user_id=$1 AND (ban_type='ACD' OR expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[String(user.id)]),
      ipValue?db.query("SELECT reason,expires_at FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[ipValue]):Promise.resolve({rows:[]}),
      db.query("SELECT id,reason,offensive_item FROM user_warnings WHERE user_id=$1 AND acknowledged_at IS NULL ORDER BY created_at DESC LIMIT 1",[String(user.id)])
    ]);
    const banRows=banResult.rows||[];
    if(banRows.length){
      const b=banRows[0];
      return res.status(403).json({error:String(b.reason||'Your account is currently banned.'),banned:true,ban_type:String(b.ban_type||'BAN'),expires_at:b.expires_at||null});
    }
    const ipBanRows=ipBanResult.rows||[];
    if(ipBanRows.length)return res.status(403).json({error:String(ipBanRows[0].reason||'Your IP address is currently banned.'),banned:true,ip_banned:true,ban_type:'IB',expires_at:ipBanRows[0].expires_at||null});
    const warningRows=warningResult.rows||[];
    if(warningRows.length){
      const w=warningRows[0];
      return res.status(403).json({error:String(w.reason||'Please acknowledge your warning before using chat.'),warning:true,warning_id:String(w.id),offensive_item:String(w.offensive_item||'')});
    }
  }
  if(action==='edit'){
    if(!id)return res.status(400).json({error:'Message id required.'});
    const message=String(req.body?.message||'').trim().slice(0,500);
    if(!message)return res.status(400).json({error:'Message cannot be empty.'});
    const {rows}=await db.query("SELECT id,user_id,username,message FROM chat_messages WHERE id=$1 AND deleted_at IS NULL LIMIT 1",[id]);
    if(!rows.length)return res.status(404).json({error:'Message not found.'});
    if(String(rows[0].user_id)!==String(user.id))return res.status(403).json({error:'You can only edit your own messages.'});
    const filterConfig=await getFilterConfig();
    const sourceLanguage=guessSourceLocale(message);
    const nativeMatched=await findAllBlockedTerms(message,filterConfig);
    const englishTranslation=await translateText(message,'en',sourceLanguage);
    const translatedMatched=englishTranslation&&englishTranslation!==message?await findAllBlockedTerms(englishTranslation,filterConfig):[];
    const matched=[...new Set([...nativeMatched,...translatedMatched])];
    if(matched.length)return res.status(403).json({error:'This message cannot be edited because the new text is filtered.',filtered:true,punishment:'edit_blocked'});
    await db.query("UPDATE chat_messages SET message=$2,edited_at=NOW() WHERE id=$1 AND user_id=$3 AND deleted_at IS NULL",[id,message,String(user.id)]);
    await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) VALUES ($1,$2,$3,$4,$5,$6,NULL,'user_edit')",[String(user.id),String(rows[0].username||'User'),String(user.email||''),message,String(rows[0].message),'Message edited by user']);
    return res.json({ok:true,edited_at:new Date().toISOString()});
  }
  if(action==='delete'){
    if(!id)return res.status(400).json({error:'Message id required.'});
    const {rows}=await db.query("SELECT id,user_id,username,message FROM chat_messages WHERE id=$1 AND deleted_at IS NULL LIMIT 1",[id]);
    if(!rows.length)return res.status(404).json({error:'Message not found.'});
    if(String(rows[0].user_id)!==String(user.id))return res.status(403).json({error:'You can only delete your own messages.'});
    const original=rows[0];
    await db.query("UPDATE chat_messages SET deleted_at=NOW(),deleted_by=$2 WHERE id=$1",[id,String(user.id)]);
    await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) VALUES ($1,$2,$3,$4,$4,$5,NULL,'user_delete')",[String(user.id),String(original.username||'User'),String(user.email||''),String(original.message),'Message deleted by user']);
    return res.json({ok:true});
  }
  const message=String(req.body?.message||'').trim().slice(0,500);
  const replyToId=String(req.body?.reply_to_id||'').trim()||null;
  if(!message)return res.status(400).json({error:'Message cannot be empty.'});
  let replyToMessage=null;
  if(replyToId){
    const {rows:replyRows}=await db.query("SELECT id,user_id,username,message,message_type,deleted_at FROM chat_messages WHERE id=$1 AND deleted_at IS NULL LIMIT 1",[replyToId]);
    const target=replyRows[0];
    if(!target||target.message_type==='system')return res.status(400).json({error:'The message you are replying to is unavailable.'});
    replyToMessage=target;
  }
  const [username,filterConfig]=await Promise.all([getUsername(user),getFilterConfig()]);
  const sourceLanguage=guessSourceLocale(message);
  const nativeMatched=await findAllBlockedTerms(message,filterConfig);
  const englishTranslation=await translateText(message,'en',sourceLanguage);
  const translatedMatched=englishTranslation&&englishTranslation!==message?await findAllBlockedTerms(englishTranslation,filterConfig):[];
  const matched=[...new Set([...nativeMatched,...translatedMatched])];
  let punishment=matched.length?punishmentForTerms(matched,filterConfig):null;
  if(matched.length){
    const matchedWord=primaryMatchedWord(matched);
    const autoReason=automaticFilterReason(matchedWord);
    const punishmentReasonSaved=String(filterConfig.punishmentReasons?.get(deSpace(canonicalFilterTerm(matchedWord)))||'').trim();
    const moderationReason=punishmentReasonSaved||autoReason;
    await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) VALUES ($1,$2,$3,$4,$4,$5,$6,'moderation')",[String(user.id),username,String(user.email||''),message,`Filtered message · punishment: ${punishment}`,matched.join(', ')]);
    const matchedCanonicalTerms=[...new Set(matched.map(raw=>canonicalFilterTerm(String(raw||'').replace(/^custom:/,''))).filter(Boolean))];
    const escalationRules=(filterConfig.warningRules||[]).filter(r=>r.enabled!==false&&matchedCanonicalTerms.includes(canonicalFilterTerm(r.filter_term))).sort((a,b)=>String(a.filter_term||'').localeCompare(String(b.filter_term||''))||Number(a.order_index??0)-Number(b.order_index??0)||String(a.id||'').localeCompare(String(b.id||'')));
    const hasEscalation=escalationRules.length>0;
    if(hasEscalation){
      const userId=String(user.id);
      const filterKey=canonicalFilterTerm(String(matchedWord||'')).toLowerCase();
      const nowMs=Date.now();
      const [{rows:cycleRows},{rows:settingRows}]=await Promise.all([
        db.query("SELECT warning_count,escalation_stage,last_violation_at FROM user_filter_escalation_cycles WHERE user_id=$1 AND filter_term=$2 LIMIT 1",[userId,filterKey]),
        db.query("SELECT escalation_reset_mode FROM moderation_settings WHERE id=1 LIMIT 1")
      ]);
      const cycle=cycleRows[0]||null;
      const resetMode=String(settingRows[0]?.escalation_reset_mode||'24h').toLowerCase()==='never'?'never':'24h';
      const cycleExpired=resetMode==='24h' && !!cycle?.last_violation_at && (nowMs-new Date(cycle.last_violation_at).getTime()>=24*60*60*1000);
      const storedStage=Math.max(0,Math.min(escalationRules.length,Number(cycle?.escalation_stage||0)));
      const storedTerminal=storedStage>=escalationRules.length && escalationRules.length>0;
      const previousCount=cycleExpired||storedTerminal?0:Math.max(0,Number(cycle?.warning_count||0));
      // escalation_stage is the next escalation rule allowed to fire.
      // A completed sequence is deliberately wrapped back to stage 0 after the
      // final rule fires, so the next violation starts a fresh cycle. Legacy terminal
      // rows are also treated as a completed cycle, including their warning count.
      const previousStage=cycleExpired||storedTerminal?0:storedStage;
      const activePreviousCount=previousCount;
      const warningCount=activePreviousCount+1;
      // `warning_count` is the number of prior violations/warnings in this filter's
      // current escalation cycle. By default a cycle expires after 24 hours without
      // another violation; admins can switch that policy to manual-only reset.
      // An escalation rule means "after N prior warnings, apply this action", so
      // base punishment Warn + rule `1 -> Ban` means violation #1 warns, #2 bans.
      // `escalation_stage` stores the next rule that is allowed to fire. Never scan
      // from rule #1 again after a rule has fired, otherwise the first ban/warn rule
      // becomes a permanent loop. A threshold is evaluated against prior violations:
      // rule `1 -> Ban` means violation #1 gets the base punishment, violation #2 fires Ban.
      // `escalation_stage` is the authoritative next-rule pointer. Never search earlier
      // rules again once a stage has fired. A rule fires only when the number of prior
      // violations in the current cycle has reached that stage's threshold.
      const startStage=Math.max(0,Math.min(escalationRules.length,previousStage));
      const candidateIndex=startStage;
      const candidateRule=candidateIndex>=0?escalationRules[candidateIndex]:null;
      const candidateThreshold=candidateRule?Number(candidateRule.warning_count):Infinity;
      // A higher threshold must never make a later escalation less likely than an earlier one.
      // Keep the chain flexible, but normalize thresholds at evaluation time so later rules
      // can trigger on the same or fewer violations when the action becomes more severe.
      let reachedIndex=-1;
      if(candidateRule&&Number.isFinite(candidateThreshold)){
        const effectiveThreshold=Math.max(1,Math.min(candidateThreshold, ...escalationRules.slice(0,candidateIndex+1).map(r=>Number(r.warning_count)).filter(Number.isFinite)));
        if(activePreviousCount>=effectiveThreshold) reachedIndex=candidateIndex;
      }
      const reachedRule=reachedIndex>=0?candidateRule:null;
      const stageIndex=startStage;
      const finalRuleReached=reachedIndex>=0 && reachedIndex===escalationRules.length-1;
      const afterRuleStage=reachedIndex>=0?(finalRuleReached?0:Math.min(escalationRules.length,reachedIndex+1)):stageIndex;
      const afterRuleWarningCount=reachedIndex>=0 && finalRuleReached?0:warningCount;
      if(reachedRule?.action==='ip_ban'){
        const {rows:ipRows}=await db.query("SELECT last_ip FROM user_last_ips WHERE user_id=$1 LIMIT 1",[userId]);
        const targetIp=String(ipRows[0]?.last_ip||'').trim();
        if(!targetIp)return res.status(400).json({error:'IP ban could not be applied because this account has no recorded IP address.'});
        const banSeconds=Math.max(0,Number(reachedRule.ban_duration_seconds??604800));
        const expiresAt=banSeconds===0?null:new Date(nowMs+banSeconds*1000);
        const ipReason=String(reachedRule?.reason||'').trim()||autoReason;
        await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,$4) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at",[targetIp,ipReason,message,expiresAt]);
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)",[userId,String(user.email||''),username,ipReason,message]);
        await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,afterRuleWarningCount,afterRuleStage]);
        return res.status(403).json({error:ipReason,ip_banned:true,reason:ipReason,offensive_item:message,filtered:true,punishment:'ip_ban',ban_duration_seconds:banSeconds,expires_at:expiresAt?.toISOString()||null,filter_term:matchedWord});
      }
      if(reachedRule?.action==='ban'){
        const banSeconds=Math.max(0,Number(reachedRule.ban_duration_seconds??604800));
        const permanent=banSeconds===0;
        const expiresAt=permanent?null:new Date(nowMs+banSeconds*1000);
        const banReason=String(reachedRule?.reason||'').trim()||autoReason;
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,$4,$5,$6)",[userId,String(user.email||''),username,permanent?'P':'BAN',banReason,message]);
        await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type=EXCLUDED.ban_type",[userId,String(user.email||''),banReason,message,expiresAt,permanent?'P':'BAN']);
        // Keep normal progress after a non-terminal rule. After the final rule,
        // immediately start a fresh cycle so the next violation is treated as #1.
        await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,afterRuleWarningCount,afterRuleStage]);
        return res.status(403).json({error:banReason,banned:true,reason:banReason,offensive_item:message,filtered:true,punishment:'ban',warning_count:warningCount,filter_term:matchedWord});
      }
      if(reachedRule?.action==='warn'){
        const warningReason=String(reachedRule.reason||'').trim()||moderationReason;
        const {rows:warningInsertRows}=await db.query("INSERT INTO user_warnings (user_id,filter_term,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,NULL,NULL) RETURNING id",[userId,filterKey,warningReason,message]);
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'W',$4,$5)",[userId,String(user.email||''),username,warningReason,message]);
        try{await notifyAdminsOfModeration('warn',username,warningReason);}catch(_){ }
        await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,afterRuleWarningCount,afterRuleStage]);
        return res.status(403).json({error:warningReason,warning:true,warning_id:warningInsertRows[0]?.id||null,offensive_item:message,filtered:true,punishment:'warn',warning_count:afterRuleWarningCount===0?0:warningCount,filter_term:matchedWord});
      }
      if(reachedRule?.action==='delete'){
        const cycleCountAfterDelete=afterRuleWarningCount;
        await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,cycleCountAfterDelete,afterRuleStage]);
        return res.status(201).json({message:null,filtered:true,deleted:true,punishment:'delete',filter_term:matchedWord});
      }
      if(!reachedRule){
        // Escalation is not due yet, so the filter's normal punishment still applies.
        // The escalation counter advances after that normal punishment, using the selected
        // per-user/per-filter reset policy.
        if(punishment==='warn'){
          await db.query("INSERT INTO user_warnings (user_id,filter_term,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,NULL,NULL)",[userId,filterKey,moderationReason,message]);
          await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'W',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
          try{await notifyAdminsOfModeration('warn',username,moderationReason);}catch(_){ }
        } else if(punishment==='delete'){
          await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,warningCount,stageIndex]);
          return res.status(201).json({message:null,filtered:true,deleted:true,punishment:'delete',filter_term:matchedWord});
        } else if(punishment==='ip_ban'){
          const {rows:ipRows}=await db.query("SELECT last_ip FROM user_last_ips WHERE user_id=$1 LIMIT 1",[userId]);
          const targetIp=String(ipRows[0]?.last_ip||'').trim();
          if(!targetIp)return res.status(400).json({error:'IP ban could not be applied because this account has no recorded IP address.'});
          await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,NULL) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL",[targetIp,moderationReason,message]);
          await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
          await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,warningCount,stageIndex]);
          return res.status(403).json({error:`Your IP address was banned for using a filtered word (${matchedWord}).`,banned:true,ip_banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ip_ban',expires_at:null});
        } else if(punishment==='ban'){
          const banSeconds=Math.max(0,Number(filterConfig.banDurations.get(deSpace(matchedWord))??604800));
          const expiresAt=banSeconds>0?new Date(nowMs+banSeconds*1000):null;
          await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'BAN',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
          await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type) VALUES ($1,$2,$3,$4,$5,'BAN') ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type='BAN'",[userId,String(user.email||''),moderationReason,message,expiresAt]);
          await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,warningCount,stageIndex]);
          return res.status(403).json({error:`Your account was banned for using a filtered word (${matchedWord}).`,banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ban',ban_duration_seconds:banSeconds,expires_at:expiresAt?.toISOString()||null});
        }
      }
      // Escalation thresholds are cumulative within the selected filter cycle.
      // Keep the count when advancing stages so a rule such as 2 -> Warn, 3 -> Ban
      // reaches the second rule on the third violation instead of requiring 3 more.
      const cycleCountAfterAction=warningCount;
      const cycleStageAfterAction=reachedRule?afterRuleStage:stageIndex;
      await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[userId,filterKey,cycleCountAfterAction,cycleStageAfterAction]);
      if(reachedRule?.action==='warn') punishment='warn';
    } else if(punishment==='warn' && !reachedRule) {
      await db.query("INSERT INTO user_warnings (user_id,filter_term,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,NULL,NULL)",[String(user.id),String(matchedWord||'').toLowerCase(),moderationReason,message]);
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'W',$4,$5)",[String(user.id),String(user.email||''),username,moderationReason,message]);
      try{await notifyAdminsOfModeration('warn',username,moderationReason);}catch(_){ }
    }
    if(punishment==='ip_ban'){
      const ipSeconds=0;
      const {rows:ipRows}=await db.query("SELECT last_ip FROM user_last_ips WHERE user_id=$1 LIMIT 1",[String(user.id)]);
      const targetIp=String(ipRows[0]?.last_ip||'').trim();
      if(!targetIp)return res.status(400).json({error:'IP ban could not be applied because this account has no recorded IP address.'});
      await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,NULL) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL",[targetIp,moderationReason,message]);
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)",[String(user.id),String(user.email||''),username,moderationReason,message]);
      return res.status(403).json({error:`Your IP address was banned for using a filtered word (${matchedWord}).`,banned:true,ip_banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ip_ban',ban_duration_seconds:ipSeconds,expires_at:null});
    }
    if(punishment==='ban'){
      const banSeconds=Math.max(0,Number(filterConfig.banDurations.get(deSpace(matchedWord))??604800));
      const expiresAt=banSeconds>0?new Date(Date.now()+banSeconds*1000):null;
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'BAN',$4,$5)",[String(user.id),String(user.email||''),username,moderationReason,message]);
      await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type) VALUES ($1,$2,$3,$4,$5,'BAN') ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type='BAN'",[String(user.id),String(user.email||''),moderationReason,message,expiresAt]);
      return res.status(403).json({error:`Your account was banned for using a filtered word (${matchedWord}).`,banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ban',ban_duration_seconds:banSeconds,expires_at:expiresAt?.toISOString()||null});
    }
    if(punishment==='delete')return res.status(201).json({message:null,filtered:true,deleted:true,punishment:'delete'});
  }
  const {rows}=await db.query("INSERT INTO chat_messages (user_id,username,message,message_type,source_language,reply_to_id) VALUES ($1,$2,$3,'user',$4,$5) RETURNING id,user_id,username,message,created_at,message_type,edited_at,source_language,reply_to_id",[String(user.id),username,message,'auto',replyToId]);
  res.status(201).json({message:rows[0],filtered:matched.length>0,punishment:punishment||null});
}

// Shared moderation helpers are exported at their function declarations above.