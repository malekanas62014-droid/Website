import { db, storage } from "hatchable";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
  const key=String(req.query?.key||'').trim();
  if(!key||!key.startsWith('moderation/'))return res.status(400).send('Attachment required.');
  try{
    const meta=await db.query(`
      SELECT attachment_name AS filename, attachment_type AS content_type
      FROM banned_users WHERE attachment_key=$1
      UNION ALL
      SELECT attachment_name AS filename, attachment_type AS content_type
      FROM user_warnings WHERE attachment_key=$1
      UNION ALL
      SELECT attachment_name AS filename, attachment_type AS content_type
      FROM ip_bans WHERE attachment_key=$1
      UNION ALL
      SELECT attachment_name AS filename, attachment_type AS content_type
      FROM ban_history WHERE attachment_key=$1
      LIMIT 1`,[key]);
    if(!meta.rows.length)return res.status(404).send('Attachment unavailable.');
    const file=await storage.get(key);
    if(!file?.buffer)return res.status(404).send('Attachment unavailable.');
    const name=String(meta.rows[0].filename||'evidence').replace(/[^a-zA-Z0-9._-]/g,'_');
    const type=String(meta.rows[0].content_type||file.contentType||'application/octet-stream');
    res.setHeader('Content-Type',type);
    res.setHeader('Content-Disposition',`inline; filename="${name}"`);
    res.setHeader('Cache-Control','private, no-store');
    return res.send(file.buffer);
  }catch(e){return res.status(404).send('Attachment unavailable.');}
}