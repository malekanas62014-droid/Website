import { db, auth } from "hatchable";

export const access = "public";
export const methods = ["GET","POST"];

export default async function(req,res){
  const user=await auth.getUser(req);
  const recipientId=user?String(user.id):'';
  if(!recipientId)return res.json({notifications:[]});

  if(req.method==='GET'){
    const {rows}=await db.query(`SELECT id,title,message,button_text,created_at,seen_at
      FROM troll_notifications
      WHERE recipient_id=$1
      ORDER BY created_at DESC,id DESC LIMIT 20`,[recipientId]);
    return res.json({notifications:rows});
  }

  const id=Number(req.body?.id);
  if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid Troll id.'});
  await db.query(`UPDATE troll_notifications SET seen_at=NOW()
    WHERE id=$1 AND recipient_id=$2`,[id,recipientId]);
  return res.json({ok:true});
}