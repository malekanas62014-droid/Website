import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

const RELEASE_VERSION = "635";

export default async function (req, res) {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  try {
    const { rows } = await db.query(
      "SELECT release_version, updated_at, release_title, release_summary, release_kind FROM manual_update_release WHERE id = 1 LIMIT 1"
    );
    const row = rows[0] || {};
    res.json({
      version: String(row.release_version || RELEASE_VERSION),
      updated_at: row.updated_at || null,
      title: String(row.release_title || ""),
      summary: String(row.release_summary || ""),
      kind: String(row.release_kind || "Update")
    });
  } catch (_) {
    res.json({ version: RELEASE_VERSION, title: "", summary: "", kind: "Update" });
  }
}