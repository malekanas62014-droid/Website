import { db, auth } from "hatchable";
import { isAdminUser } from "lib/admin-auth";
export const access = "public";
export const methods = ["GET"];
export default async function(req,res){
  const member=await auth.getUser(req);
  const admin=!!(member && await isAdminUser(member.id,member.email));
  const forwarded=String(req.headers?.['x-forwarded-for']||'').split(',')[0].trim();
  const ip=forwarded||String(req.headers?.['x-real-ip']||'').trim();
  if(!ip)return res.json({banned:false,admin});
  const {rows}=await db.query("SELECT reason,offensive_item,expires_at,attachment_key,attachment_name,attachment_type FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY banned_at DESC LIMIT 1",[ip]);
  if(!rows.length)return res.json({banned:false,admin});
  res.json({banned:true,admin,reason:rows[0].reason||'No reason provided',offensive_item:rows[0].offensive_item||'',expires_at:rows[0].expires_at,attachment_key:rows[0].attachment_key||'',attachment_name:rows[0].attachment_name||'',attachment_type:rows[0].attachment_type||''});
}