import { getVapidPublicKey } from "lib/web-push";
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  try{return res.json({ok:true,public_key:await getVapidPublicKey()});}
  catch(e){return res.status(503).json({error:'Push notifications are not ready yet.'});}
}