import { db } from "hatchable";
export const access="user";
export const methods=["GET","POST"];

const validSocial=['everyone','followers','nobody'];

export default async function(req,res){
  const userId=String(req.user.id);
  if(req.method==='GET'){
    try{
      const {rows}=await db.query("SELECT COALESCE(dm_existing_contacts,false) AS dm_existing_contacts,COALESCE(dm_restriction,'everyone') AS dm_restriction,COALESCE(social_stats_visibility,'everyone') AS social_stats_visibility FROM user_preferences WHERE user_id=$1 LIMIT 1",[userId]);
      const restriction=String(rows[0]?.dm_restriction||'everyone').toLowerCase();
      const social=String(rows[0]?.social_stats_visibility||'everyone').toLowerCase();
      return res.json({
        dm_enabled:restriction!=='off',
        dm_existing_contacts:rows.length?!!rows[0].dm_existing_contacts:false,
        dm_restriction:['everyone','friends','followers','off'].includes(restriction)?restriction:'everyone',
        social_stats_visibility:validSocial.includes(social)?social:'everyone'
      });
    }catch(e){
      return res.status(200).json({dm_enabled:true,dm_existing_contacts:false,dm_restriction:'everyone',social_stats_visibility:'everyone',fallback:true});
    }
  }
  const enabled=req.body?.dm_enabled;
  const existingContacts=req.body?.dm_existing_contacts;
  const requestedRestriction=String(req.body?.dm_restriction||'').trim().toLowerCase();
  const requestedSocial=String(req.body?.social_stats_visibility||'').trim().toLowerCase();
  if(typeof enabled!=='boolean' && typeof existingContacts!=='boolean' && !requestedRestriction && !requestedSocial)return res.status(400).json({error:'A DM or social privacy setting must be provided.'});
  const current=await db.query("SELECT COALESCE(dm_existing_contacts,false) AS dm_existing_contacts,COALESCE(dm_restriction,'everyone') AS dm_restriction,COALESCE(social_stats_visibility,'everyone') AS social_stats_visibility FROM user_preferences WHERE user_id=$1 LIMIT 1",[userId]);
  let nextRestriction=['everyone','friends','followers','off'].includes(requestedRestriction)?requestedRestriction:String(current.rows[0]?.dm_restriction||'everyone').toLowerCase();
  if(typeof enabled==='boolean' && !requestedRestriction)nextRestriction=enabled?'everyone':'off';
  const nextEnabled=nextRestriction!=='off';
  const nextExisting=typeof existingContacts==='boolean'?existingContacts:!!current.rows[0]?.dm_existing_contacts;
  const currentSocial=validSocial.includes(String(current.rows[0]?.social_stats_visibility||'').toLowerCase())?String(current.rows[0].social_stats_visibility).toLowerCase():'everyone';
  const nextSocial=validSocial.includes(requestedSocial)?requestedSocial:currentSocial;
  await db.query("INSERT INTO user_preferences (user_id,dm_enabled,dm_existing_contacts,dm_restriction,social_stats_visibility,updated_at) VALUES ($1,$2,$3,$4,$5,NOW()) ON CONFLICT (user_id) DO UPDATE SET dm_enabled=EXCLUDED.dm_enabled,dm_existing_contacts=EXCLUDED.dm_existing_contacts,dm_restriction=EXCLUDED.dm_restriction,social_stats_visibility=EXCLUDED.social_stats_visibility,updated_at=NOW()",[userId,nextEnabled,nextExisting,nextRestriction,nextSocial]);
  res.json({ok:true,dm_enabled:nextEnabled,dm_existing_contacts:nextExisting,dm_restriction:nextRestriction,social_stats_visibility:nextSocial});
}