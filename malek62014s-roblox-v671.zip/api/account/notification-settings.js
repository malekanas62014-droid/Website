import { db } from "hatchable";
export const access="user";

async function isAdmin(userId,email){
  if(String(email||'').trim().toLowerCase()==='robloxassetsowner@protonmail.com')return true;
  const {rows}=await db.query(`SELECT 1 FROM admin_user_directory WHERE is_admin=true AND (user_id=$1 OR lower(email)=lower($2)) LIMIT 1`,[String(userId||''),String(email||'')]);
  return rows.length>0;
}
export const methods=["GET","POST"];

export default async function(req,res){
  const userId=String(req.user.id);
  const admin=await isAdmin(userId,req.user.email);
  if(req.method==='GET'){
    const {rows}=await db.query(`SELECT
      COALESCE(notifications_enabled,true) AS notifications_enabled,
      COALESCE(notification_dm,true) AS notification_dm,
      COALESCE(notification_support,true) AS notification_support,
      COALESCE(notification_reports,true) AS notification_reports,
      COALESCE(notification_logins,true) AS notification_logins,
      COALESCE(notification_bans,true) AS notification_bans,
      COALESCE(notification_unbans,true) AS notification_unbans,
      COALESCE(notification_warnings,true) AS notification_warnings,
      COALESCE(notification_friend_requests,true) AS notification_friend_requests,
      COALESCE(notification_followers,true) AS notification_followers
      FROM user_preferences WHERE user_id=$1 LIMIT 1`,[userId]);
    const p=rows[0]||{};
    return res.json({
      notifications_enabled:rows.length?!!p.notifications_enabled:true,
      notification_dm:rows.length?!!p.notification_dm:true,
      notification_support:rows.length?!!p.notification_support:true,
      notification_reports:rows.length?!!p.notification_reports:true,
      notification_logins:rows.length?!!p.notification_logins:true,
      notification_friend_requests:rows.length?!!p.notification_friend_requests:true,
      notification_followers:rows.length?!!p.notification_followers:true,
      ...(admin?{
        notification_bans:rows.length?!!p.notification_bans:true,
        notification_unbans:rows.length?!!p.notification_unbans:true,
        notification_warnings:rows.length?!!p.notification_warnings:true,
        notification_friend_requests:rows.length?!!p.notification_friend_requests:true,
        notification_followers:rows.length?!!p.notification_followers:true
      }: {})
    });
  }
  const enabled=req.body?.notifications_enabled;
  const dm=req.body?.notification_dm;
  const support=req.body?.notification_support;
  const reports=req.body?.notification_reports;
  const logins=req.body?.notification_logins;
  const bans=req.body?.notification_bans;
  const unbans=req.body?.notification_unbans;
  const warnings=req.body?.notification_warnings;
  const friendRequests=req.body?.notification_friend_requests;
  const followers=req.body?.notification_followers;
  if(typeof enabled!=='boolean' && typeof dm!=='boolean' && typeof support!=='boolean' && typeof reports!=='boolean' && typeof logins!=='boolean' && typeof bans!=='boolean' && typeof unbans!=='boolean' && typeof warnings!=='boolean' && typeof friendRequests!=='boolean' && typeof followers!=='boolean')return res.status(400).json({error:'A notification setting must be provided.'});
  if((typeof bans==='boolean'||typeof unbans==='boolean'||typeof warnings==='boolean')&&!admin)return res.status(403).json({error:'Admin access required'});
  const {rows}=await db.query(`SELECT
    COALESCE(dm_enabled,true) AS dm_enabled,
    COALESCE(dm_existing_contacts,false) AS dm_existing_contacts,
    COALESCE(notifications_enabled,true) AS notifications_enabled,
    COALESCE(notification_dm,true) AS notification_dm,
    COALESCE(notification_support,true) AS notification_support,
    COALESCE(notification_reports,true) AS notification_reports,
    COALESCE(notification_logins,true) AS notification_logins,
    COALESCE(notification_bans,true) AS notification_bans,
    COALESCE(notification_unbans,true) AS notification_unbans,
    COALESCE(notification_warnings,true) AS notification_warnings,
    COALESCE(notification_friend_requests,true) AS notification_friend_requests,
    COALESCE(notification_followers,true) AS notification_followers
    FROM user_preferences WHERE user_id=$1 LIMIT 1`,[userId]);
  const cur=rows[0]||{};
  const next={
    enabled:typeof enabled==='boolean'?enabled:!!cur.notifications_enabled,
    dm:typeof dm==='boolean'?dm:!!cur.notification_dm,
    support:typeof support==='boolean'?support:!!cur.notification_support,
    reports:typeof reports==='boolean'?reports:!!cur.notification_reports,
    logins:typeof logins==='boolean'?logins:!!cur.notification_logins,
    bans:typeof bans==='boolean' && admin ? bans : !!cur.notification_bans,
    unbans:typeof unbans==='boolean' && admin ? unbans : !!cur.notification_unbans,
    warnings:typeof warnings==='boolean' && admin ? warnings : !!cur.notification_warnings,
    friendRequests:typeof friendRequests==='boolean'?friendRequests:!!cur.notification_friend_requests,
    followers:typeof followers==='boolean'?followers:!!cur.notification_followers
  };
  await db.query(`INSERT INTO user_preferences (user_id,dm_enabled,dm_existing_contacts,notifications_enabled,notification_dm,notification_support,notification_reports,notification_logins,notification_bans,notification_unbans,notification_warnings,notification_friend_requests,notification_followers,updated_at)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,NOW())
    ON CONFLICT (user_id) DO UPDATE SET
      dm_enabled=EXCLUDED.dm_enabled,
      dm_existing_contacts=EXCLUDED.dm_existing_contacts,
      notifications_enabled=EXCLUDED.notifications_enabled,
      notification_dm=EXCLUDED.notification_dm,
      notification_support=EXCLUDED.notification_support,
      notification_reports=EXCLUDED.notification_reports,
      notification_logins=EXCLUDED.notification_logins,
      notification_bans=EXCLUDED.notification_bans,
      notification_unbans=EXCLUDED.notification_unbans,
      notification_warnings=EXCLUDED.notification_warnings,
      notification_friend_requests=EXCLUDED.notification_friend_requests,
      notification_followers=EXCLUDED.notification_followers,
      updated_at=NOW()`,
    [userId,!!cur.dm_enabled,!!cur.dm_existing_contacts,next.enabled,next.dm,next.support,next.reports,next.logins,next.bans,next.unbans,next.warnings,next.friendRequests,next.followers]);
  return res.json({ok:true,notifications_enabled:next.enabled,notification_dm:next.dm,notification_support:next.support,notification_reports:next.reports,notification_logins:next.logins,...(admin?{notification_bans:next.bans,notification_unbans:next.unbans,notification_warnings:next.warnings}: {}),notification_friend_requests:next.friendRequests,notification_followers:next.followers});
}