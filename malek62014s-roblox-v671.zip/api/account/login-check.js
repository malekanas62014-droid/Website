import { db } from "hatchable";
export const access = "public";
export const methods = ["GET"];
export default async function(req,res){
  const email=String(req.query?.email||"").trim().toLowerCase();
  if(!email)return res.status(400).json({ok:false,error:"Email is required."});
  const forwarded=String(req.headers?.['x-forwarded-for']||'').split(',')[0].trim();
  const ip=forwarded||String(req.headers?.['x-real-ip']||'').trim();
  const {rows}=await db.query("SELECT d.email,COALESCE((SELECT h.reason FROM ban_history h WHERE lower(h.email)=lower(d.email) AND h.ban_type='AD' ORDER BY h.banned_at DESC LIMIT 1),'No reason provided') AS deletion_reason,COALESCE((SELECT h.offensive_item FROM ban_history h WHERE lower(h.email)=lower(d.email) AND h.ban_type='AD' ORDER BY h.banned_at DESC LIMIT 1),d.offensive_item,'') AS offensive_item FROM deleted_accounts d WHERE lower(d.email)=lower($1) LIMIT 1",[email]);
  if(rows.length)return res.json({ok:false,deleted:true,registered:true,username:'Account Deleted',deletion_reason:String(rows[0].deletion_reason||'No reason provided'),offensive_item:String(rows[0].offensive_item||''),error:'This account has been deleted and can no longer sign in.'});
  const {rows:accountRows}=await db.query("SELECT 1 FROM users WHERE lower(email)=lower($1) LIMIT 1",[email]);
  const registered=accountRows.length>0;
  if(ip){
    // An authenticated admin must remain able to reach the site/admin panel
    // even when testing an IP ban against their own public IP. Never trust
    // the email query parameter for this bypass; use the authenticated member.
    let isAdmin=false;
    const memberEmail=String(req.member?.email||'').trim().toLowerCase();
    if(memberEmail){
      if(memberEmail==='robloxassetsowner@protonmail.com') isAdmin=true;
      else {
        const {rows:adminRows}=await db.query("SELECT 1 FROM admin_user_directory WHERE lower(email)=lower($1) AND is_admin=true LIMIT 1",[memberEmail]);
        isAdmin=adminRows.length>0;
      }
    }
    if(!isAdmin){
      const {rows:ipRows}=await db.query("SELECT 1 FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[ip]);
      if(ipRows.length)return res.json({ok:false,ip_banned:true,error:"This IP address is banned and cannot sign in."});
    }
  }
  return res.json({ok:true,deleted:false,ip_banned:false,registered});
}