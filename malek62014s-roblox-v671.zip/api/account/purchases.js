import { db } from "hatchable";
export const access="user"; export const methods=["GET"];
export default async function(req,res){const {rows}=await db.query("SELECT asset_key FROM asset_purchases WHERE user_id=$1",[String(req.user.id)]);res.json({purchases:rows.map(x=>x.asset_key)});}