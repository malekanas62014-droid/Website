import { db } from "hatchable";
export const access="member";
export const methods=["POST"];

export default async function(req,res){
  const username=String(req.body?.username||'').trim();
  const id=String(req.member.id);
  if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return res.status(400).json({error:'Username must be 3-20 characters and use only letters, numbers, or _.'});

  const [{rows:currentRows},{rows:dupe}]=await Promise.all([
    db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[id]),
    db.query("SELECT user_id,username FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1",[username])
  ]);
  const current=String(currentRows[0]?.username||'');
  if(current.toLowerCase()===username.toLowerCase())return res.json({ok:true,username:current,charged:false});
  if(dupe.length&&String(dupe[0].user_id)!==id)return res.status(409).json({error:'That username is already taken.'});

  try{
    await db.query("INSERT INTO premium_wallets (user_id,coins,premium_access) VALUES ($1,0,false) ON CONFLICT (user_id) DO NOTHING",[id]);
    const result=await db.query("WITH charged AS (UPDATE premium_wallets SET coins=coins-25 WHERE user_id=$1 AND coins>=25 RETURNING user_id,coins), updated AS (INSERT INTO profile_usernames (user_id,username) SELECT $1,$2 FROM charged ON CONFLICT (user_id) DO UPDATE SET username=EXCLUDED.username RETURNING username), directory AS (UPDATE admin_user_directory SET username=$2,updated_at=NOW() WHERE user_id=$1 AND EXISTS (SELECT 1 FROM updated) RETURNING user_id) SELECT c.coins,u.username FROM charged c CROSS JOIN updated u",[id,username]);
    const row=result.rows?.[0];
    if(!row)return res.status(400).json({error:'You need 25 Coins to change your username.'});
    return res.json({ok:true,username:String(row.username||username),charged:true,coins:Number(row.coins||0)});
  }catch(error){
    if(String(error?.message||'').toLowerCase().includes('unique'))return res.status(409).json({error:'That username is already taken. Your Coins were not charged.'});
    throw error;
  }
}