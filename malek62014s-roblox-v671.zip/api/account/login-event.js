import { db } from "hatchable";
import { isAdminUser } from "lib/admin-auth";
import { sendWebPushToUsers } from "lib/web-push";
export const access="user";
export const methods=["POST"];

export default async function(req,res){
  const user=req.user;
  const userId=String(user.id||'').trim();
  const sessionKey=String(req.body?.session_key||'').trim().slice(0,160);
  if(!userId||!sessionKey)return res.status(400).json({error:'Login session is required.'});
  const username=String(user.handle||user.display_name||user.email||'User').replace(/[<>]/g,'').slice(0,50)||'User';
  const email=String(user.email||'').trim().toLowerCase();
  if(await isAdminUser(userId,email))return res.json({ok:true,recorded:false,reason:'admin'});
  const {rows}=await db.query(`INSERT INTO user_login_events (user_id,username,session_key)
    VALUES ($1,$2,$3)
    ON CONFLICT (user_id,session_key) DO NOTHING
    RETURNING id,username,created_at`,[userId,username,sessionKey]);
  if(rows.length){
    try{
      const {rows:admins}=await db.query("SELECT DISTINCT user_id FROM admin_user_directory WHERE is_admin=true AND user_id IS NOT NULL");
      const recipientIds=new Set(admins.map(x=>String(x.user_id)));
      const {rows:owner}=await db.query("SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1",['robloxassetsowner@protonmail.com']);
      if(owner[0]?.id)recipientIds.add(String(owner[0].id));
      const eligible=[];
      for(const recipientId of recipientIds){
        const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_logins,true) AS logins FROM user_preferences WHERE user_id=$1 LIMIT 1",[recipientId]);
        if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].logins!==false))eligible.push(recipientId);
      }
      await sendWebPushToUsers(eligible,'User Logged In','@'+username+' logged in.','login_'+String(rows[0].id));
    }catch(_){ }
  }
  return res.json({ok:true,recorded:rows.length>0,event:rows[0]||null});
}