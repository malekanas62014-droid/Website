import { db, auth } from "hatchable";
import { sendWebPushToUsers } from "lib/web-push";
export const access="public";
export const methods=["POST"];

const OWNER_EMAIL="robloxassetsowner@protonmail.com";
const GUEST_COOKIE="rbx_app_install_guest";

function cookieValue(req,name){
  const raw=String(req.headers?.cookie||'');
  const part=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));
  return part ? decodeURIComponent(part.slice(name.length+1)) : '';
}

function safeName(value,fallback){
  return String(value||fallback||'').replace(/[<>]/g,'').trim().slice(0,50)||fallback;
}

export default async function(req,res){
  const user=await auth.getUser(req);
  let identityId='';
  let displayName='';
  let guestCookie='';

  if(user?.id){
    const authId=String(user.id);
    const email=String(user.email||'').trim().toLowerCase();
    const {rows:account}=email?await db.query(`SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1`,[email]):{rows:[]};
    identityId=String(account[0]?.id||authId);
    displayName=safeName(user.name||user.email,'User');

    // If the app was installed before this person signed in, the install was
    // temporarily recorded against the browser's guest cookie. Claim that
    // existing install for the signed-in account so Admin > Manage shows it.
    guestCookie=cookieValue(req,GUEST_COOKIE);
    if(/^[a-zA-Z0-9_-]{16,100}$/.test(guestCookie)){
      const guestId='guest:'+guestCookie;
      const {rows:existing}=await db.query(`SELECT user_id FROM user_app_installs WHERE user_id=$1 LIMIT 1`,[identityId]);
      if(existing.length){
        await db.query(`DELETE FROM user_app_installs WHERE user_id=$1`,[guestId]);
      }else{
        await db.query(`UPDATE user_app_installs SET user_id=$1,last_seen_at=NOW() WHERE user_id=$2`,[identityId,guestId]);
      }
    }
  }else{
    guestCookie=cookieValue(req,GUEST_COOKIE);
    if(!/^[a-zA-Z0-9_-]{16,100}$/.test(guestCookie)){
      guestCookie=crypto.randomUUID().replace(/-/g,'');
      res.cookie(GUEST_COOKIE,guestCookie,{httpOnly:true,sameSite:'lax',secure:true,maxAge:31536000,path:'/'});
    }
    identityId='guest:'+guestCookie;
    displayName=`Guest[${guestCookie}]`;
  }

  const inserted=await db.query(`INSERT INTO user_app_installs (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING RETURNING user_id,installed_at`,[identityId]);
  await db.query(`UPDATE user_app_installs SET last_seen_at=NOW() WHERE user_id=$1`,[identityId]);
  const isNew=inserted.rowCount>0;

  // App installation tracking remains enabled, but app-install notifications have been removed.

  res.json({ok:true,new_install:isNew,anonymous:!user});
}