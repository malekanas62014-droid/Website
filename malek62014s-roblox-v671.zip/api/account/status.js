import { db } from "hatchable";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  const userId = String(req.user.id);
  const rewardState = await db.query(
    "SELECT total_claims, last_claim_date FROM daily_rewards WHERE user_id=$1 LIMIT 1",
    [userId]
  );
  const rewardClaims = Number(rewardState.rows[0]?.total_claims || 0);
  await db.query(
    `INSERT INTO premium_wallets (user_id, coins, last_reward_week)
     VALUES ($1, $2::int * 5, $3::date)
     ON CONFLICT (user_id) DO NOTHING`,
    [userId, rewardClaims, rewardState.rows[0]?.last_claim_date || new Date().toISOString().slice(0, 10)]
  );
  const { rows } = await db.query(
    `SELECT COALESCE(w.coins, $2::int * 5, 0) AS coins,
            COALESCE(w.premium_access, false) AS premium_access,
            COALESCE(w.last_reward_week, r.last_claim_date) AS last_reward_week,
            (COALESCE(w.last_reward_week, r.last_claim_date) = date_trunc('week', CURRENT_DATE)::date) AS weekly_claimed,
            COALESCE(p.username, $3) AS username
     FROM (SELECT $1::text AS user_id) u
     LEFT JOIN daily_rewards r ON r.user_id = u.user_id
     LEFT JOIN premium_wallets w ON w.user_id = u.user_id
     LEFT JOIN profile_usernames p ON p.user_id = u.user_id`,
    [userId, rewardClaims, req.user.handle || req.user.email || "User"]
  );
  res.json({
    coins: Number(rows[0]?.coins || 0),
    premium_access: !!rows[0]?.premium_access,
    username: rows[0]?.username,
    unlock_cost: 70,
    weekly_reward: 5,
    weekly_claimed: !!rows[0]?.weekly_claimed
  });
}