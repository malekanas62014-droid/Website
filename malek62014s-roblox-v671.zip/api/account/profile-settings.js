import { db, auth } from "hatchable";
export const access="user";
export const methods=["GET","POST"];
const cleanDisplay=v=>String(v??'').trim().replace(/\s+/g,' ').slice(0,20);
const cleanUsername=v=>String(v??'').trim().slice(0,20);
const cleanBio=v=>String(v??'').trim().replace(/\r/g,'').slice(0,300);
export default async function(req,res){
  const user=await auth.getUser(req);
  if(!user)return res.status(401).json({error:'Not signed in.'});
  const userId=String(user.id);
  if(req.method==='GET'){
    const [{rows:p},{rows:w}]=await Promise.all([
      db.query("SELECT COALESCE(p.username,'') AS username,COALESCE(up.display_name,'') AS display_name,COALESCE(up.bio,'') AS bio FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id WHERE u.id=$1 LIMIT 1",[userId]),
      db.query("SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1",[userId])
    ]);
    return res.json({username:String(p[0]?.username||''),display_name:String(p[0]?.display_name||''),bio:String(p[0]?.bio||''),coins:Number(w[0]?.coins||0),username_change_cost:25});
  }
  const type=String(req.body?.type||'').trim().toLowerCase();
  if(type==='username_reserve'){
    const result=await db.query("SELECT * FROM reserve_username_change($1)",[userId]);
    const row=result.rows[0];
    if(!row?.ok)return res.status(402).json({error:String(row?.error||'You don’t have enough Coins to change your username. You need 25 Coins.'),coins:Number(row?.coins||0),required:25});
    return res.json({ok:true,reservation_id:String(row.reservation_id),charged:true,coins:Number(row.coins||0),amount:25});
  }
  if(type==='username_refund'){
    const reservationId=String(req.body?.reservation_id||'').trim();
    if(!reservationId)return res.status(400).json({error:'Missing username change reservation.'});
    const result=await db.query("SELECT * FROM refund_username_change($1,$2::uuid)",[userId,reservationId]);
    const row=result.rows[0];
    return res.json({ok:true,refunded:!!row?.refunded,coins:Number(row?.coins||0),amount:Number(row?.amount||0),message:String(row?.message||'Coins were already settled.')});
  }
  if(type==='username_check'){
    const username=cleanUsername(req.body?.value);
    if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return res.json({ok:true,available:false,reason:'Username must be 3–20 characters and use only letters, numbers, or underscores.'});
    const [{rows:currentRows},{rows:existing}]=await Promise.all([
      db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[userId]),
      db.query("SELECT user_id,username FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1",[username])
    ]);
    const current=String(currentRows[0]?.username||'');
    if(current.toLowerCase()===username.toLowerCase())return res.json({ok:true,available:true,same_as_current:true,username:current});
    if(existing.length&&String(existing[0].user_id)!==userId)return res.json({ok:true,available:false,reason:'That username is already taken.',taken_username:String(existing[0].username||'')});
    return res.json({ok:true,available:true,username});
  }
  if(type==='username_commit'){
    const username=cleanUsername(req.body?.value);
    const reservationId=String(req.body?.reservation_id||'').trim();
    if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return res.status(400).json({error:'Username must be 3–20 characters and use only letters, numbers, or underscores.'});
    if(!reservationId)return res.status(400).json({error:'Missing username change reservation.'});
    const [{rows:currentRows},{rows:existing}]=await Promise.all([
      db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[userId]),
      db.query("SELECT user_id,username FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1",[username])
    ]);
    const current=String(currentRows[0]?.username||'');
    if(current.toLowerCase()===username.toLowerCase())return res.status(400).json({error:'Enter a different username.'});
    if(existing.length&&String(existing[0].user_id)!==userId)return res.status(409).json({error:'That username is already taken. Your Coins are still reserved; choose another username.'});
    try{
      const tx=await db.transaction([
        {sql:"UPDATE profile_usernames SET username=$1 WHERE user_id=$2 RETURNING username",params:[username,userId]},
        {sql:"INSERT INTO profile_usernames (user_id,username) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM profile_usernames WHERE user_id=$1) RETURNING username",params:[userId,username]},
        {sql:"UPDATE admin_user_directory SET username=$1,updated_at=NOW() WHERE user_id=$2",params:[username,userId]},
        {sql:"UPDATE username_change_reservations SET status='settled',settled_at=NOW() WHERE id=$1::uuid AND user_id=$2 AND status='pending' RETURNING amount",params:[reservationId,userId]},
        {sql:"SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1",params:[userId]}
      ]);
      const settled=tx.results[3]?.rows?.[0];
      if(!settled)return res.status(400).json({error:'This username change reservation is no longer active.'});
      const saved=tx.results[0]?.rows?.[0]?.username||tx.results[1]?.rows?.[0]?.username||username;
      const coins=Number(tx.results[4]?.rows?.[0]?.coins||0);
      return res.json({ok:true,committed:true,username:String(saved),charged:true,coins});
    }catch(error){
      if(String(error?.message||'').toLowerCase().includes('unique'))return res.status(409).json({error:'That username is already taken. Your Coins were not charged.'});
      throw error;
    }
  }
  if(type==='bio'){
    const bio=cleanBio(req.body?.value);
    const {rows}=await db.query("INSERT INTO user_profiles (user_id,bio,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET bio=EXCLUDED.bio,updated_at=NOW() RETURNING bio",[userId,bio]);
    return res.json({ok:true,bio:String(rows[0]?.bio||bio)});
  }
  if(type==='display_name'){
    const displayName=cleanDisplay(req.body?.value);
    if(displayName.length<3||displayName.length>20)return res.status(400).json({error:'Display name must be 3–20 characters.'});
    if(!/^[\p{L}\p{N} _.-]+$/u.test(displayName))return res.status(400).json({error:'Display name can use letters, numbers, spaces, underscores, periods, and hyphens.'});
    const {rows}=await db.query("INSERT INTO user_profiles (user_id,display_name,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET display_name=EXCLUDED.display_name,updated_at=NOW() RETURNING display_name",[userId,displayName]);
    return res.json({ok:true,display_name:String(rows[0]?.display_name||displayName),coins:null});
  }
  if(type==='username'){
    const username=cleanUsername(req.body?.value);
    return res.status(400).json({error:'Use the username change editor to change your username.'});
  }
  return res.status(400).json({error:'Choose Username or Display Name.'});
}