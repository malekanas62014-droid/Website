import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

function maskEmail(email) {
  const value = String(email || "").trim();
  const at = value.indexOf("@");
  if (at <= 0) return "your registered email address";
  const local = value.slice(0, at);
  const domain = value.slice(at + 1);
  if (!domain) return "your registered email address";
  if (local.length <= 2) return `${local[0] || "•"}***@${domain}`;
  return `${local[0]}${"•".repeat(Math.max(2, Math.min(5, local.length - 2)))}${local.slice(-1)}@${domain}`;
}

export default async function (req, res) {
  const username = String(req.query?.username || "").trim();
  if (!username) return res.status(400).json({ ok: false, error: "Username is required." });
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
    return res.status(400).json({ ok: false, error: "Enter a valid username." });
  }

  const { rows } = await db.query(
    `SELECT lower(u.email) AS email
       FROM profile_usernames p
       JOIN users u ON u.id = p.user_id
      WHERE lower(p.username) = lower($1)
      LIMIT 1`,
    [username]
  );

  if (!rows.length) {
    return res.status(404).json({ ok: false, error: "We couldn't find an account with that username." });
  }

  const email = String(rows[0].email || "").trim().toLowerCase();
  if (!email) {
    return res.status(404).json({ ok: false, error: "This account does not have a usable registered email address." });
  }

  return res.json({ ok: true, email, masked_email: maskEmail(email) });
}