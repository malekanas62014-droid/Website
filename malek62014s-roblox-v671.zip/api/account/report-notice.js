import { db } from "hatchable";
export const access="user";
export const methods=["GET","POST"];
export default async function(req,res){
  const user=req.user;
  const uid=String(user.id);
  if(req.method==='GET'){
    const {rows}=await db.query("SELECT id,category,details,status,resolution_outcome,resolved_at FROM user_reports WHERE reporter_user_id=$1 AND status IN ('resolved','denied') AND reporter_notice_acknowledged_at IS NULL ORDER BY resolved_at DESC LIMIT 1",[uid]);
    return res.json({notice:rows[0]||null});
  }
  const id=String(req.body?.id||'').trim();
  if(!id)return res.status(400).json({error:'Report id required.'});
  const {rowCount}=await db.query("UPDATE user_reports SET reporter_notice_acknowledged_at=NOW() WHERE id=$1 AND reporter_user_id=$2 AND status IN ('resolved','denied') AND reporter_notice_acknowledged_at IS NULL",[id,uid]);
  if(!rowCount)return res.status(404).json({error:'Report notice not found.'});
  res.json({ok:true});
}