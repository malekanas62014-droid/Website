import { db } from "hatchable";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  const identity = req.user || req.member || null;
  const memberId = String(identity?.id || "").trim();
  let email = String(identity?.email || "").trim().toLowerCase();
  if (!email && memberId) {
    const { rows } = await db.query("SELECT lower(email) AS email FROM users WHERE id = $1 LIMIT 1", [memberId]);
    email = String(rows[0]?.email || "").trim().toLowerCase();
  }
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  if (email === "robloxassetsowner@protonmail.com") return res.json({ is_admin: true });
  const { rows: adminRows } = await db.query(
    "SELECT 1 FROM admin_user_directory WHERE is_admin = true AND (user_id = $1 OR lower(email) = lower($2)) LIMIT 1",
    [memberId, email]
  );
  res.json({ is_admin: adminRows.length > 0 });
}