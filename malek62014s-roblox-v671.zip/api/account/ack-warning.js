import { db } from "hatchable";
export const access = "user";
export const methods = ["POST"];
export default async function(req,res){
  const user=req.user||req.member;
  if(!user?.id)return res.status(401).json({error:"Sign in required."});
  const id=String(req.body?.id||'').trim();
  if(!id)return res.status(400).json({error:"Warning id is required."});
  const {rowCount}=await db.query("UPDATE user_warnings SET acknowledged_at=NOW() WHERE id=$1 AND user_id=$2 AND acknowledged_at IS NULL",[id,String(user.id)]);
  if(!rowCount)return res.status(404).json({error:"Warning not found or already acknowledged."});
  res.json({ok:true});
}