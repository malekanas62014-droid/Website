import { saveSubscription, removeSubscription } from "lib/web-push";
export const access='user';
export const methods=['POST','DELETE'];
export default async function(req,res){
  const userId=String(req.user?.id||'').trim();
  if(!userId)return res.status(401).json({error:'Sign in required.'});
  const subscription=req.body?.subscription||req.body||{};
  const endpoint=String(subscription.endpoint||'').trim().slice(0,2000);
  const p256dh=String(subscription.keys?.p256dh||'').trim();
  const auth=String(subscription.keys?.auth||'').trim();
  if(req.method==='DELETE'){
    if(endpoint)await removeSubscription(userId,endpoint);
    return res.json({ok:true});
  }
  if(!endpoint||!p256dh||!auth)return res.status(400).json({error:'Invalid push subscription.'});
  if(!/^https:\/\//i.test(endpoint))return res.status(400).json({error:'Invalid push endpoint.'});
  await saveSubscription(userId,{endpoint,p256dh,auth});
  return res.json({ok:true});
}