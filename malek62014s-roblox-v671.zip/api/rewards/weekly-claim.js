import { db } from "hatchable";

export const access = "user";
export const methods = ["POST"];

export default async function (req, res) {
  const userId = String(req.user.id);
  const weekStart = new Date();
  const day = weekStart.getUTCDay();
  weekStart.setUTCDate(weekStart.getUTCDate() - ((day + 6) % 7));
  const week = weekStart.toISOString().slice(0, 10);
  const previousWeekDate = new Date(weekStart);
  previousWeekDate.setUTCDate(previousWeekDate.getUTCDate() - 7);
  const previousWeek = previousWeekDate.toISOString().slice(0, 10);

  await db.query(
    "INSERT INTO daily_rewards (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING",
    [userId]
  );
  await db.query(
    "INSERT INTO premium_wallets (user_id, coins) VALUES ($1, 0) ON CONFLICT (user_id) DO NOTHING",
    [userId]
  );

  const claimed = await db.query(
    "UPDATE daily_rewards SET last_claim_date=$2::date, streak=CASE WHEN last_claim_date=$3::date THEN streak+1 ELSE 1 END, total_claims=total_claims+1, updated_at=NOW() WHERE user_id=$1 AND (last_claim_date IS NULL OR last_claim_date<>$2::date) RETURNING streak",
    [userId, week, previousWeek]
  );
  if (!claimed.rows.length) {
    const current = await db.query("SELECT streak FROM daily_rewards WHERE user_id=$1 LIMIT 1", [userId]);
    const wallet = await db.query("SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1", [userId]);
    return res.status(409).json({
      error: "Weekly reward already claimed.",
      claimed: true,
      streak: Number(current.rows[0]?.streak || 0),
      coins: Number(wallet.rows[0]?.coins || 0)
    });
  }

  const nextStreak = Number(claimed.rows[0]?.streak || 1);
  let wallet = await db.query(
    "UPDATE premium_wallets SET coins=coins+5, last_reward_week=$2::date WHERE user_id=$1 RETURNING coins",
    [userId, week]
  );
  if (!wallet.rows.length) {
    wallet = await db.query(
      "INSERT INTO premium_wallets (user_id, coins, last_reward_week) VALUES ($1, 5, $2::date) ON CONFLICT (user_id) DO UPDATE SET coins=premium_wallets.coins+5,last_reward_week=EXCLUDED.last_reward_week RETURNING coins",
      [userId, week]
    );
  }

  res.json({
    ok: true,
    claimed: true,
    reward_coins: 5,
    streak: nextStreak,
    coins: Number(wallet.rows[0]?.coins || 0)
  });
}