import { db } from "hatchable";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  const userId = String(req.user.id);
  const weekStart = new Date();
  const day = weekStart.getUTCDay();
  weekStart.setUTCDate(weekStart.getUTCDate() - ((day + 6) % 7));
  const week = weekStart.toISOString().slice(0, 10);

  await db.query("INSERT INTO daily_rewards (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING", [userId]);
  const { rows } = await db.query(
    "SELECT last_claim_date, streak, total_claims FROM daily_rewards WHERE user_id=$1 LIMIT 1",
    [userId]
  );
  const row = rows[0] || {};
  const claimed = !!row.last_claim_date && String(row.last_claim_date).slice(0, 10) === week;

  res.json({
    claimed_today: claimed,
    weekly_claimed: claimed,
    streak: Number(row.streak || 0),
    total_claims: Number(row.total_claims || 0),
    reward_coins: 5
  });
}