import { db, storage } from "hatchable";
import { sendWebPushToUsers } from "lib/web-push";
export const access="user";
export const methods=["POST"];

const MAX_ATTACHMENTS=5;
const MAX_FILE_BYTES=80*1024*1024;

function safeFilename(name){
  return String(name||'proof').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,160) || 'proof';
}

export default async function(req,res){
  const reporter=req.user;
  const body=req.body||{};
  const files=Array.isArray(req.files)?req.files:[];
  const reportedUserId=String(body.reported_user_id||'').trim();
  const category=String(body.category||'Other').trim().slice(0,40);
  const details=String(body.details||'').trim().slice(0,1000);
  const sourceType=['help_chat','dm','user'].includes(String(body.source_type))?String(body.source_type):'user';
  const sourceMessageId=String(body.source_message_id||'').trim().slice(0,120);
  if(!reportedUserId)return res.status(400).json({error:'User to report is required.'});
  if(reportedUserId===String(reporter.id))return res.status(400).json({error:'You cannot report yourself.'});
  if(files.length>MAX_ATTACHMENTS)return res.status(400).json({error:'You can attach a maximum of 5 files.'});
  for(const file of files){
    if(!file?.buffer || file.buffer.length>MAX_FILE_BYTES)return res.status(400).json({error:'Each attachment must be 80 MB or smaller.'});
  }
  const {rows:reported}=await db.query("SELECT p.user_id,p.username,u.email FROM profile_usernames p JOIN users u ON u.id=p.user_id WHERE p.user_id=$1 LIMIT 1",[reportedUserId]);
  if(!reported.length)return res.status(404).json({error:'User not found.'});
  const {rows:rep}=await db.query("SELECT p.username,u.email FROM profile_usernames p JOIN users u ON u.id=p.user_id WHERE p.user_id=$1 LIMIT 1",[String(reporter.id)]);
  const reporterUsername=String(rep[0]?.username||reporter.handle||reporter.display_name||'User');
  const {rows}=await db.query("INSERT INTO user_reports (reporter_user_id,reporter_username,reported_user_id,reported_username,category,details,source_type,source_message_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,created_at,status,source_type,source_message_id",[String(reporter.id),reporterUsername,reportedUserId,String(reported[0].username||'User'),category,details,sourceType,sourceMessageId||null]);
  const report=rows[0];
  try{
    const {rows:admins}=await db.query("SELECT DISTINCT user_id FROM admin_user_directory WHERE is_admin=true AND user_id IS NOT NULL");
    const ids=admins.map(x=>String(x.user_id));
    const {rows:owner}=await db.query("SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1",['robloxassetsowner@protonmail.com']);
    if(owner[0]?.id)ids.push(String(owner[0].id));
    const eligible=[];
    for(const id of [...new Set(ids)]){
      const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_reports,true) AS reports FROM user_preferences WHERE user_id=$1 LIMIT 1",[id]);
      if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].reports!==false))eligible.push(id);
    }
    await sendWebPushToUsers(eligible,'New report','@'+reporterUsername+' reported @'+String(reported[0].username||'User')+' · '+category,'report_'+String(report.id));
  }catch(_){ }
  for(const file of files){
    const filename=safeFilename(file.filename);
    const key=`reports/${report.id}/${crypto.randomUUID()}-${filename}`;
    await storage.put(key,file.buffer,file.contentType||'application/octet-stream');
    await db.query("INSERT INTO user_report_attachments (report_id,filename,content_type,storage_key,size_bytes) VALUES ($1,$2,$3,$4,$5)",[report.id,filename,file.contentType||'application/octet-stream',key,file.buffer.length]);
  }
  res.status(201).json({ok:true,report,attachments:files.length});
}