import { db } from "hatchable";
export const access="user";
export const methods=["GET","POST"];

const pair=(a,b)=>{const x=String(a),y=String(b);return x<y?[x,y]:[y,x]};
const allowedVisibility=v=>['everyone','followers','nobody'].includes(String(v||'').toLowerCase())?String(v).toLowerCase():'everyone';

async function viewerCanSeeStats(me,target){
  if(String(me)===String(target))return true;
  const {rows}=await db.query(`SELECT COALESCE(up.social_stats_visibility,'everyone') AS visibility,
    EXISTS(SELECT 1 FROM user_follows WHERE follower_user_id=$1 AND followed_user_id=$2) AS viewer_follows_target,
    EXISTS(SELECT 1 FROM user_follows WHERE follower_user_id=$2 AND followed_user_id=$1) AS target_follows_viewer
    FROM users u LEFT JOIN user_preferences up ON up.user_id=u.id WHERE u.id=$2 LIMIT 1`,[String(me),String(target)]);
  if(!rows.length)return false;
  const v=allowedVisibility(rows[0].visibility);
  if(v==='nobody')return false;
  if(v==='followers')return !!rows[0].viewer_follows_target;
  return true;
}

async function socialList(me,target,type){
  const canSee=await viewerCanSeeStats(me,target);
  if(!canSee)return {visible:false,items:[]};
  let rows=[];
  if(type==='friends'){
    ({rows}=await db.query(`SELECT u.id AS user_id,COALESCE(p.username,u.name,u.email,'User') AS username,COALESCE(up.display_name,'') AS display_name,u.image,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin
      FROM user_friendships f JOIN users u ON u.id=CASE WHEN f.user_a=$1 THEN f.user_b ELSE f.user_a END
      LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
      WHERE f.user_a=$1 OR f.user_b=$1 ORDER BY COALESCE(p.username,u.name,u.email,'User') ASC`,[String(target)]));
  }else if(type==='followers'){
    ({rows}=await db.query(`SELECT u.id AS user_id,COALESCE(p.username,u.name,u.email,'User') AS username,COALESCE(up.display_name,'') AS display_name,u.image,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin
      FROM user_follows f JOIN users u ON u.id=f.follower_user_id
      LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
      WHERE f.followed_user_id=$1 ORDER BY COALESCE(p.username,u.name,u.email,'User') ASC`,[String(target)]));
  }else{
    ({rows}=await db.query(`SELECT u.id AS user_id,COALESCE(p.username,u.name,u.email,'User') AS username,COALESCE(up.display_name,'') AS display_name,u.image,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin
      FROM user_follows f JOIN users u ON u.id=f.followed_user_id
      LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
      WHERE f.follower_user_id=$1 ORDER BY COALESCE(p.username,u.name,u.email,'User') ASC`,[String(target)]));
  }
  return {visible:true,items:(rows||[]).map(x=>({user_id:String(x.user_id),username:String(x.username||'User'),display_name:String(x.display_name||''),image:x.image||null,is_verified:!!x.is_verified,is_creator:!!x.is_creator,is_admin:!!x.is_admin}))};
}

export default async function(req,res){
  const me=String(req.user.id);
  if(req.method==='GET'){
    const target=String(req.query?.user_id||'').trim();
    if(!target)return res.status(400).json({error:'User id is required.'});
    const type=String(req.query?.list||'').toLowerCase();
    if(['friends','followers','following'].includes(type))return res.json(await socialList(me,target,type));
    const [{rows:p},{rows:counts},{rows:rel},{rows:pending},{rows:privacy}]=await Promise.all([
      db.query("SELECT u.id AS user_id,COALESCE(p.username,u.name,u.email,'User') AS username,COALESCE(up.display_name,'') AS display_name,COALESCE(up.bio,'') AS bio,u.image,COALESCE(up.is_verified,false) AS is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS is_admin FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id WHERE u.id=$1 LIMIT 1",[target]),
      db.query("SELECT (SELECT COUNT(*) FROM user_follows WHERE followed_user_id=$1)::int AS followers,(SELECT COUNT(*) FROM user_follows WHERE follower_user_id=$1)::int AS following,(SELECT COUNT(*) FROM user_friendships WHERE user_a=$1 OR user_b=$1)::int AS friends",[target]),
      db.query("SELECT EXISTS(SELECT 1 FROM user_follows WHERE follower_user_id=$1 AND followed_user_id=$2) AS following, EXISTS(SELECT 1 FROM user_follows WHERE follower_user_id=$2 AND followed_user_id=$1) AS follows_me, EXISTS(SELECT 1 FROM user_friendships WHERE (user_a=$1 AND user_b=$2) OR (user_a=$2 AND user_b=$1)) AS friends",[me,target]),
      db.query("SELECT status,sender_user_id,recipient_user_id FROM friend_requests WHERE status='pending' AND ((sender_user_id=$1 AND recipient_user_id=$2) OR (sender_user_id=$2 AND recipient_user_id=$1)) ORDER BY created_at DESC LIMIT 1",[me,target]),
      db.query("SELECT COALESCE(social_stats_visibility,'everyone') AS social_stats_visibility FROM user_preferences WHERE user_id=$1 LIMIT 1",[target])
    ]);
    if(!p.length)return res.status(404).json({error:'User not found.'});
    const r=rel[0]||{};const f=pending[0]||null;
    let friendRequestStatus=null;if(f)friendRequestStatus=String(f.sender_user_id)===me?'sent':'received';
    const visible=await viewerCanSeeStats(me,target);
    return res.json({profile:{...p[0],username:String(p[0].username||'User'),display_name:String(p[0].display_name||''),is_creator:!!p[0].is_creator,is_admin:!!p[0].is_admin,is_verified:!!p[0].is_verified},counts:visible?{followers:Number(counts[0]?.followers||0),following:Number(counts[0]?.following||0),friends:Number(counts[0]?.friends||0)}:{followers:null,following:null,friends:null},stats_visibility:allowedVisibility(privacy[0]?.social_stats_visibility||'everyone'),stats_visible:visible,relationship:{following:!!r.following,follows_me:!!r.follows_me,friends:!!r.friends,friend_request:friendRequestStatus}});
  }

  const target=String(req.body?.user_id||'').trim();
  const action=String(req.body?.action||'').trim().toLowerCase();
  if(action==='set_stats_visibility'){
    const requested=String(req.body?.visibility||'').trim().toLowerCase();
    if(!['everyone','followers','nobody'].includes(requested))return res.status(400).json({error:'Invalid stats visibility.'});
    await db.query("INSERT INTO user_preferences (user_id,social_stats_visibility,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET social_stats_visibility=EXCLUDED.social_stats_visibility,updated_at=NOW()",[me,requested]);
    return res.json({ok:true,stats_visibility:requested});
  }
  if(!target)return res.status(400).json({error:'User id is required.'});
  const exists=await db.query("SELECT 1 FROM users WHERE id=$1 LIMIT 1",[target]);
  if(!exists.rows.length)return res.status(404).json({error:'User not found.'});
  if(action==='follow'||action==='unfollow'){
    if(action==='follow')await db.query("INSERT INTO user_follows (follower_user_id,followed_user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",[me,target]);
    else await db.query("DELETE FROM user_follows WHERE follower_user_id=$1 AND followed_user_id=$2",[me,target]);
    return res.json({ok:true,following:action==='follow'});
  }
  if(action==='friend_request'){
    const [a,b]=pair(me,target);
    const friend=await db.query("SELECT 1 FROM user_friendships WHERE user_a=$1 AND user_b=$2 LIMIT 1",[a,b]);
    if(friend.rows.length)return res.json({ok:true,status:'friends'});
    const reverse=await db.query("SELECT id FROM friend_requests WHERE sender_user_id=$1 AND recipient_user_id=$2 AND status='pending' LIMIT 1",[target,me]);
    if(reverse.rows.length){
      await db.transaction([{sql:"UPDATE friend_requests SET status='accepted',updated_at=NOW() WHERE id=$1",params:[reverse.rows[0].id]},{sql:"INSERT INTO user_friendships (user_a,user_b) VALUES ($1,$2) ON CONFLICT DO NOTHING",params:[a,b]},{sql:"DELETE FROM friend_requests WHERE sender_user_id=$1 AND recipient_user_id=$2 AND status='pending'",params:[me,target]}]);
      return res.json({ok:true,status:'friends'});
    }
    await db.query("INSERT INTO friend_requests (sender_user_id,recipient_user_id,status,updated_at) VALUES ($1,$2,'pending',NOW()) ON CONFLICT (sender_user_id,recipient_user_id) DO UPDATE SET status='pending',updated_at=NOW()",[me,target]);
    return res.json({ok:true,status:'sent'});
  }
  if(action==='accept_friend'||action==='decline_friend'){
    const {rows}=await db.query("SELECT id,sender_user_id FROM friend_requests WHERE sender_user_id=$1 AND recipient_user_id=$2 AND status='pending' ORDER BY created_at DESC LIMIT 1",[target,me]);
    if(!rows.length)return res.status(404).json({error:'Friend request not found.'});
    if(action==='decline_friend'){await db.query("UPDATE friend_requests SET status='declined',updated_at=NOW() WHERE id=$1",[rows[0].id]);return res.json({ok:true,status:'declined'});}
    const [a,b]=pair(me,target);
    await db.transaction([{sql:"UPDATE friend_requests SET status='accepted',updated_at=NOW() WHERE id=$1",params:[rows[0].id]},{sql:"INSERT INTO user_friendships (user_a,user_b) VALUES ($1,$2) ON CONFLICT DO NOTHING",params:[a,b]}]);
    return res.json({ok:true,status:'friends'});
  }
  if(action==='remove_friend'){
    const [a,b]=pair(me,target);
    await db.query("DELETE FROM user_friendships WHERE user_a=$1 AND user_b=$2",[a,b]);
    return res.json({ok:true,status:'none'});
  }
  return res.status(400).json({error:'Unknown social action.'});
}