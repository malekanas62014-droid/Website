import { db, storage } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="public";
export const methods=["GET"];

export default async function(req,res){
  const id=String(req.params?.id||'').trim();
  if(!id)return res.status(400).send('Attachment id required.');
  const {rows}=await db.query("SELECT a.filename,a.content_type,a.storage_key,r.reporter_user_id FROM user_report_attachments a JOIN user_reports r ON r.id=a.report_id WHERE a.id=$1 LIMIT 1",[id]);
  if(!rows.length)return res.status(404).send('Attachment not found.');
  const isAdmin=await assertAdmin(req);
  const isReporter=req.user && String(req.user.id)===String(rows[0].reporter_user_id);
  if(!isAdmin && !isReporter)return res.status(403).send('Access denied.');
  const file=await storage.get(rows[0].storage_key);
  if(!file?.buffer)return res.status(404).send('Attachment unavailable.');
  res.setHeader('Content-Type',rows[0].content_type||'application/octet-stream');
  res.setHeader('Content-Disposition',`inline; filename="${String(rows[0].filename||'proof').replace(/[^a-zA-Z0-9._-]/g,'_')}"`);
  return res.send(file.buffer);
}