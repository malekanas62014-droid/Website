import { db } from "hatchable";
export const access="public";
export const methods=["GET","POST","DELETE"];

export default async function(req,res){
  const user=req.user;
  if(!user)return res.status(401).json({error:'Sign in required.'});
  const me=String(user.id);
  const target=String(req.body?.user_id||req.query?.user_id||'').trim();
  if(req.method==='GET'){
    const {rows}=await db.query("SELECT blocked_user_id FROM user_blocks WHERE blocker_user_id=$1 ORDER BY created_at DESC",[me]);
    return res.json({blockedUserIds:rows.map(r=>String(r.blocked_user_id))});
  }
  if(!target)return res.status(400).json({error:'User is required.'});
  if(target===me)return res.status(400).json({error:'You cannot block yourself.'});
  const {rows:targetRows}=await db.query("SELECT user_id FROM profile_usernames WHERE user_id=$1 LIMIT 1",[target]);
  if(!targetRows.length)return res.status(404).json({error:'User not found.'});
  if(req.method==='DELETE'){
    await db.query("DELETE FROM user_blocks WHERE blocker_user_id=$1 AND blocked_user_id=$2",[me,target]);
    return res.json({ok:true,blocked:false});
  }
  if(req.method==='POST'){
    await db.query("INSERT INTO user_blocks (blocker_user_id,blocked_user_id) VALUES ($1,$2) ON CONFLICT (blocker_user_id,blocked_user_id) DO NOTHING",[me,target]);
    return res.json({ok:true,blocked:true});
  }
  return res.status(405).json({error:'Method not allowed.'});
}