import { db } from "hatchable";
import { sendWebPushToUser } from "lib/web-push";
import { getFilterConfig, findAllBlockedTerms, punishmentForTerms, primaryMatchedWord, automaticFilterReason, canonicalFilterTerm, guessSourceLocale, translateText } from "lib/dm-filter-engine.js";
export const access="user";
export const methods=["GET","POST"];

function dmMatchedTerms(terms,config){
  const out=[];
  for(const raw of Array.isArray(terms)?terms:[]){
    const custom=String(raw||'').startsWith('custom:');
    const term=String(raw||'').replace(/^custom:/,'');
    const key=custom?deSpace(term):deSpace(canonicalFilterTerm(term));
    if(config.dmFiltering?.get(key)===true)out.push(raw);
  }
  return [...new Set(out)];
}
function deSpace(value){return String(value||'').toLowerCase().replace(/\s+/g,'');}
function dmTagEnabled(terms,config){
  return (terms||[]).some(raw=>{
    const custom=String(raw||'').startsWith('custom:');
    const term=String(raw||'').replace(/^custom:/,'');
    const key=custom?deSpace(term):deSpace(canonicalFilterTerm(term));
    return config.dmFiltering?.get(key)===true && config.dmTagging?.get(key)!==false;
  });
}
// Moderation matching, punishment, escalation, language detection, and translation are shared with Help Chat.
async function recordCycle(userId,filterKey,warningCount,stage){
  await db.query("INSERT INTO user_filter_escalation_cycles (user_id,filter_term,warning_count,escalation_stage,last_violation_at,updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) ON CONFLICT (user_id,filter_term) DO UPDATE SET warning_count=$3,escalation_stage=$4,last_violation_at=NOW(),updated_at=NOW()",[String(userId),filterKey,warningCount,stage]);
}
async function moderateDm({user,username,message,matched,config}){
  if(!matched.length)return {kind:'send',message};
  const matchedWord=primaryMatchedWord(matched);
  const autoReason=automaticFilterReason(matchedWord);
  const punishment=punishmentForTerms(matched,config);
  const moderationReason=String(config.punishmentReasons?.get(deSpace(canonicalFilterTerm(matchedWord)))||'').trim()||autoReason;
  await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) VALUES ($1,$2,$3,$4,$4,$5,$6,'dm_moderation')",[String(user.id),username,String(user.email||''),message,`DM filter · punishment: ${punishment}`,matched.join(', ')]);

  const matchedCanonicalTerms=[...new Set(matched.map(raw=>canonicalFilterTerm(String(raw||'').replace(/^custom:/,''))).filter(Boolean))];
  const escalationRules=(config.warningRules||[]).filter(r=>r.enabled!==false&&matchedCanonicalTerms.includes(canonicalFilterTerm(r.filter_term))).sort((a,b)=>String(a.filter_term||'').localeCompare(String(b.filter_term||''))||Number(a.order_index??0)-Number(b.order_index??0));
  const userId=String(user.id);
  const filterKey=canonicalFilterTerm(String(matchedWord||'')).toLowerCase();
  let warningCount=0,stage=0,reachedRule=null,afterStage=0,afterCount=0;
  if(escalationRules.length){
    const [{rows:cycleRows},{rows:settingRows}]=await Promise.all([
      db.query("SELECT warning_count,escalation_stage,last_violation_at FROM user_filter_escalation_cycles WHERE user_id=$1 AND filter_term=$2 LIMIT 1",[userId,filterKey]),
      db.query("SELECT escalation_reset_mode FROM moderation_settings WHERE id=1 LIMIT 1")
    ]);
    const cycle=cycleRows[0]||null;
    const resetMode=String(settingRows[0]?.escalation_reset_mode||'24h').toLowerCase()==='never'?'never':'24h';
    const expired=resetMode==='24h'&&cycle?.last_violation_at&&(Date.now()-new Date(cycle.last_violation_at).getTime()>=86400000);
    const storedStage=Math.max(0,Math.min(escalationRules.length,Number(cycle?.escalation_stage||0)));
    const terminal=storedStage>=escalationRules.length&&escalationRules.length>0;
    const previousCount=expired||terminal?0:Math.max(0,Number(cycle?.warning_count||0));
    stage=expired||terminal?0:storedStage;
    warningCount=previousCount+1;
    const candidate=escalationRules[stage];
    if(candidate){
      const thresholds=escalationRules.slice(0,stage+1).map(r=>Number(r.warning_count)).filter(Number.isFinite);
      const effectiveThreshold=Math.max(1,Math.min(Number(candidate.warning_count)||1,...thresholds));
      if(previousCount>=effectiveThreshold)reachedRule=candidate;
    }
    const reachedIndex=reachedRule?escalationRules.indexOf(reachedRule):-1;
    const finalReached=reachedIndex===escalationRules.length-1&&reachedIndex>=0;
    afterStage=reachedIndex>=0?(finalReached?0:reachedIndex+1):stage;
    afterCount=reachedIndex>=0&&finalReached?0:warningCount;
    if(reachedRule){
      const action=String(reachedRule.action||'warn').toLowerCase();
      const reason=String(reachedRule.reason||'').trim()||moderationReason;
      if(action==='warn'){
        const {rows}=await db.query("INSERT INTO user_warnings (user_id,filter_term,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,NULL,NULL) RETURNING id",[userId,filterKey,reason,message]);
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'W',$4,$5)",[userId,String(user.email||''),username,reason,message]);
        await recordCycle(userId,filterKey,afterCount,afterStage);
        return {kind:'blocked',status:403,payload:{error:reason,warning:true,warning_id:rows[0]?.id||null,offensive_item:message,filtered:true,punishment:'warn',filter_term:matchedWord}};
      }
      if(action==='delete'){
        await recordCycle(userId,filterKey,afterCount,afterStage);
        return {kind:'blocked',status:201,payload:{message:null,filtered:true,deleted:true,punishment:'delete',filter_term:matchedWord}};
      }
      if(action==='ban'){
        const seconds=Math.max(0,Number(reachedRule.ban_duration_seconds??604800));
        const expiresAt=seconds===0?null:new Date(Date.now()+seconds*1000);
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,$4,$5,$6)",[userId,String(user.email||''),username,seconds===0?'P':'BAN',reason,message]);
        await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type=EXCLUDED.ban_type",[userId,String(user.email||''),reason,message,expiresAt,seconds===0?'P':'BAN']);
        await recordCycle(userId,filterKey,afterCount,afterStage);
        return {kind:'blocked',status:403,payload:{error:reason,banned:true,reason,offensive_item:message,filtered:true,punishment:'ban',ban_duration_seconds:seconds,expires_at:expiresAt?.toISOString()||null,filter_term:matchedWord}};
      }
      if(action==='ip_ban'){
        const {rows:ipRows}=await db.query("SELECT last_ip FROM user_last_ips WHERE user_id=$1 LIMIT 1",[userId]);
        const ip=String(ipRows[0]?.last_ip||'').trim();
        if(!ip)return {kind:'blocked',status:400,payload:{error:'IP ban could not be applied because this account has no recorded IP address.'}};
        const seconds=Math.max(0,Number(reachedRule.ban_duration_seconds??604800));
        const expiresAt=seconds===0?null:new Date(Date.now()+seconds*1000);
        await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,$4) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at",[ip,reason,message,expiresAt]);
        await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)",[userId,String(user.email||''),username,reason,message]);
        await recordCycle(userId,filterKey,afterCount,afterStage);
        return {kind:'blocked',status:403,payload:{error:reason,ip_banned:true,banned:true,reason,offensive_item:message,filtered:true,punishment:'ip_ban',ban_duration_seconds:seconds,expires_at:expiresAt?.toISOString()||null,filter_term:matchedWord}};
      }
    }
    if(!reachedRule)await recordCycle(userId,filterKey,warningCount,stage);
  }

  if(punishment==='warn'){
    const {rows}=await db.query("INSERT INTO user_warnings (user_id,filter_term,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,NULL,NULL) RETURNING id",[userId,filterKey,moderationReason,message]);
    await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'W',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
    return {kind:'blocked',status:403,payload:{error:moderationReason,warning:true,warning_id:rows[0]?.id||null,offensive_item:message,filtered:true,punishment:'warn',filter_term:matchedWord}};
  }
  if(punishment==='delete')return {kind:'blocked',status:201,payload:{message:null,filtered:true,deleted:true,punishment:'delete',filter_term:matchedWord}};
  if(punishment==='ban'){
    const seconds=Math.max(0,Number(config.banDurations.get(deSpace(canonicalFilterTerm(matchedWord)))??604800));
    const expiresAt=seconds===0?null:new Date(Date.now()+seconds*1000);
    await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'BAN',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
    await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type) VALUES ($1,$2,$3,$4,$5,'BAN') ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type='BAN'",[userId,String(user.email||''),moderationReason,message,expiresAt]);
    return {kind:'blocked',status:403,payload:{error:moderationReason,banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ban',ban_duration_seconds:seconds,expires_at:expiresAt?.toISOString()||null,filter_term:matchedWord}};
  }
  if(punishment==='ip_ban'){
    const {rows:ipRows}=await db.query("SELECT last_ip FROM user_last_ips WHERE user_id=$1 LIMIT 1",[userId]);
    const ip=String(ipRows[0]?.last_ip||'').trim();
    if(!ip)return {kind:'blocked',status:400,payload:{error:'IP ban could not be applied because this account has no recorded IP address.'}};
    await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,NULL) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL",[ip,moderationReason,message]);
    await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)",[userId,String(user.email||''),username,moderationReason,message]);
    return {kind:'blocked',status:403,payload:{error:moderationReason,banned:true,ip_banned:true,reason:moderationReason,offensive_item:message,filtered:true,punishment:'ip_ban',filter_term:matchedWord}};
  }
  return {kind:'send',message:dmTagEnabled(matched,config)?'***':message};
}

export default async function(req,res){
  const user=req.user;
  const action=String(req.body?.action||'send').trim().toLowerCase();
  const id=String(req.body?.id||'').trim();
  if(req.method==='POST' && (action==='edit'||action==='delete')){
    if(!id)return res.status(400).json({error:'Message id required.'});
    const {rows}=await db.query("SELECT id,sender_user_id,message,sender_username FROM direct_messages WHERE id=$1 AND deleted_at IS NULL LIMIT 1",[id]);
    if(!rows.length)return res.status(404).json({error:'Message not found.'});
    if(String(rows[0].sender_user_id)!==String(user.id))return res.status(403).json({error:action==='edit'?'You can only edit your own messages.':'You can only delete your own messages.'});
    if(action==='delete'){
      await db.query("UPDATE direct_messages SET deleted_at=NOW() WHERE id=$1 AND sender_user_id=$2 AND deleted_at IS NULL",[id,String(user.id)]);
      return res.json({ok:true});
    }
    const message=String(req.body?.message||'').trim().slice(0,500);
    if(!message)return res.status(400).json({error:'Message cannot be empty.'});
    const filterConfig=await getFilterConfig();
    const sourceLanguage=guessSourceLocale(message);
    const nativeHits=await findAllBlockedTerms(message,filterConfig);
    const englishTranslation=await translateText(message,'en',sourceLanguage);
    const translatedHits=englishTranslation&&englishTranslation!==message?await findAllBlockedTerms(englishTranslation,filterConfig):[];
    const matched=[...new Set([...nativeHits,...translatedHits])];
    if(matched.length)return res.status(403).json({error:'This message cannot be edited because the new text is filtered.',filtered:true,punishment:'edit_blocked'});
    await db.query("UPDATE direct_messages SET message=$2,edited_at=NOW() WHERE id=$1 AND sender_user_id=$3 AND deleted_at IS NULL",[id,message,String(user.id)]);
    return res.json({ok:true,edited_at:new Date().toISOString()});
  }
  if(req.method==='GET'){
    const peer=String(req.query?.peer||'').trim();
    if(!peer)return res.status(400).json({error:'Peer user is required.'});
    const me=String(user.id);
    const {rows:blockRows}=await db.query(`SELECT EXISTS(
      SELECT 1 FROM user_blocks
      WHERE (blocker_user_id=$1 AND blocked_user_id=$2)
         OR (blocker_user_id=$2 AND blocked_user_id=$1)
    ) AS blocked`,[me,peer]);
    if(blockRows[0]?.blocked)return res.status(403).json({error:'This DM is unavailable because one of you has blocked the other.'});
    await db.query(`UPDATE direct_messages
      SET read_at=COALESCE(read_at,NOW())
      WHERE recipient_user_id=$1 AND sender_user_id=$2 AND deleted_at IS NULL`,[me,peer]);
    const {rows:messageRows}=await db.query(`SELECT d.id,d.sender_user_id,d.sender_username,COALESCE(up.display_name,'') AS sender_display_name,d.recipient_user_id,d.recipient_username,d.message,d.created_at,d.edited_at,d.read_at,d.reply_to_id,
        rt.sender_username AS reply_to_username,COALESCE(rp.display_name,rt.sender_username,'User') AS reply_to_display_name,rt.message AS reply_to_message,
        COALESCE(up.is_verified,false) AS sender_is_verified,(lower(u.email)=lower('robloxassetsowner@protonmail.com')) AS sender_is_creator,(lower(u.email)=lower('robloxassetsowner@protonmail.com') OR EXISTS(SELECT 1 FROM admin_user_directory ax WHERE ax.is_admin=true AND (ax.user_id=CAST(u.id AS text) OR lower(ax.email)=lower(u.email)))) AS sender_is_admin
      FROM direct_messages d
      LEFT JOIN users u ON u.id=d.sender_user_id
      LEFT JOIN user_profiles up ON up.user_id=d.sender_user_id
      LEFT JOIN direct_messages rt ON rt.id=d.reply_to_id
      LEFT JOIN user_profiles rp ON rp.user_id=rt.sender_user_id
      WHERE d.deleted_at IS NULL
        AND ((d.sender_user_id=$1 AND d.recipient_user_id=$2) OR (d.sender_user_id=$2 AND d.recipient_user_id=$1))
      ORDER BY created_at ASC
      LIMIT 200`,[me,peer]);
    const filterConfig=await getFilterConfig();
    const messages=[];
    for(const m of messageRows||[]){
      const hits=await findAllBlockedTerms(m.message,filterConfig);
      const dmHits=dmMatchedTerms(hits,filterConfig);
      messages.push({...m,message:dmHits.length&&dmTagEnabled(dmHits,filterConfig)?'***':m.message});
    }
    return res.json({messages});
  }
  const recipient=String(req.body?.recipient_user_id||'').trim();
  const message=String(req.body?.message||'').trim().slice(0,500);
  const replyToId=String(req.body?.reply_to_id||'').trim()||null;
  const {rows:accountBlocks}=await db.query("SELECT reason,expires_at,ban_type FROM banned_users WHERE user_id=$1 AND (ban_type='ACD' OR expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[String(user.id)]);
  if(accountBlocks.length){
    const b=accountBlocks[0];
    return res.status(403).json({error:String(b.reason||'Your account is currently banned.'),banned:true,ban_type:String(b.ban_type||'BAN'),expires_at:b.expires_at||null});
  }
  const {rows:openWarnings}=await db.query("SELECT id,reason,offensive_item FROM user_warnings WHERE user_id=$1 AND acknowledged_at IS NULL ORDER BY created_at DESC LIMIT 1",[String(user.id)]);
  if(openWarnings.length){
    const w=openWarnings[0];
    return res.status(403).json({error:String(w.reason||'Please acknowledge your warning before sending messages.'),warning:true,warning_id:String(w.id),offensive_item:String(w.offensive_item||'')});
  }
  if(!recipient||!message)return res.status(400).json({error:'Recipient and message are required.'});
  if(recipient===String(user.id))return res.status(400).json({error:'You cannot DM yourself.'});
  // Consolidate all permission/contact/name reads into one DB call. The insert
  // remains a second call only after all checks pass.
  const {rows:stateRows}=await db.query(`
    SELECT
      EXISTS(
        SELECT 1 FROM user_blocks
        WHERE (blocker_user_id=$1 AND blocked_user_id=$2)
           OR (blocker_user_id=$2 AND blocked_user_id=$1)
      ) AS blocked,
      COALESCE((SELECT dm_enabled FROM user_preferences WHERE user_id=$2 LIMIT 1),true) AS dm_enabled,
      COALESCE((SELECT dm_existing_contacts FROM user_preferences WHERE user_id=$2 LIMIT 1),false) AS dm_existing_contacts,
      COALESCE((SELECT dm_restriction FROM user_preferences WHERE user_id=$2 LIMIT 1),'everyone') AS dm_restriction,
      EXISTS(
        SELECT 1 FROM direct_messages
        WHERE (sender_user_id=$1 AND recipient_user_id=$2)
           OR (sender_user_id=$2 AND recipient_user_id=$1)
        LIMIT 1
      ) AS has_prior,
      EXISTS(SELECT 1 FROM user_friendships WHERE (user_a=$1 AND user_b=$2) OR (user_a=$2 AND user_b=$1)) AS are_friends,
      EXISTS(SELECT 1 FROM user_follows WHERE follower_user_id=$1 AND followed_user_id=$2) AS sender_follows_recipient,
      (SELECT username FROM profile_usernames WHERE user_id=$2 LIMIT 1) AS recipient_username,
      (SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1) AS sender_username
  `,[String(user.id),recipient]);
  const state=stateRows[0]||{};
  if(state.blocked)return res.status(403).json({error:'This DM is unavailable because one of you has blocked the other.'});
  if(!state.recipient_username)return res.status(404).json({error:'User not found.'});
  const dmRestriction=String(state.dm_restriction||'everyone').toLowerCase();
  const existingContactReply=!!state.dm_existing_contacts && !!state.has_prior;
  if(dmRestriction==='friends' && !state.are_friends && !existingContactReply)return res.status(403).json({error:'This user only accepts DMs from friends.',code:'DM_FRIENDS_ONLY'});
  if(dmRestriction==='followers' && !state.sender_follows_recipient && !existingContactReply)return res.status(403).json({error:'This user only accepts DMs from followers.',code:'DM_FOLLOWERS_ONLY'});
  if(dmRestriction==='off' || state.dm_enabled===false){
    if(state.dm_existing_contacts && state.has_prior){}
    else if(state.dm_existing_contacts)return res.status(403).json({error:'This user does not accept new DMs.',code:'DM_EXISTING_CONTACTS_ONLY'});
    else return res.status(403).json({error:'This user has DMs disabled.',code:'DM_DISABLED'});
  }
  const senderUsername=String(state.sender_username||user.handle||user.display_name||'User').slice(0,20);
  let replyToMessage=null;
  if(replyToId){
    const {rows:replyRows}=await db.query("SELECT id,sender_user_id,sender_username,recipient_user_id,recipient_username,message,deleted_at FROM direct_messages WHERE id=$1 LIMIT 1",[replyToId]);
    const target=replyRows[0];
    if(!target||target.deleted_at||!((String(target.sender_user_id)===String(user.id)&&String(target.recipient_user_id)===String(recipient))||(String(target.sender_user_id)===String(recipient)&&String(target.recipient_user_id)===String(user.id))))return res.status(400).json({error:'The message you are replying to is unavailable.'});
    replyToMessage=target;
  }
  const filterConfig=await getFilterConfig();
  const sourceLanguage=guessSourceLocale(message);
  const nativeHits=await findAllBlockedTerms(message,filterConfig);
  const englishTranslation=await translateText(message,'en',sourceLanguage);
  const translatedHits=englishTranslation&&englishTranslation!==message?await findAllBlockedTerms(englishTranslation,filterConfig):[];
  const allHits=[...new Set([...nativeHits,...translatedHits])];
  const dmHits=dmMatchedTerms(allHits,filterConfig);
  const moderation=await moderateDm({user,username:senderUsername,message,matched:dmHits,config:filterConfig});
  if(moderation.kind==='blocked')return res.status(moderation.status).json(moderation.payload);
  const storedMessage=moderation.message;
  const {rows}=await db.query("INSERT INTO direct_messages (sender_user_id,sender_username,recipient_user_id,recipient_username,message,reply_to_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id,sender_user_id,sender_username,recipient_user_id,recipient_username,message,created_at,read_at,reply_to_id",[String(user.id),senderUsername,recipient,String(state.recipient_username||'User'),storedMessage,replyToId]);
  const created=rows[0];
  try{
    const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_dm,true) AS dm FROM user_preferences WHERE user_id=$1 LIMIT 1",[recipient]);
    if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].dm!==false))await sendWebPushToUser(recipient,'New message from @'+senderUsername,String(message),'dm_'+String(created.id));
  }catch(_){ }
  res.status(201).json({message:created});
}