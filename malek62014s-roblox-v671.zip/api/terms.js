import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
export default async function(req,res){
  const [{rows:meta},{rows:sections}]=await Promise.all([
    db.query("SELECT updated_at FROM tos_meta WHERE id=TRUE LIMIT 1"),
    db.query("SELECT id,section_number,kicker,title,body,sort_order FROM tos_sections WHERE active=true ORDER BY sort_order,id")
  ]);
  return res.json({updated_at:meta[0]?.updated_at||null,sections});
}