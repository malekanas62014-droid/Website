import { db } from "hatchable";
export const access="scheduler";
export const schedule="0 * * * *";
export default async function(req,res){
  const {rowCount}=await db.query("DELETE FROM chat_messages WHERE created_at < NOW()-INTERVAL '24 hours'");
  res.json({ok:true,deleted:rowCount||0});
}