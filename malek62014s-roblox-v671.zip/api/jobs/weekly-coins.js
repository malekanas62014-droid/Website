import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];

export default async function (req, res) {
  // Weekly rewards are now claim-based. Keep this scheduled endpoint as a
  // harmless health run so the old cron cannot silently grant extra coins.
  res.json({ rewarded_wallets: 0, coins_each: 5, claim_required: true });
}