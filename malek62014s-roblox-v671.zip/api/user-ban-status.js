import { db } from "hatchable";
export const access = "user";
export const methods = ["GET"];
export default async function(req,res){
  const user=req.user;
  const forwarded=String(req.headers?.['x-forwarded-for']||'').split(',')[0].trim();
  const ip=forwarded||String(req.headers?.['x-real-ip']||'').trim();
  if(ip){ await db.query("INSERT INTO user_last_ips (user_id,last_ip,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET last_ip=EXCLUDED.last_ip,updated_at=NOW()",[String(user.id),ip]); }
  const {rows}=await db.query("SELECT reason,offensive_item,expires_at,ban_type,attachment_key,attachment_name,attachment_type FROM banned_users WHERE user_id=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[String(user.id)]);
  let ipBanRows=[];
  if(ip){ const r=await db.query("SELECT reason,offensive_item,expires_at FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[ip]); ipBanRows=r.rows||[]; }
  const [{rows:warnings},{rows:warningCounts}]=await Promise.all([
    db.query("SELECT id,filter_term,reason,offensive_item,created_at,attachment_key,attachment_name,attachment_type FROM user_warnings WHERE user_id=$1 AND acknowledged_at IS NULL ORDER BY created_at ASC LIMIT 1",[String(user.id)]),
    db.query("SELECT filter_term,COUNT(*)::int AS count FROM user_warnings WHERE user_id=$1 GROUP BY filter_term",[String(user.id)])
  ]);
  let warningCount=0;
  let warningLimit=0;
  let remainingUntilAction=0;
  let nextAction='';
  let currentStage=0;
  if(warnings[0]?.filter_term){
    const filterTerm=String(warnings[0].filter_term||'');
    const countRow=warningCounts.find(x=>String(x.filter_term||'').toLowerCase()===filterTerm.toLowerCase());
    const {rows:rules}=await db.query("SELECT warning_count,action,reason,ban_duration_seconds FROM warning_escalation_rules WHERE enabled=true AND lower(filter_term)=lower($1) ORDER BY order_index ASC,warning_count ASC,id ASC",[filterTerm]);
    const {rows:cycleRows}=await db.query("SELECT warning_count,escalation_stage,last_violation_at FROM user_filter_escalation_cycles WHERE user_id=$1 AND lower(filter_term)=lower($2) LIMIT 1",[String(user.id),filterTerm]);
    const cycle=cycleRows[0];
    const totalCount=Number(cycle?.warning_count||0);
    currentStage=Math.max(0,Math.min(rules.length,Number(cycle?.escalation_stage||0)));
    const nextRule=rules.slice(currentStage).find(r=>Number(totalCount)<Number(r.warning_count));
    if(nextRule){
      warningCount=totalCount;
      warningLimit=Number(nextRule.warning_count);
      remainingUntilAction=Math.max(0,Number(nextRule.warning_count)-totalCount+1);
      nextAction=String(nextRule.action||'warn');
    }else if(rules.length){
      warningCount=totalCount;
      warningLimit=Number(rules[rules.length-1].warning_count||1);
      remainingUntilAction=0;
      nextAction=String(rules[rules.length-1].action||'warn');
      currentStage=rules.length;
    }
  }
  const warningPayload=warnings[0]?{id:warnings[0].id,filter_term:warnings[0].filter_term||'',reason:warnings[0].reason||'No reason provided',offensive_item:warnings[0].offensive_item||'',created_at:warnings[0].created_at,attachment_key:warnings[0].attachment_key||'',attachment_name:warnings[0].attachment_name||'',attachment_type:warnings[0].attachment_type||'',warning_count:warningCount,warnings_until_action:warningLimit,remaining_until_action:remainingUntilAction,next_action:nextAction,current_stage:currentStage}:null;
  if(!rows.length&&!ipBanRows.length)return res.json({banned:false,warning:warningPayload,warning_count:warningCount,warnings_until_action:warningLimit,remaining_until_action:remainingUntilAction,next_action:nextAction,current_stage:currentStage});
  const ban=rows[0]||{}; const ipBan=ipBanRows[0]||{};
  res.json({banned:true,reason:ban.reason||ipBan.reason||'No reason provided',offensive_item:ban.offensive_item||ipBan.offensive_item||'',expires_at:ban.expires_at||ipBan.expires_at||null,ban_type:ban.ban_type||'IB',attachment_key:ban.attachment_key||'',attachment_name:ban.attachment_name||'',attachment_type:ban.attachment_type||'',warning:null,warning_count:warningCount,warnings_until_action:warningLimit,remaining_until_action:remainingUntilAction,next_action:nextAction,current_stage:currentStage});
}