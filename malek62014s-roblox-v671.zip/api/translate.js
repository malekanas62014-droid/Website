export const access="public";
export const methods=["POST"];

const MAX_TEXTS=40;
const MAX_TEXT_LENGTH=500;
const TARGET_RE=/^[A-Za-z]{2,3}(?:-[A-Za-z]{2,4})?$/;
function normalizeLocale(code){
  const raw=String(code||'en').trim();
  if(!raw)return 'en';
  const parts=raw.split('-');
  return parts.length>1?parts[0].toLowerCase()+'-'+parts[1].toUpperCase():raw.toLowerCase();
}

function cleanText(value){return String(value??'').slice(0,MAX_TEXT_LENGTH);}
function guessSourceLocale(text){
  const value=String(text||'');
  if(/[\u0600-\u06ff]/.test(value))return 'ar';
  if(/[\u0590-\u05ff]/.test(value))return 'he';
  if(/[\u0400-\u04ff]/.test(value))return 'ru';
  if(/[\u0370-\u03ff]/.test(value))return 'el';
  if(/[\u0900-\u097f]/.test(value))return 'hi';
  if(/[\u0980-\u09ff]/.test(value))return 'bn';
  if(/[\u0a00-\u0a7f]/.test(value))return 'pa';
  if(/[\u0b80-\u0bff]/.test(value))return 'ta';
  if(/[\u0c00-\u0c7f]/.test(value))return 'te';
  if(/[\u0d00-\u0d7f]/.test(value))return 'ml';
  if(/[\u0e00-\u0e7f]/.test(value))return 'th';
  if(/[\u3040-\u30ff]/.test(value))return 'ja';
  if(/[\uac00-\ud7af]/.test(value))return 'ko';
  if(/[\u4e00-\u9fff]/.test(value))return 'zh';
  return 'auto';
}
function decodeEntities(value){
  return String(value||'')
    .replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
}
async function translateOne(text,target,source='auto'){
  if(!text)return '';
  const targetLocale=normalizeLocale(target);
  const requestedSource=source==='auto'||!source?'auto':normalizeLocale(source);
  const detected=requestedSource==='auto'?guessSourceLocale(text):requestedSource;
  const from=detected==='auto'?'auto':detected.split('-')[0];
  const to=targetLocale.split('-')[0];
  if((from==='en'||from==='auto')&&to==='en')return text;
  try{
    const googleUrl='https://translate.googleapis.com/translate_a/single?client=gtx&sl='+encodeURIComponent(from)+'&tl='+encodeURIComponent(to)+'&dt=t&q='+encodeURIComponent(text);
    const googleResponse=await fetch(googleUrl,{headers:{Accept:'application/json'},method:'GET'});
    if(googleResponse.ok){
      const data=await googleResponse.json();
      const translated=decodeEntities(Array.isArray(data?.[0])?data[0].map(x=>String(x?.[0]||'')).join(''):'');
      if(translated&&translated.toLowerCase()!==String(text).toLowerCase())return translated;
    }
  }catch(_){ }
  try{
    const memoryFrom=detected==='auto'?'autodetect':detected;
    const memoryUrl='https://api.mymemory.translated.net/get?q='+encodeURIComponent(text)+'&langpair='+encodeURIComponent(memoryFrom+'|'+targetLocale);
    const response=await fetch(memoryUrl,{headers:{Accept:'application/json'},method:'GET'});
    if(!response.ok)throw Error('Translation service unavailable.');
    const data=await response.json();
    const translated=decodeEntities(String(data?.responseData?.translatedText||''));
    if(translated&&!translated.toUpperCase().includes('PLEASE SELECT TWO DISTINCT LANGUAGES'))return translated;
  }catch(_){ }
  return text;
}

export default async function(req,res){
  const target=normalizeLocale(req.body?.target||'en');
  const sourceRaw=String(req.body?.source||'auto').trim()||'auto';
  const source=sourceRaw==='auto'?'auto':normalizeLocale(sourceRaw);
  const texts=Array.isArray(req.body?.texts)?req.body.texts.map(cleanText).slice(0,MAX_TEXTS):[];
  if(!TARGET_RE.test(target))return res.status(400).json({error:'Invalid target language.'});
  if(source!=='auto'&&!TARGET_RE.test(source))return res.status(400).json({error:'Invalid source language.'});
  if(!texts.length)return res.status(400).json({error:'No text supplied.'});
  const translations=await Promise.all(texts.map(async text=>{
    if(!text)return '';
    try{return await translateOne(text,target,source);}catch(_){return text;}
  }));
  return res.json({translations,target,source,provider:'Google Translate with MyMemory fallback'});
}