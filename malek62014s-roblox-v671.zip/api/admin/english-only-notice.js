import { db } from 'hatchable';
import { assertAdmin } from 'lib/admin-auth';

export const access = 'user';
export const methods = ['POST'];

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:'Admin access required'});
  const userId=String(req.body?.user_id||'').trim();
  if(!userId)return res.status(400).json({error:'A target user is required.'});
  const {rowCount:exists}=await db.query('SELECT 1 FROM users WHERE id=$1 LIMIT 1',[userId]);
  if(!exists)return res.status(404).json({error:'Target user was not found.'});
  const {rows}=await db.query(`INSERT INTO user_preferences (user_id,english_notice_version,language,updated_at)
    VALUES ($1,1,'en',NOW())
    ON CONFLICT (user_id) DO UPDATE SET english_notice_version=COALESCE(user_preferences.english_notice_version,0)+1,language='en',updated_at=NOW()
    RETURNING english_notice_version`,[userId]);
  return res.json({ok:true,user_id:userId,version:Number(rows[0]?.english_notice_version||1)});
}