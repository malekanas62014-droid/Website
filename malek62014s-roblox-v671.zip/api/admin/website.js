import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET","POST"];
export default async function(req,res){
 if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
 if(req.method==='GET'){
  const {rows}=await db.query("SELECT id,name,category,description FROM managed_assets ORDER BY created_at DESC");
  const {rows:cats}=await db.query("SELECT id,name,slug FROM website_categories ORDER BY name");
  const {rows:settingRows}=await db.query("SELECT key,value FROM site_settings WHERE key IN ('maintenance_enabled','maintenance_reason')");
  const settings=Object.fromEntries(settingRows.map(x=>[x.key,x.value]));
  const {rows:tosRows}=await db.query("SELECT id,section_number,kicker,title,body,sort_order,active,updated_at FROM tos_sections ORDER BY sort_order,id");
  const {rows:tosMeta}=await db.query("SELECT updated_at FROM tos_meta WHERE id=TRUE LIMIT 1");
  return res.json({assets:rows,categories:cats,legacy_asset_count:10,maintenance:{enabled:settings.maintenance_enabled==='1',reason:settings.maintenance_reason||''},tos:{updated_at:tosMeta[0]?.updated_at||null,sections:tosRows}});
 }
 const b=req.body||{};const action=String(b.action||'');
 if(action==='asset_text'){
  const rawId=String(b.asset_id??'').trim();
  if(!rawId)return res.status(400).json({error:'Missing asset id'});
  const requestedCategories=String(b.category||'').split(',').map(v=>v.trim()).filter(Boolean);
  const {rows:categoryRows}=await db.query("SELECT name,slug FROM website_categories");
  const categoryMap=new Map(); categoryRows.forEach(c=>{categoryMap.set(String(c.name).trim().toLowerCase(),String(c.slug).trim().toLowerCase());categoryMap.set(String(c.slug).trim().toLowerCase(),String(c.slug).trim().toLowerCase());});
  const normalizedCategories=[]; for(const requestedCategory of requestedCategories){const slug=categoryMap.get(requestedCategory.toLowerCase());if(!slug)return res.status(400).json({error:`Category "${requestedCategory}" does not exist. Create it first.`});if(!normalizedCategories.includes(slug))normalizedCategories.push(slug);}
  const category=normalizedCategories.join(',');
  const name=String(b.name||'').trim();
  const description=String(b.description||'');
  if(rawId.startsWith('legacy-')){
   const legacyId=rawId.slice(7);
   if(!legacyId)return res.status(400).json({error:'Invalid legacy asset id'});
   await db.query("INSERT INTO page_asset_overrides (legacy_id,category) VALUES ($1,$2) ON CONFLICT (legacy_id) DO UPDATE SET category=EXCLUDED.category",[legacyId,category]);
   return res.json({ok:true,category});
  }
  const id=Number(rawId);
  if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid asset id'});
  await db.query("UPDATE managed_assets SET name=$2,description=$3,category=$4,updated_at=NOW() WHERE id=$1",[id,name,description,category]);
  return res.json({ok:true,category});
 }
 if(action==='maintenance'){
  const enabled=Boolean(b.enabled);
  const reason=String(b.reason||'').trim().slice(0,500);
  await db.query("INSERT INTO site_settings (key,value) VALUES ('maintenance_enabled',$1) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value",[enabled?'1':'0']);
  await db.query("INSERT INTO site_settings (key,value) VALUES ('maintenance_reason',$1) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value",[reason]);
  return res.json({ok:true,maintenance:{enabled,reason}});
 }
 if(action==='category'){
  const name=String(b.name||'').trim();if(!name)return res.status(400).json({error:'Category name required'});
  const slug=name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60);if(!slug)return res.status(400).json({error:'Invalid category name'});
  await db.query("INSERT INTO website_categories (name,slug) VALUES ($1,$2)",[name,slug]);return res.json({ok:true});
 }
 if(action==='delete_category'){
  const id=Number(b.category_id);if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid category id'});
  const {rows}=await db.query("SELECT name FROM website_categories WHERE id=$1",[id]);if(!rows.length)return res.status(404).json({error:'Category not found'});
  await db.query("DELETE FROM website_categories WHERE id=$1",[id]);return res.json({ok:true});
 }
 if(action==='tos_create'){
  const title=String(b.title||'').trim().slice(0,140);const body=String(b.body||'').trim().slice(0,5000);const kicker=String(b.kicker||'Community').trim().slice(0,60)||'Community';
  if(!title||!body)return res.status(400).json({error:'Title and rule text are required.'});
  const sectionNumber=Math.max(0,Number.isFinite(Number(b.section_number))?Number(b.section_number):1);const sortOrder=Number.isFinite(Number(b.sort_order))?Number(b.sort_order):sectionNumber;
  const {rows}=await db.query("INSERT INTO tos_sections (section_number,kicker,title,body,sort_order,active) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id,section_number,kicker,title,body,sort_order,active,updated_at",[sectionNumber,kicker,title,body,sortOrder,b.active!==false]);
  await db.query("INSERT INTO tos_meta (id,updated_at) VALUES (TRUE,NOW()) ON CONFLICT (id) DO UPDATE SET updated_at=NOW()");return res.json({ok:true,section:rows[0]});
 }
 if(action==='tos_update'){
  const id=Number(b.id);if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid Terms section.'});
  const title=String(b.title||'').trim().slice(0,140);const body=String(b.body||'').trim().slice(0,5000);const kicker=String(b.kicker||'Community').trim().slice(0,60)||'Community';
  if(!title||!body)return res.status(400).json({error:'Title and rule text are required.'});
  const sectionNumber=Math.max(0,Number.isFinite(Number(b.section_number))?Number(b.section_number):1);const sortOrder=Number.isFinite(Number(b.sort_order))?Number(b.sort_order):sectionNumber;
  const {rows}=await db.query("UPDATE tos_sections SET section_number=$2,kicker=$3,title=$4,body=$5,sort_order=$6,active=$7,updated_at=NOW() WHERE id=$1 RETURNING id,section_number,kicker,title,body,sort_order,active,updated_at",[id,sectionNumber,kicker,title,body,sortOrder,b.active!==false]);
  if(!rows.length)return res.status(404).json({error:'Terms section not found.'});
  await db.query("UPDATE tos_meta SET updated_at=NOW() WHERE id=TRUE");return res.json({ok:true,section:rows[0]});
 }
 if(action==='tos_delete'){
  const id=Number(b.id);if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid Terms section.'});
  await db.query("DELETE FROM tos_sections WHERE id=$1",[id]);await db.query("UPDATE tos_meta SET updated_at=NOW() WHERE id=TRUE");return res.json({ok:true});
 }
 if(action==='tos_toggle'){
  const id=Number(b.id);if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid Terms section.'});
  const {rows}=await db.query("UPDATE tos_sections SET active=NOT active,updated_at=NOW() WHERE id=$1 RETURNING active",[id]);if(!rows.length)return res.status(404).json({error:'Terms section not found.'});await db.query("UPDATE tos_meta SET updated_at=NOW() WHERE id=TRUE");return res.json({ok:true,active:!!rows[0].active});
 }
 return res.status(400).json({error:'Unknown action'});
}