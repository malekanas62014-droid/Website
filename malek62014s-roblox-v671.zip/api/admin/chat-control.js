import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access="user";
export const methods=["GET","POST"];

async function requireAdmin(req,res){
  if(!(await assertAdmin(req))){res.status(403).json({error:"Admin access required"});return false;}
  return true;
}

async function usernameFor(userId){
  if(!userId)return 'System';
  const {rows}=await db.query("SELECT username FROM profile_usernames WHERE user_id=$1 LIMIT 1",[String(userId)]);
  return String(rows[0]?.username||'User');
}

export default async function(req,res){
  if(!(await requireAdmin(req,res)))return;
  if(req.method==='GET'){
    const {rows}=await db.query("SELECT id,user_id,username,message,created_at,message_type,deleted_at,deleted_by,edited_at FROM chat_messages WHERE deleted_at IS NULL AND created_at>NOW()-INTERVAL '24 hours' ORDER BY created_at ASC LIMIT 500");
    return res.json({messages:rows});
  }
  const action=String(req.body?.action||'').trim();
  if(action==='delete_message'){
    const id=String(req.body?.id||'').trim();
    if(!id)return res.status(400).json({error:'Message id required.'});
    const {rows}=await db.query("SELECT id,user_id,username,message FROM chat_messages WHERE id=$1 AND deleted_at IS NULL LIMIT 1",[id]);
    if(!rows.length)return res.status(404).json({error:'Live message not found.'});
    const m=rows[0];
    await db.query("UPDATE chat_messages SET deleted_at=NOW(),deleted_by=$2 WHERE id=$1 AND deleted_at IS NULL",[id,'admin']);
    await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) SELECT $1,$2,COALESCE(u.email,''),$3,$3,$4,NULL,'admin_delete' FROM users u WHERE u.id=$1",[String(m.user_id||''),String(m.username||'System'),String(m.message),'Message deleted by admin']);
    return res.json({ok:true});
  }
  if(action==='bulk_delete_messages'){
    const ids=Array.isArray(req.body?.ids)?req.body.ids.map(String).filter(Boolean):[];
    if(!ids.length)return res.status(400).json({error:'Select at least one live message.'});
    const {rows}=await db.query("SELECT id,user_id,username,message FROM chat_messages WHERE id = ANY($1::uuid[]) AND deleted_at IS NULL",[ids]);
    for(const m of rows){
      await db.query("UPDATE chat_messages SET deleted_at=NOW(),deleted_by=$2 WHERE id=$1 AND deleted_at IS NULL",[String(m.id),'admin']);
      await db.query("INSERT INTO chat_logs (user_id,username,email,message,original_message,reason,matched_terms,message_type) SELECT $1,$2,COALESCE(u.email,''),$3,$3,$4,NULL,'admin_delete' FROM users u WHERE u.id=$1",[String(m.user_id||''),String(m.username||'System'),String(m.message),'Message deleted by admin']);
    }
    return res.json({ok:true,deleted:rows.length});
  }
  if(action==='edit_message'){
    const id=String(req.body?.id||'').trim();
    const message=String(req.body?.message||'').trim().slice(0,500);
    if(!id||!message)return res.status(400).json({error:'Message id and text are required.'});
    const {rowCount}=await db.query("UPDATE chat_messages SET message=$2,edited_at=NOW() WHERE id=$1 AND deleted_at IS NULL",[id,message]);
    if(!rowCount)return res.status(404).json({error:'Live message not found.'});
    return res.json({ok:true});
  }
  if(action==='system_message'){
    const message=String(req.body?.message||'').trim().slice(0,500);
    if(!message)return res.status(400).json({error:'System message cannot be empty.'});
    const {rows}=await db.query("INSERT INTO chat_messages (user_id,username,message,message_type) VALUES (NULL,'System',$1,'system') RETURNING id,user_id,username,message,created_at,message_type,deleted_at,deleted_by,edited_at",[message]);
    return res.status(201).json({message:rows[0]});
  }
  return res.status(400).json({error:'Unknown action.'});
}