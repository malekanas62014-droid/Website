import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET","POST"];

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:'Admin access required'});
  if(req.method==='GET'){
    const id=String(req.query?.id||'').trim();
    if(id){
      const {rows}=await db.query("SELECT r.id,r.reporter_user_id,r.reporter_username,ru.email AS reporter_email,r.reported_user_id,r.reported_username,tu.email AS reported_email,r.category,r.details,r.status,r.created_at,r.resolved_at,r.resolved_by,r.source_type,r.source_message_id,r.resolution_outcome FROM user_reports r LEFT JOIN users ru ON ru.id=r.reporter_user_id LEFT JOIN users tu ON tu.id=r.reported_user_id WHERE r.id=$1 LIMIT 1",[id]);
      if(!rows.length)return res.status(404).json({error:'Report not found.'});
      const report=rows[0];
      const {rows:attachments}=await db.query("SELECT id,filename,content_type,size_bytes,storage_key,created_at FROM user_report_attachments WHERE report_id=$1 ORDER BY created_at ASC",[id]);
      if(report.source_type==='help_chat'){
        const {rows:messages}=await db.query("SELECT id,user_id,username,message,created_at,message_type,edited_at FROM chat_messages WHERE deleted_at IS NULL ORDER BY created_at ASC");
        return res.json({report,attachments,messages,context_type:'help_chat'});
      }
      const {rows:messages}=await db.query("SELECT id,sender_user_id,sender_username,recipient_user_id,recipient_username,message,created_at,read_at FROM direct_messages WHERE deleted_at IS NULL AND ((sender_user_id=$1 AND recipient_user_id=$2) OR (sender_user_id=$2 AND recipient_user_id=$1)) ORDER BY created_at ASC",[String(report.reporter_user_id),String(report.reported_user_id)]);
      return res.json({report,attachments,messages,context_type:'dm'});
    }
    const {rows}=await db.query("SELECT r.id,r.reporter_user_id,r.reporter_username,ru.email AS reporter_email,r.reported_user_id,r.reported_username,tu.email AS reported_email,r.category,r.details,r.status,r.created_at,r.resolved_at,r.resolved_by,r.source_type,r.source_message_id,r.resolution_outcome FROM user_reports r LEFT JOIN users ru ON ru.id=r.reporter_user_id LEFT JOIN users tu ON tu.id=r.reported_user_id WHERE r.status='open' ORDER BY r.created_at DESC LIMIT 500");
    return res.json({reports:rows});
  }
  const action=String(req.body?.action||'');
  const id=String(req.body?.id||'').trim();
  if(action==='resolve' || action==='deny'){
    if(!id)return res.status(400).json({error:'Report id required.'});
    const reason=String(req.body?.reason||req.body?.outcome||'').trim().slice(0,1000);
    if(!reason)return res.status(400).json({error:action==='deny'?'A reason for denial is required.':'Resolution outcome is required.'});
    const status=action==='deny'?'denied':'resolved';
    const {rowCount}=await db.query("UPDATE user_reports SET status=$2,resolved_at=now(),resolved_by=$3,resolution_outcome=$4 WHERE id=$1 AND status='open'",[id,status,String(req.user?.id||'admin'),reason]);
    if(!rowCount)return res.status(404).json({error:'Open report not found.'});
    return res.json({ok:true,status});
  }
  if(action==='delete'){
    if(!id)return res.status(400).json({error:'Report id required.'});
    await db.query("DELETE FROM user_reports WHERE id=$1",[id]);
    return res.json({ok:true});
  }
  if(action==='bulk_delete'){
    const ids=Array.isArray(req.body?.ids)?req.body.ids.map(String).filter(Boolean):[];
    if(!ids.length)return res.status(400).json({error:'Select at least one report.'});
    const result=await db.query("DELETE FROM user_reports WHERE id=ANY($1::uuid[])",[ids]);
    return res.json({ok:true,deleted:result.rowCount||0});
  }
  return res.status(400).json({error:'Unknown action.'});
}