import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access = "user";
export const methods = ["POST"];
export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });
  const { asset_id, premium } = req.body || {};
  if (!asset_id || typeof premium !== "boolean") return res.status(400).json({error:"Missing asset_id or premium"});
  await db.query("UPDATE managed_assets SET premium=$1 WHERE id=$2", [premium, asset_id]);
  res.json({ok:true});
}