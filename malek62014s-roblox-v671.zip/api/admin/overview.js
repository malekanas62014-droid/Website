import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });
  const detail = String(req.query?.detail || '').trim();
  if (detail === 'new-users') {
    const { rows } = await db.query("SELECT u.id AS user_id, COALESCE(p.username,u.name,'(no username)') AS username, u.email, u.created_at FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id WHERE u.created_at >= NOW() - INTERVAL '7 days' ORDER BY u.created_at DESC LIMIT 100");
    return res.json({ detail, users: rows });
  }
  if (detail === 'premium-users') {
    const { rows } = await db.query("SELECT w.user_id, COALESCE(p.username,u.name,'(no username)') AS username, u.email, w.coins FROM premium_wallets w LEFT JOIN users u ON u.id=w.user_id LEFT JOIN profile_usernames p ON p.user_id=w.user_id WHERE w.premium_access = true ORDER BY LOWER(COALESCE(p.username,u.name,u.email)) ASC LIMIT 200");
    return res.json({ detail, users: rows });
  }
  if (detail === 'purchases') {
    const { rows } = await db.query("SELECT p.user_id, COALESCE(pr.username,u.name,'(no username)') AS username, u.email, p.asset_key, COALESCE(a.name,p.asset_key) AS asset_name, p.purchased_at FROM asset_purchases p LEFT JOIN users u ON u.id=p.user_id LEFT JOIN profile_usernames pr ON pr.user_id=p.user_id LEFT JOIN managed_assets a ON a.id::text=p.asset_key WHERE p.purchased_at >= NOW() - INTERVAL '7 days' ORDER BY p.purchased_at DESC LIMIT 200");
    return res.json({ detail, purchases: rows });
  }
  if (detail === 'top-asset') {
    const top = await db.query("SELECT p.asset_key, COUNT(*)::int AS purchases, COALESCE(a.name,p.asset_key) AS name FROM asset_purchases p LEFT JOIN managed_assets a ON a.id::text=p.asset_key GROUP BY p.asset_key,a.name ORDER BY purchases DESC LIMIT 1");
    if (!top.rows.length) return res.json({ detail, asset: null, buyers: [] });
    const asset=top.rows[0];
    const { rows: buyers } = await db.query("SELECT p.user_id, COALESCE(pr.username,u.name,'(no username)') AS username, u.email, p.purchased_at FROM asset_purchases p LEFT JOIN users u ON u.id=p.user_id LEFT JOIN profile_usernames pr ON pr.user_id=p.user_id WHERE p.asset_key=$1 ORDER BY p.purchased_at DESC LIMIT 200",[asset.asset_key]);
    return res.json({ detail, asset, buyers });
  }
  const users = await db.query("SELECT COUNT(*)::int AS count FROM users");
  const assets = await db.query("SELECT COUNT(*)::int AS count FROM managed_assets");
  const wallets = await db.query("SELECT COALESCE(SUM(coins),0)::int AS coins FROM premium_wallets");
  const reports = await db.query("SELECT COUNT(*)::int AS count FROM user_reports WHERE status='open'");
  const tickets = await db.query("SELECT COUNT(*)::int AS count FROM support_tickets WHERE status IN ('open','pending')");
  const warnings = await db.query("SELECT COUNT(*)::int AS count FROM user_warnings WHERE acknowledged_at IS NULL");
  const banned = await db.query("SELECT COUNT(*)::int AS count FROM banned_users WHERE expires_at IS NULL OR expires_at > NOW()");
  const newUsers7d = await db.query("SELECT COUNT(*)::int AS count FROM users WHERE created_at >= NOW() - INTERVAL '7 days'");
  const purchases7d = await db.query("SELECT COUNT(*)::int AS count FROM asset_purchases WHERE purchased_at >= NOW() - INTERVAL '7 days'");
  const premiumUsers = await db.query("SELECT COUNT(*)::int AS count FROM premium_wallets WHERE premium_access = true");
  const topAsset = await db.query("SELECT p.asset_key, COUNT(*)::int AS purchases, COALESCE(a.name, p.asset_key) AS name FROM asset_purchases p LEFT JOIN managed_assets a ON a.id::text = p.asset_key GROUP BY p.asset_key, a.name ORDER BY purchases DESC LIMIT 1");
  res.json({
    users: users.rows[0].count,
    managed_assets: assets.rows[0].count,
    coins_issued: wallets.rows[0].coins,
    open_reports: reports.rows[0].count,
    open_tickets: tickets.rows[0].count,
    unacknowledged_warnings: warnings.rows[0].count,
    active_bans: banned.rows[0].count,
    new_users_7d: newUsers7d.rows[0].count,
    purchases_7d: purchases7d.rows[0].count,
    premium_users: premiumUsers.rows[0].count,
    top_asset: topAsset.rows[0] || null
  });
}