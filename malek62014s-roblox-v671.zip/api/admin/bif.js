import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET"];

export default async function(req,res){
  if(!(await assertAdmin(req))) return res.status(403).json({error:"Admin access required"});
  const q=String(req.query?.identifier||'').trim();
  if(!q) return res.status(400).json({error:"Provide a username or email"});

  const {rows:active}=await db.query(`
    SELECT u.id AS user_id,
           u.email,
           COALESCE(p.username,u.name,'') AS username,
           'active' AS source
    FROM users u
    LEFT JOIN profile_usernames p ON p.user_id=u.id
    WHERE lower(u.email)=lower($1)
       OR lower(COALESCE(p.username,u.name,''))=lower($1)
       OR lower(u.id)=lower($1)
    ORDER BY COALESCE(p.username,u.name,u.email)
  `,[q]);

  const {rows:deleted}=await db.query(`
    SELECT d.user_id,
           d.email,
           'Account Deleted' AS username,
           COALESCE(NULLIF(d.username,'Account Deleted'),
                    NULLIF((SELECT h.username FROM ban_history h
                            WHERE lower(h.email)=lower(d.email) AND h.ban_type='AD'
                            ORDER BY h.banned_at DESC LIMIT 1),''),
                    '') AS old_username,
           'deleted' AS source
    FROM deleted_accounts d
    WHERE lower(d.email)=lower($1)
       OR lower(COALESCE(d.username,''))=lower($1)
       OR EXISTS (
         SELECT 1 FROM ban_history h
         WHERE h.user_id=d.user_id
           AND h.ban_type='AD'
           AND lower(COALESCE(h.username,''))=lower($1)
       )
       OR lower(COALESCE((SELECT h.username FROM ban_history h
                          WHERE lower(h.email)=lower(d.email) AND h.ban_type='AD'
                          ORDER BY h.banned_at DESC LIMIT 1),''))=lower($1)
    ORDER BY d.deleted_at DESC
  `,[q]);

  const matches=[...active,...deleted];
  if(!matches.length) return res.status(404).json({error:"User does not exist",code:"USER_NOT_FOUND"});

  const unique=[];
  const seen=new Set();
  for(const m of matches){
    const key=String(m.user_id||m.email);
    if(seen.has(key)) continue;
    seen.add(key);
    unique.push(m);
  }

  if(!req.query?.user_id && unique.length>1){
    return res.json({identifier:q,multiple:true,matches:unique});
  }

  const selectedId=String(req.query?.user_id||'').trim();
  const user=selectedId ? unique.find(m=>String(m.user_id)===selectedId) : unique[0];
  if(!user) return res.status(404).json({error:"Selected user does not exist",code:"USER_NOT_FOUND"});

  const {rows}=await db.query(`
    SELECT id,user_id,email,username,ban_type,reason,banned_at
    FROM ban_history
    WHERE user_id=$1 OR lower(email)=lower($2)
    ORDER BY banned_at DESC
  `,[String(user.user_id),String(user.email||'')]);

  return res.json({identifier:q,user,total:rows.length,bans:rows});
}