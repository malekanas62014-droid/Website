import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
import { notifyAdminsOfModeration } from "lib/admin-moderation-notify";
export const access="user";
export const methods=["GET","POST","DELETE"];
export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
  if(req.method==='GET'){
    const {rows}=await db.query(`SELECT ib.ip,ib.reason,ib.offensive_item,ib.expires_at,ib.banned_at,
      COALESCE(string_agg(DISTINCT COALESCE(p.username,u.name,u.email), ', ' ORDER BY COALESCE(p.username,u.name,u.email)), '') AS affected_users
      FROM ip_bans ib LEFT JOIN user_last_ips li ON li.last_ip=ib.ip LEFT JOIN users u ON u.id=li.user_id LEFT JOIN profile_usernames p ON p.user_id=u.id
      WHERE ib.expires_at IS NULL OR ib.expires_at>NOW() GROUP BY ib.ip,ib.reason,ib.offensive_item,ib.expires_at,ib.banned_at ORDER BY ib.banned_at DESC`);
    return res.json(rows);
  }
  const body=req.body||{};
  if(req.method==='DELETE'){
    const ip=String(body.ip||req.query?.ip||'').trim();
    if(!ip)return res.status(400).json({error:'Missing IP address'});
    const affected=await db.query(`SELECT DISTINCT COALESCE(p.username,u.name,u.email) AS username
      FROM user_last_ips li JOIN users u ON u.id=li.user_id
      LEFT JOIN profile_usernames p ON p.user_id=u.id WHERE li.last_ip=$1`,[ip]);
    const r=await db.query('DELETE FROM ip_bans WHERE ip=$1',[ip]);
    if(Number(r.rowCount||0)>0){for(const a of affected.rows){try{await notifyAdminsOfModeration('unban',a.username,'IP ban removed');}catch(_){ }}}
    return res.json({ok:true,removed:Number(r.rowCount||0)});
  }
  const ips=Array.isArray(body.user_ids)?body.user_ids:[];
  if(!ips.length)return res.status(400).json({error:'Select at least one user.'});
  const reason=String(body.reason||'Network ban by administrator.').trim().slice(0,500);
  const offensiveItem=String(body.offensiveItem||'').trim().slice(0,500);
  const results=[];
  for(const id of ips){
    const {rows}=await db.query(`SELECT u.id,u.email,COALESCE(p.username,u.name,'') AS username,COALESCE(li.last_ip,'') AS last_ip FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_last_ips li ON li.user_id=u.id WHERE lower(u.id)=lower($1) LIMIT 1`,[String(id)]);
    if(!rows.length)continue;
    const u=rows[0];
    if(!u.last_ip){results.push({user_id:u.id,ok:false,error:'No recorded IP'});continue;}
    await db.query(`INSERT INTO ip_bans (ip,reason,offensive_item,expires_at) VALUES ($1,$2,$3,NULL) ON CONFLICT (ip) DO UPDATE SET reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL`,[u.last_ip,reason,offensiveItem]);
    await db.query(`INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item) VALUES ($1,$2,$3,'IB',$4,$5)`,[String(u.id),u.email,u.username,reason,offensiveItem]);
    try{await notifyAdminsOfModeration('ban',u.username,reason+' · IP ban');}catch(_){ }
    results.push({user_id:u.id,username:u.username,ip:u.last_ip,ok:true});
  }
  return res.json({ok:true,results});
}