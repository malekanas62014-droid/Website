import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET","POST"];
async function allowed(req,res){if(!(await assertAdmin(req))){res.status(403).json({error:'Admin access required'});return false}return true}
export default async function(req,res){
  if(!(await allowed(req,res)))return;
  if(req.method==='GET'){
    const limit=Math.min(500,Math.max(1,Number.parseInt(String(req.query?.limit||'200'),10)||200));
    const {rows}=await db.query("SELECT l.id,l.user_id,l.username,COALESCE(l.email,u.email,'') AS email,COALESCE(l.original_message,l.message) AS message,l.reason,l.matched_terms,l.message_type,l.created_at FROM chat_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT $1",[limit]);
    return res.json({logs:rows});
  }
  const action=String(req.body?.action||'');
  if(action==='delete_log'){
    const id=String(req.body?.id||'');if(!id)return res.status(400).json({error:'Log id required.'});
    const {rowCount}=await db.query("DELETE FROM chat_logs WHERE id=$1",[id]);return res.json({ok:rowCount>0});
  }
  if(action==='bulk_delete'){
    const ids=Array.isArray(req.body?.ids)?req.body.ids.map(String).filter(Boolean):[];
    if(!ids.length)return res.status(400).json({error:'Select at least one log.'});
    const {rowCount}=await db.query("DELETE FROM chat_logs WHERE id = ANY($1::uuid[])",[ids]);return res.json({ok:true,deleted:rowCount||0});
  }
  return res.status(400).json({error:'Unknown action.'});
}