import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["POST"];
export default async function(req,res){if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
 const b=req.body||{}; if(b.asset_id==null)return res.status(400).json({error:"Missing asset id"});
 const id=String(b.asset_id).trim();
 if(id.startsWith('legacy-')){
  const legacy=id.slice(7);
  const defaultCategories={wall:'scripts',boss:'scripts',sink:'models',acv2:'models',ac:'models',flashlight3:'flashlights',flashlight2:'flashlights',workspace:'tools',flashlight:'flashlights',traffic:'models',gamble:'scripts',door:'models',gui:'models',run:'scripts',settings:'scripts',shop:'scripts'};
  const defaultCategory=defaultCategories[legacy]||'models';
  await db.query("INSERT INTO page_asset_overrides (legacy_id,disabled,disabled_reason,removed,premium,basic_price,premium_price,category,has_scripts) VALUES ($1,COALESCE($2,false),$3,false,$4,COALESCE($5,0),COALESCE($6,0),$8,$7) ON CONFLICT (legacy_id) DO UPDATE SET disabled=COALESCE($2,page_asset_overrides.disabled),disabled_reason=CASE WHEN $2=true THEN $3 WHEN $2=false THEN NULL ELSE page_asset_overrides.disabled_reason END,premium=COALESCE($4,page_asset_overrides.premium),basic_price=COALESCE($5,page_asset_overrides.basic_price),premium_price=COALESCE($6,page_asset_overrides.premium_price),category=CASE WHEN page_asset_overrides.category='everything' THEN $8 ELSE page_asset_overrides.category END,has_scripts=COALESCE($7,page_asset_overrides.has_scripts)",[legacy,typeof b.disabled==='boolean'?b.disabled:null,String(b.reason||''),typeof b.premium==='boolean'?b.premium:null,b.basic_price==null?null:Math.max(0,Number(b.basic_price)||0),b.premium_price==null?null:Math.max(0,Number(b.premium_price)||0),typeof b.has_scripts==='boolean'?b.has_scripts:null,defaultCategory]);
 } else {
  const managedId=Number(id);
  if(!Number.isInteger(managedId)||managedId<1)return res.status(400).json({error:"Invalid asset id"});
  await db.query("UPDATE managed_assets SET premium=COALESCE($2,premium),disabled=COALESCE($3,disabled),disabled_reason=CASE WHEN $3=true THEN $4 WHEN $3=false THEN NULL ELSE disabled_reason END,basic_price=COALESCE($5,basic_price),premium_price=COALESCE($6,premium_price),has_scripts=COALESCE($7,has_scripts),download_enabled=CASE WHEN $3=true THEN false WHEN $3=false THEN true ELSE download_enabled END,updated_at=now() WHERE id=$1",[Number(id),typeof b.premium==='boolean'?b.premium:null,typeof b.disabled==='boolean'?b.disabled:null,String(b.reason||''),b.basic_price==null?null:Math.max(0,Number(b.basic_price)||0),b.premium_price==null?null:Math.max(0,Number(b.premium_price)||0),typeof b.has_scripts==='boolean'?b.has_scripts:null]);
 }
 res.json({ok:true});
}