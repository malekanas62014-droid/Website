import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["POST"];

const OWNER_EMAIL = "robloxassetsowner@protonmail.com";

export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });

  const { identifier, is_admin } = req.body || {};
  const value = String(identifier || "").trim();
  if (!value) return res.status(400).json({ error: "Missing user identifier" });

  const { rows } = await db.query(
    "SELECT u.id, u.email, COALESCE(p.username, u.name, '') AS username FROM users u LEFT JOIN profile_usernames p ON p.user_id = u.id WHERE lower(u.email)=lower($1) OR lower(COALESCE(p.username,u.name,''))=lower($1) OR lower(u.id)=lower($1) LIMIT 1",
    [value]
  );
  if (!rows.length) return res.status(404).json({ error: "User not found" });

  const user = rows[0];
  const {rows:deletedRows}=await db.query("SELECT 1 FROM deleted_accounts WHERE lower(email)=lower($1) LIMIT 1",[String(user.email||'')]);
  if(deletedRows.length)return res.status(403).json({error:"Deleted accounts are view-only and cannot be made admin."});
  const email = String(user.email || "").trim().toLowerCase();
  if (email === OWNER_EMAIL) return res.status(400).json({ error: "The owner is always an admin." });

  const enabled = Boolean(is_admin);
  const accountId = String(user.id);
  if (enabled) {
    // Normalize this identity first so a stale row for the same email can never
    // keep a second copy of the account elevated.
    await db.query(
      "DELETE FROM admin_user_directory WHERE user_id=$1 OR lower(email)=lower($2)",
      [accountId, user.email]
    );
    await db.query(
      "INSERT INTO admin_user_directory (user_id,email,username,is_admin) VALUES ($1,$2,$3,true)",
      [accountId, user.email, user.username]
    );
  } else {
    // Revoke by BOTH identity keys. Updating only user_id was the bug that
    // left stale email-matched rows able to authorize the account forever.
    await db.query(
      "DELETE FROM admin_user_directory WHERE user_id=$1 OR lower(email)=lower($2)",
      [accountId, user.email]
    );
  }

  res.setHeader('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
  res.json({ ok: true, user_id: accountId, email: user.email, username: user.username, is_admin: enabled });
}