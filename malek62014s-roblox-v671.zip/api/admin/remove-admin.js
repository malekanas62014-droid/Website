import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["POST"];

const OWNER_EMAIL = "robloxassetsowner@protonmail.com";

export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });

  const value = String(req.body?.identifier || "").trim();
  if (!value) return res.status(400).json({ error: "Missing user identifier" });

  const { rows } = await db.query(
    "SELECT u.id,u.email,COALESCE(p.username,u.name,'') AS username FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id WHERE lower(u.email)=lower($1) OR lower(COALESCE(p.username,u.name,''))=lower($1) OR lower(u.id)=lower($1) LIMIT 1",
    [value]
  );
  if (!rows.length) return res.status(404).json({ error: "User not found" });

  const user = rows[0];
  const email = String(user.email || "").trim().toLowerCase();
  if (email === OWNER_EMAIL) return res.status(400).json({ error: "The owner is always an admin." });

  const removed = await db.query(
    "DELETE FROM admin_user_directory WHERE user_id=$1 OR lower(email)=lower($2)",
    [String(user.id), user.email]
  );

  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  res.json({ ok: true, user_id: String(user.id), email: user.email, username: user.username, is_admin: false, removed_rows: Number(removed.rowCount || 0) });
}