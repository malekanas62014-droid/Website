import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["DELETE"];
export default async function(req,res){
  if(!(await assertAdmin(req))) return res.status(403).json({error:"Admin access required"});
  const ids=Array.isArray(req.body?.ids)?req.body.ids.map(x=>String(x).trim().toLowerCase()).filter(Boolean):[];
  if(!ids.length) return res.status(400).json({error:"Select at least one history record"});
  const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const invalid=ids.find(id=>!uuid.test(id));
  if(invalid)return res.status(400).json({error:"One or more history record ids are invalid."});
  const result=await db.query("DELETE FROM ban_history WHERE id = ANY($1::uuid[])",[ids]);
  return res.json({ok:true,deleted:Number(result.rowCount||0)});
}