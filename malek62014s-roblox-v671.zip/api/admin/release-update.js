import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["POST"];

const clean = (value, max) => String(value ?? "").trim().slice(0, max);
const validKinds = new Set(["Feature", "Improvement", "Fix", "Security", "Maintenance", "Update"]);

function nextUpdateVersion(latest) {
  const value = String(latest || "1").trim();
  const parts = value.split(".");
  if (!parts.length || parts.some(part => !/^\d+$/.test(part))) return "1.1";
  if (parts.length === 1) return parts[0] + ".1";
  const last = Number(parts[parts.length - 1]);
  if (!Number.isSafeInteger(last)) return "1.1";
  parts[parts.length - 1] = String(last + 1);
  return parts.join(".");
}

export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });

  const body = req.body || {};
  const title = clean(body.title, 120);
  const summary = clean(body.summary, 2000);
  const kind = clean(body.kind, 30) || "Update";

  if (!title) return res.status(400).json({ error: "Add a title for this release." });
  if (!summary) return res.status(400).json({ error: "Describe what's new before releasing the update." });
  if (!validKinds.has(kind)) return res.status(400).json({ error: "Choose a valid update type." });

  const { rows: latestRows } = await db.query(
    "SELECT version FROM update_logs ORDER BY created_at DESC, id DESC LIMIT 1"
  );
  const updateVersion = nextUpdateVersion(latestRows[0]?.version);

  try {
    const tx = await db.transaction([
      {
        sql: "UPDATE manual_update_release SET release_version = release_version + 1, updated_at = NOW(), release_title = $1, release_summary = $2, release_kind = $3 WHERE id = 1 RETURNING release_version, updated_at, release_title, release_summary, release_kind",
        params: [title, summary, kind]
      },
      {
        sql: "INSERT INTO update_logs (version, title, summary, kind) VALUES ($1, $2, $3, $4) RETURNING id, version, title, summary, kind, created_at",
        params: [updateVersion, title, summary, kind]
      }
    ]);

    const release = tx?.results?.[0]?.rows?.[0];
    const log = tx?.results?.[1]?.rows?.[0];
    if (!release || !log) {
      return res.status(500).json({ error: "The release could not be verified. Please check Update Logs before retrying." });
    }

    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    return res.json({
      ok: true,
      version: String(release.release_version),
      updated_at: release.updated_at,
      release: {
        title: release.release_title,
        summary: release.release_summary,
        kind: release.release_kind
      },
      log
    });
  } catch (error) {
    if (String(error?.message || "").toLowerCase().includes("unique")) {
      return res.status(409).json({ error: "That Update Log version already exists. Refresh the page and try again." });
    }
    throw error;
  }
}