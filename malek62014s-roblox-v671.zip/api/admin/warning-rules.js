import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access="user";
export const methods=["GET","POST"];

async function admin(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
}

export default async function(req,res){
  const denied=await admin(req,res); if(denied)return denied;
  const canonicalFilterTerm=(term)=>{
    const raw=String(term||'').trim().toLowerCase();
    const aliases={fucking:'fuck',fucked:'fuck',fucker:'fuck',fuckin:'fuck',motherfuck:'fuck',bullshit:'shit',sh1t:'shit',bitch:'bitch',bi7ch:'bitch',bitc:'bitch',b1tch:'bitch'};
    return aliases[raw]||raw;
  };
  if(req.method==='GET'){
    const filterTerm=canonicalFilterTerm(String(req.query?.filter_term||'').trim().slice(0,100));
    const params=filterTerm?[filterTerm]:[];
    const sql=filterTerm
      ? "SELECT id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index,created_at,updated_at FROM warning_escalation_rules WHERE lower(filter_term)=lower($1) ORDER BY order_index ASC,created_at ASC,id ASC"
      : "SELECT id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index,created_at,updated_at FROM warning_escalation_rules ORDER BY lower(filter_term) ASC,order_index ASC,created_at ASC,id ASC";
    const {rows}=await db.query(sql,params);
    return res.json({rules:rows});
  }
  const action=String(req.body?.action||'');
  if(action==='create'){
    const filterTerm=canonicalFilterTerm(String(req.body?.filter_term||'').trim().slice(0,100));
    const warningCount=Math.max(1,Math.min(1000,Number(req.body?.warning_count||1)));
    const ruleAction=String(req.body?.rule_action||'warn').toLowerCase();
    const reason=String(req.body?.reason||'').trim().slice(0,500);
    const banDuration=['ban','ip_ban'].includes(ruleAction)?Math.max(1,Math.min(315360000,Math.floor(Number(req.body?.ban_duration_seconds??604800)))):0;
    if(filterTerm.length<2)return res.status(400).json({error:'Main filter word is required.'});
    if(!['warn','delete','ip_ban','ban'].includes(ruleAction))return res.status(400).json({error:'Invalid escalation action.'});
    const {rows}=await db.query(
      "INSERT INTO warning_escalation_rules (filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index) VALUES ($1,$2,$3,$4,true,$5,COALESCE((SELECT MAX(order_index)+1 FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)),1)) RETURNING id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index,created_at,updated_at",
      [filterTerm,warningCount,ruleAction,reason,banDuration]
    );
    return res.status(201).json({rule:rows[0]});
  }
  if(action==='update'){
    const id=String(req.body?.id||'').trim();
    const warningCount=Math.max(1,Math.min(1000,Number(req.body?.warning_count||1)));
    const ruleAction=String(req.body?.rule_action||'warn').toLowerCase();
    const reason=String(req.body?.reason||'').trim().slice(0,500);
    const banDuration=ruleAction==='ban'?Math.max(1,Math.min(315360000,Math.floor(Number(req.body?.ban_duration_seconds??604800)))):0;
    const enabled=req.body?.enabled!==false;
    if(!id)return res.status(400).json({error:'Rule id is required.'});
    if(!['warn','delete','ip_ban','ban','permanent_ban'].includes(ruleAction))return res.status(400).json({error:'Invalid escalation action.'});
    const {rows}=await db.query(
      "UPDATE warning_escalation_rules SET warning_count=$2,action=$3,reason=$4,enabled=$5,ban_duration_seconds=$6,updated_at=NOW() WHERE id=$1 RETURNING id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,created_at,updated_at",
      [id,warningCount,ruleAction,reason,enabled,banDuration]
    );
    if(!rows.length)return res.status(404).json({error:'Warning escalation rule not found.'});
    return res.json({rule:rows[0]});
  }
  if(action==='delete'){
    const id=String(req.body?.id||'').trim();
    if(!id)return res.status(400).json({error:'Rule id is required.'});
    const {rowCount}=await db.query("DELETE FROM warning_escalation_rules WHERE id=$1",[id]);
    if(!rowCount)return res.status(404).json({error:'Warning escalation rule not found.'});
    return res.json({ok:true,id});
  }
  return res.status(400).json({error:'Unknown warning-rule action.'});
}