import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["POST"];

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
  const recipientId=String(req.body?.recipientId||'').trim();
  const title=String(req.body?.title||'').trim();
  const message=String(req.body?.message||'').trim();
  const buttonText=String(req.body?.buttonText||'Got it').trim()||'Got it';
  if(!recipientId)return res.status(400).json({error:'A target user is required.'});
  if(!title)return res.status(400).json({error:'Enter a Troll title.'});
  if(!message)return res.status(400).json({error:'Enter a Troll message.'});
  if(title.length>120)return res.status(400).json({error:'Troll title must be 120 characters or fewer.'});
  if(message.length>1500)return res.status(400).json({error:'Troll message must be 1500 characters or fewer.'});
  if(buttonText.length>40)return res.status(400).json({error:'Button text must be 40 characters or fewer.'});
  const {rowCount}=await db.query(`SELECT 1 FROM users WHERE id=$1 LIMIT 1`,[recipientId]);
  if(!rowCount)return res.status(404).json({error:'Target user was not found.'});
  const {rows}=await db.query(`INSERT INTO troll_notifications (recipient_id,title,message,button_text) VALUES ($1,$2,$3,$4) RETURNING id,created_at`,[recipientId,title,message,buttonText]);
  return res.json({ok:true,troll:rows[0]});
}