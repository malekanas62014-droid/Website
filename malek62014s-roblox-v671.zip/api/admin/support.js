import { admin, db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
import { sendWebPushToUser } from "lib/web-push";

export const access = "user";
export const methods = ["GET","POST"];

const statuses=new Set(["open","waiting_user","in_progress","closed"]);
const priorities=new Set(["low","normal","high"]);
const resolutions=new Set(["resolved","declined"]);
const OWNER_EMAIL="robloxassetsowner@protonmail.com";

async function getSupportStaffIdentity(req){
  const platform=await admin.profile(req).catch(()=>null);
  const platformHandle=String(platform?.handle||'').trim();
  const platformEmail=String(platform?.email||'').trim().toLowerCase();
  let websiteUsername='';
  let email=platformEmail;
  const {rows}=await db.query(
    `SELECT u.email,p.username AS website_username,d.username AS admin_username
     FROM users u
     LEFT JOIN profile_usernames p ON p.user_id=u.id
     LEFT JOIN admin_user_directory d ON d.user_id=u.id
     WHERE lower(u.email)=lower($1) OR lower(COALESCE(d.email,''))=lower($1) OR lower(COALESCE(d.username,''))=lower($1)
     LIMIT 1`,
    [platformHandle||platformEmail]
  );
  if(rows[0]){
    email=String(rows[0].email||email).trim().toLowerCase();
    websiteUsername=String(rows[0].website_username||rows[0].admin_username||'').trim();
  }
  if(email===OWNER_EMAIL || platformHandle.toLowerCase()==='malekanas62014'){
    const {rows:ownerRows}=await db.query(
      `SELECT u.email,p.username AS website_username
       FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id
       WHERE lower(u.email)=lower($1) LIMIT 1`,
      [OWNER_EMAIL]
    );
    email=OWNER_EMAIL;
    websiteUsername=String(ownerRows[0]?.website_username||'Malek62014').trim();
    return {senderName:'Owner · '+websiteUsername,senderEmail:email,senderUserId:String(platform?.id||'admin')};
  }
  return {senderName:'Admin · '+(websiteUsername||platformHandle||'Unknown'),senderEmail:email,senderUserId:String(platform?.id||'admin')};
}

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
  if(req.method==='GET'){
    const status=String(req.query?.status||'').trim();
    const search=String(req.query?.search||'').trim().slice(0,120);
    const where=[];const params=[];
    if(status){if(!statuses.has(status))return res.status(400).json({error:'Invalid status.'});params.push(status);where.push(`t.status=$${params.length}`);}
    if(search){params.push('%'+search.toLowerCase()+'%');where.push(`(lower(t.subject) LIKE $${params.length} OR lower(t.username) LIKE $${params.length} OR lower(t.user_email) LIKE $${params.length})`);}
    const clause=where.length?' WHERE '+where.join(' AND '):'';
    const {rows}=await db.query(`SELECT t.id,t.user_id,t.user_email,t.username,t.subject,t.category,t.priority,t.status,t.assigned_admin,t.created_at,t.updated_at,t.closed_at,
      (SELECT m.message FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_message,
      (SELECT m.sender_role FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_sender_role,
      (SELECT COUNT(*)::int FROM support_messages m WHERE m.ticket_id=t.id) AS message_count
      FROM support_tickets t${clause} ORDER BY CASE t.priority WHEN 'high' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,t.updated_at DESC,t.id DESC LIMIT 300`,params);
    const {rows:counts}=await db.query(`SELECT status,COUNT(*)::int AS count FROM support_tickets GROUP BY status`);
    return res.json({tickets:rows,counts});
  }
  const action=String(req.body?.action||'').trim();
  const ticketId=Number(req.body?.ticket_id);
  if(!Number.isInteger(ticketId)||ticketId<1)return res.status(400).json({error:'Invalid ticket id.'});
  const exists=await db.query('SELECT id FROM support_tickets WHERE id=$1 LIMIT 1',[ticketId]);
  if(!exists.rows.length)return res.status(404).json({error:'Support ticket not found.'});
  if(action==='set_status'){
    const status=String(req.body?.status||'').trim();
    if(!statuses.has(status))return res.status(400).json({error:'Invalid status.'});
    if(status==='closed'){
      const resolution=String(req.body?.resolution||'').trim().toLowerCase();
      if(!resolutions.has(resolution))return res.status(400).json({error:'Choose Resolved or Declined.'});
      const ticketResult=await db.query('SELECT id,user_id,username,subject FROM support_tickets WHERE id=$1 LIMIT 1',[ticketId]);
      const ticket=ticketResult.rows[0];
      const staff=await getSupportStaffIdentity(req);
      const {rows:userRows}=await db.query('SELECT 1 FROM users WHERE id=$1 LIMIT 1',[String(ticket.user_id)]);
      const recipientType=userRows.length?'user':'guest';
      const verb=resolution==='declined'?'declined':'resolved';
      const title=resolution==='declined'?'Support ticket declined':'Support ticket resolved';
      const message=`Your support ticket #${ticket.id} · ${ticket.subject} has been ${verb} by ${staff.senderName}. If you still need help, you can create a new support ticket.`;
      const notificationResult=await db.transaction([
        {sql:`INSERT INTO support_notifications (recipient_type,recipient_id,title,message) VALUES ($1,$2,$3,$4) RETURNING id`,params:[recipientType,String(ticket.user_id),title,message]},
        {sql:'DELETE FROM support_messages WHERE ticket_id=$1',params:[ticketId]},
        {sql:'DELETE FROM support_tickets WHERE id=$1',params:[ticketId]}
      ]);
      if(recipientType==='user'){
        try{
          const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_support,true) AS support FROM user_preferences WHERE user_id=$1 LIMIT 1",[String(ticket.user_id)]);
          if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].support!==false))await sendWebPushToUser(String(ticket.user_id),title,message,'support_'+String(notificationResult.results?.[0]?.rows?.[0]?.id||ticketId));
        }catch(_){ }
      }
      return res.json({ok:true,status:'closed',resolution,deleted:true,notification_sent:true,recipient_type:recipientType});
    }
    await db.query(`UPDATE support_tickets SET status=$2,updated_at=NOW(),closed_at=NULL WHERE id=$1`,[ticketId,status]);
    return res.json({ok:true,status});
  }
  if(action==='set_priority'){
    const priority=String(req.body?.priority||'').trim().toLowerCase();
    if(!priorities.has(priority))return res.status(400).json({error:'Invalid priority.'});
    await db.query('UPDATE support_tickets SET priority=$2,updated_at=NOW() WHERE id=$1',[ticketId,priority]);
    return res.json({ok:true,priority});
  }
  if(action==='assign'){
    const assigned=String(req.body?.assigned_admin||'').trim().slice(0,120);
    await db.query('UPDATE support_tickets SET assigned_admin=$2,updated_at=NOW() WHERE id=$1',[ticketId,assigned]);
    return res.json({ok:true,assigned_admin:assigned});
  }
  if(action==='delete_ticket'){
    const reason=String(req.body?.reason||'Admin deleted ticket').trim().slice(0,500);
    await db.transaction([
      {sql:'DELETE FROM support_messages WHERE ticket_id=$1',params:[ticketId]},
      {sql:'DELETE FROM support_tickets WHERE id=$1',params:[ticketId]}
    ]);
    return res.json({ok:true,deleted:true,ticket_id:ticketId,reason});
  }
  if(action==='reply'){
    const message=String(req.body?.message||'').trim().slice(0,4000);
    if(!message)return res.status(400).json({error:'Reply cannot be empty.'});
    const staff=await getSupportStaffIdentity(req);
    const inserted=await db.query(`INSERT INTO support_messages (ticket_id,sender_user_id,sender_name,sender_email,sender_role,message)
      VALUES ($1,$2,$3,$4,'admin',$5) RETURNING id,ticket_id,sender_name,sender_email,sender_role,message,created_at`,[ticketId,staff.senderUserId,staff.senderName,staff.senderEmail,message]);
    const ticketRow=await db.query('SELECT user_id,subject FROM support_tickets WHERE id=$1 LIMIT 1',[ticketId]);
    await db.query(`UPDATE support_tickets SET status='waiting_user',updated_at=NOW(),closed_at=NULL WHERE id=$1`,[ticketId]);
    const target=ticketRow.rows[0];
    if(target?.user_id){
      try{
        const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_support,true) AS support FROM user_preferences WHERE user_id=$1 LIMIT 1",[String(target.user_id)]);
        if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].support!==false))await sendWebPushToUser(String(target.user_id),'Customer Support','New reply on ticket #'+String(ticketId)+' · '+String(target.subject||''),'support_reply_'+String(inserted.rows[0].id));
      }catch(_){ }
    }
    return res.status(201).json({ok:true,message:inserted.rows[0],status:'waiting_user'});
  }
  return res.status(400).json({error:'Unknown support action.'});
}