import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["DELETE"];

export default async function(req,res){
  if(!(await assertAdmin(req))) return res.status(403).json({error:"Admin access required"});
  const id=String(req.body?.id||'').trim();
  if(!id) return res.status(400).json({error:"History id is required"});
  const result=await db.query("DELETE FROM ban_history WHERE id=$1",[id]);
  if(!result.rowCount) return res.status(404).json({error:"Ban history record not found"});
  return res.json({ok:true,deleted:1});
}