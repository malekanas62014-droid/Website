import { db, storage } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access = "user";
export const methods = ["POST"];
export default async function(req,res){if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
 const f=req.files?.[0];
 const body=req.body||{};
 if(!f) return res.status(400).json({error:"Choose a file first"});
 const name=String(body.name||f.filename).trim();
 const requestedCategories=String(body.category||"").split(',').map(v=>v.trim()).filter(Boolean);
 const { rows: categoryRows } = await db.query("SELECT name,slug FROM website_categories");
 const categoryMap=new Map(); categoryRows.forEach(c=>{categoryMap.set(String(c.name).trim().toLowerCase(),String(c.slug).trim().toLowerCase());categoryMap.set(String(c.slug).trim().toLowerCase(),String(c.slug).trim().toLowerCase());});
 const normalizedCategories=[]; for(const requestedCategory of requestedCategories){const slug=categoryMap.get(requestedCategory.toLowerCase());if(!slug)return res.status(400).json({error:`Category "${requestedCategory}" does not exist. Create it in Website settings first.`});if(!normalizedCategories.includes(slug))normalizedCategories.push(slug);}
 const category=normalizedCategories.join(',');
 const premium=String(body.premium)==="true";
 const hasScripts=String(body.has_scripts)==="true";
 const basicPrice=premium?0:Math.max(0,Number(body.basic_price)||0);
 const premiumPrice=premium?Math.max(0,Number(body.premium_price)||0):0;
 const key=`assets/${Date.now()}-${f.filename.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
 await storage.put(key,f.buffer,f.contentType||"application/octet-stream");
 await db.query("INSERT INTO managed_assets (name,category,premium,storage_key,bytes,basic_price,premium_price,disabled,disabled_reason,download_enabled,has_scripts) VALUES ($1,$2,$3,$4,$5,$6,$7,false,NULL,true,$8)",[name,category,premium,key,f.buffer.length,basicPrice,premiumPrice,hasScripts]);
 res.json({ok:true,name});
}