import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access = "user";
export const methods = ["POST"];
export default async function(req,res){if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
 const email=String(req.body?.email||'').trim(); const username=String(req.body?.username||'').trim();
 if(!email||!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({error:'Invalid email or username.'});
 const {rows:u}=await db.query('SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1',[email]);
 if(!u.length)return res.status(404).json({error:'User not found.'});
 const {rows:x}=await db.query('SELECT user_id FROM profile_usernames WHERE lower(username)=lower($1) LIMIT 1',[username]);
 if(x.length&&x[0].user_id!==u[0].id)return res.status(409).json({error:'That username is already taken.'});
 await db.query('INSERT INTO profile_usernames (user_id,username) VALUES ($1,$2) ON CONFLICT (user_id) DO UPDATE SET username=EXCLUDED.username',[u[0].id,username]);
 res.json({ok:true,username});
}