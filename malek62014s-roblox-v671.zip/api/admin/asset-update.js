import { db, storage } from "hatchable";
import crypto from "node:crypto";
import { assertAdmin } from "lib/admin-auth";

export const access = "user";
export const methods = ["POST"];

export default async function(req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });

  const f = req.files?.[0];
  const id = String(req.body?.asset_id || "");
  if (!id) return res.status(400).json({ error: "Choose an asset first" });
  const isLegacy = id.startsWith("legacy-");
  const legacyId = isLegacy ? id.slice(7) : "";
  const managedId = Number(id);
  if (!isLegacy && (!Number.isInteger(managedId) || managedId < 1)) return res.status(400).json({ error: "Invalid asset id" });
  if (!f) return res.status(400).json({ error: "Choose the updated file first" });
  if (!f.buffer) return res.status(400).json({ error: "The uploaded replacement file could not be read." });

  const legacyDefaults={wall:'scripts',boss:'scripts',sink:'models',acv2:'models',ac:'models',flashlight3:'flashlights',flashlight2:'flashlights',workspace:'tools',flashlight:'flashlights',traffic:'models',gamble:'scripts',door:'models',gui:'models',run:'scripts',settings:'scripts',shop:'scripts'};
  let rows;
  if (isLegacy) {
    const result = await db.query("SELECT legacy_id,storage_key,category,premium,basic_price,premium_price,has_scripts FROM page_asset_overrides WHERE legacy_id=$1 LIMIT 1", [legacyId]);
    rows = result.rows;
    if (!rows.length) {
      const category=legacyDefaults[legacyId]||'everything';
      await db.query("INSERT INTO page_asset_overrides (legacy_id,storage_key,category) VALUES ($1,NULL,$2)",[legacyId,category]);
      rows = [{ legacy_id: legacyId, storage_key: null, category, premium:null, basic_price:null, premium_price:null, has_scripts:null }];
    }
  } else {
    const result = await db.query(
      "SELECT id,storage_key,name,category,premium,basic_price,premium_price,has_scripts FROM managed_assets WHERE id=$1 LIMIT 1",
      [managedId]
    );
    rows = result.rows;
    if (!rows.length) return res.status(404).json({ error: "Asset not found" });
  }

  const body=req.body||{};
  const hasField=k=>Object.prototype.hasOwnProperty.call(body,k);
  const currentPremium=rows[0].premium===true||rows[0].premium===1||String(rows[0].premium||'').toLowerCase()==='true'||String(rows[0].premium||'')==='1';
  const premium=hasField('premium') ? (body.premium===true||String(body.premium||'').toLowerCase()==='true') : currentPremium;
  const name=hasField('name') ? String(body.name||'').trim().slice(0,180) : String(rows[0].name||f.filename||'asset.rbxm').trim().slice(0,180);
  if(!name)return res.status(400).json({error:'Asset name cannot be empty.'});
  let basicPrice=hasField('basic_price')?Math.max(0,Number(body.basic_price)||0):Math.max(0,Number(rows[0].basic_price??0)||0);
  let premiumPrice=hasField('premium_price')?Math.max(0,Number(body.premium_price)||0):Math.max(0,Number(rows[0].premium_price??0)||0);
  if(premium)basicPrice=0;else premiumPrice=0;
  const hasScripts=hasField('has_scripts')?((body.has_scripts===true)||String(body.has_scripts||'').toLowerCase()==='true'):rows[0].has_scripts;
  const category=hasField('category')?String(body.category||'').trim().toLowerCase()||String(rows[0].category||'everything'):String(rows[0].category||'everything');

  const sourceFilename = String(f.filename || "asset.rbxm").trim() || "asset.rbxm";
  const safeFilename = sourceFilename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
  const oldKey=String(rows[0].storage_key||"").trim();
  // Every replacement gets a NEW object key. Never reuse the old CDN/storage key,
  // otherwise an already-cached download can continue serving the previous bytes.
  const key = `assets/${crypto.randomUUID()}-${safeFilename}`;
  await storage.put(key, f.buffer, f.contentType || "application/octet-stream");

  try {
    if (isLegacy) {
      const updated = await db.query("UPDATE page_asset_overrides SET storage_key=$1,category=$2,premium=$3,basic_price=$4,premium_price=$5,has_scripts=$6 WHERE legacy_id=$7 RETURNING legacy_id,storage_key", [key,category,premium,basicPrice,premiumPrice,hasScripts,legacyId]);
      if (!updated.rows.length) throw Error("The legacy asset could not be updated.");
    } else {
      const updated = await db.query(
        "UPDATE managed_assets SET name=$1,storage_key=$2,bytes=$3,updated_at=now(),download_enabled=true,premium=$4,basic_price=$5,premium_price=$6,has_scripts=$7,category=$8 WHERE id=$9 RETURNING id,storage_key,name,bytes",
        [name, key, f.buffer.length, premium, basicPrice, premiumPrice, hasScripts, category, managedId]
      );
      if (!updated.rows.length) throw Error("Asset update did not modify the selected asset.");
    }
    if (rows[0].storage_key && String(rows[0].storage_key) !== key) {
      try { await storage.del(rows[0].storage_key); } catch {}
    }
  } catch (error) {
    try { await storage.del(key); } catch {}
    throw error;
  }

  res.json({ ok: true, name });
}