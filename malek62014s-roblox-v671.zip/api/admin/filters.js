import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET","POST"];

const CORE_FILTERS=['fuck','fucking','fucked','fucker','fuckin','motherfuck','shit','bullshit','sh1t','bitch','bi7ch','bitc','b1tch','asshole','arsehole','dick','dickhead','dih','dik','d1ck','penis','cock','piss','pissed','cunt','cnt','bastard','whore','slut','faggot','fag','nigger','nigga','n1gga','n1gger','retard','retarded','porn','porno','pornography','pron','p0rn','rule34','hentai','ecchi','nsfw','nsfl','sex','seggs','sexual','seggsy','sexy','horny','nude','nudes','nudity','naked','send nudes','rape','rapist','molest','molestation','pedophile','pedo','predator','kys','kill yourself','go die','masturbate','masturbating','masterbate','masterbating','jerkoff','jerking off','handjob','hand job','blowjob','blow job','cum','cumming','cummed','creampie','orgasm','anal','boobs','boob','tits','titty','milf','dildo','vibrator','thot','hoe','hoes','slutty','ussy','pussy','bussy','daddy','suck me','suck it','dick pic','cock pic','onlyfans','fanvue','goon','gooner','gooning','goan','goaned','goaning','edging','edge me','coom','coomer','gyat','gyatt','hawk tuah','throat goat','deepthroat','fetish','bdsm','incest','step sis','stepbro','step mom','stepmom','stepsis','sussy','sus','sext','sexting','hornypost','r34','r34r','dingaling','ding-a-ling','dong','dongalong','dongalang','donk','fuk','fck','fuq','dix','dixs','dixx','c0ck','p3nis','dixxx','ballsack','ballsy','testicle','testicles','scrotum','boobies','titties','pornhub','xvideos','xnxx','ass','damn','hell','wtf','wth','stfu','omfg','ffs','contextual sexual slang'];
const OG_GROUPS=[{name:'fuck',roots:['fuck']},{name:'shit',roots:['shit']},{name:'bitch',roots:['bitch','bitc']},{name:'dick',roots:['dick','dik','dix','dih']},{name:'penis',roots:['penis']},{name:'cock',roots:['cock']},{name:'piss',roots:['piss']},{name:'cunt',roots:['cunt']},{name:'bastard',roots:['bastard']},{name:'fag',roots:['fag']},{name:'nigger',roots:['nigg']},{name:'retard',roots:['retard']},{name:'porn',roots:['porn']},{name:'rule34',roots:['rule34','r34']},{name:'hentai',roots:['hentai']},{name:'sex',roots:['sex','segg']},{name:'horny',roots:['horny']},{name:'nude',roots:['nude']},{name:'rape',roots:['rape']},{name:'molest',roots:['molest']},{name:'pedo',roots:['pedo']},{name:'masturbate',roots:['masturb']},{name:'jerkoff',roots:['jerkoff']},{name:'handjob',roots:['handjob']},{name:'blowjob',roots:['blowjob']},{name:'cum',roots:['cum']},{name:'creampie',roots:['creampie']},{name:'orgasm',roots:['orgasm']},{name:'anal',roots:['anal']},{name:'boob',roots:['boob']},{name:'tits',roots:['tit']},{name:'milf',roots:['milf']},{name:'dildo',roots:['dildo']},{name:'vibrator',roots:['vibrator']},{name:'pussy',roots:['pussy']},{name:'thot',roots:['thot']},{name:'slut',roots:['slut']},{name:'whore',roots:['whore']},{name:'goon',roots:['goon']},{name:'coom',roots:['coom']},{name:'gyat',roots:['gyat']},{name:'sext',roots:['sext']},{name:'edging',roots:['edg']},{name:'fetish',roots:['fetish']},{name:'bdsm',roots:['bdsm']},{name:'incest',roots:['incest']},{name:'step',roots:['step']},{name:'onlyfans',roots:['onlyfans']},{name:'fanvue',roots:['fanvue']},{name:'dong',roots:['dong']},{name:'dingaling',roots:['dingaling']},{name:'balls',roots:['balls']},{name:'testicle',roots:['testicle']},{name:'scrotum',roots:['scrotum']},{name:'kys',roots:['kys']},{name:'ass',roots:['ass']},{name:'damn',roots:['damn']},{name:'hell',roots:['hell']},{name:'wtf',roots:['wtf']},{name:'wth',roots:['wth']},{name:'stfu',roots:['stfu']},{name:'omfg',roots:['omfg']},{name:'ffs',roots:['ffs']}];
function normalized(t){return String(t||'').toLowerCase().replace(/[^a-z0-9]+/g,'').replace(/0/g,'o').replace(/1/g,'i').replace(/3/g,'e').replace(/4/g,'a').replace(/5/g,'s').replace(/7/g,'t').replace(/8/g,'b').replace(/9/g,'g');}
function coreCanonicalTerm(t){
  const raw=String(t||'').trim();
  if(!raw)return raw;
  const knownBuiltIn=CORE_FILTERS.some(v=>String(v).toLowerCase()===raw.toLowerCase());
  if(!knownBuiltIn)return raw;
  const match=OG_GROUPS.find(g=>g.name.toLowerCase()===raw.toLowerCase() || g.roots.some(r=>normalized(raw).includes(normalized(r))));
  return match?.name||raw;
}
function asBool(value, fallback=false){
  if(value===true||value===1||value==='1'||value==='true'||value==='TRUE'||value==='t'||value==='T')return true;
  if(value===false||value===0||value==='0'||value==='false'||value==='FALSE'||value==='f'||value==='F')return false;
  return fallback;
}

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:'Admin access required'});
  if(req.method==='GET'){
    if(String(req.query?.view||'').toLowerCase()==='punishments'){
      const [{rows:filterRows},{rows:overrideRows},{rows:deletionRows},{rows:punishmentRowsFast},{rows:warningRulesFast}]=await Promise.all([
        db.query("SELECT term FROM chat_filters ORDER BY lower(term) ASC"),
        db.query("SELECT term,enabled,is_custom,parent_term FROM core_filter_overrides ORDER BY lower(term) ASC"),
        db.query("SELECT term FROM core_filter_deletions ORDER BY lower(term) ASC"),
        db.query("SELECT filter_term,punishment,reason,ban_duration_seconds,filter_dms,tag_matches FROM chat_filter_punishments ORDER BY lower(filter_term) ASC"),
        db.query("SELECT id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index,created_at,updated_at FROM warning_escalation_rules ORDER BY lower(filter_term) ASC,order_index ASC,created_at ASC,id ASC")
      ]);
      res.setHeader('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
      const punishmentByTerm=new Map();
      for(const row of punishmentRowsFast)punishmentByTerm.set(coreCanonicalTerm(row.filter_term).toLowerCase(),row);
      const deletedTerms=new Set(deletionRows.map(x=>String(x.term||'').trim().toLowerCase()).filter(Boolean));
      const terms=[...new Set([...OG_GROUPS.map(g=>g.name),...CORE_FILTERS,...overrideRows.filter(x=>x.is_custom===true).map(x=>String(x.term||'').trim()),...filterRows.map(x=>String(x.term||'').trim()).filter(Boolean)].map(coreCanonicalTerm).filter(Boolean))].filter(term=>!deletedTerms.has(String(term).toLowerCase()));
      const punishments=terms.map(term=>{const saved=punishmentByTerm.get(term.toLowerCase());const rawDuration=saved?.ban_duration_seconds;return {filter_term:term,punishment:String(saved?.punishment||'mask'),reason:String(saved?.reason||''),ban_duration_seconds:rawDuration===null||rawDuration===undefined||rawDuration===''?604800:Number(rawDuration),filter_dms:asBool(saved?.filter_dms,false),tag_matches:asBool(saved?.tag_matches,true)};});
      return res.json({punishments,warningRules:warningRulesFast.map(r=>({...r,filter_term:coreCanonicalTerm(r.filter_term)}))});
    }
    const {rows}=await db.query("SELECT id,term,enabled,created_at,updated_at FROM chat_filters ORDER BY lower(term) ASC");
    const {rows:overrides}=await db.query("SELECT term,enabled,is_custom,parent_term FROM core_filter_overrides ORDER BY lower(term) ASC");
    const {rows:punishmentRows}=await db.query("SELECT filter_term,punishment,reason,ban_duration_seconds,filter_dms,tag_matches FROM chat_filter_punishments ORDER BY lower(filter_term) ASC");
    const {rows:warningRules}=await db.query("SELECT id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index,created_at,updated_at FROM warning_escalation_rules ORDER BY lower(filter_term) ASC,order_index ASC,created_at ASC,id ASC");
    const {rows:moderationSettings}=await db.query("SELECT id,warnings_until_ban,escalation_reset_mode,updated_at FROM moderation_settings WHERE id=1 LIMIT 1");
    res.setHeader('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
    const byTerm=new Map(overrides.map(x=>[String(x.term).toLowerCase(),x]));
    const deletedTerms=new Set((await db.query("SELECT term FROM core_filter_deletions")).rows.map(x=>String(x.term||'').trim().toLowerCase()).filter(Boolean));
    const core=[...new Set(CORE_FILTERS)].map(term=>{const o=byTerm.get(term.toLowerCase());return {term,enabled:o?o.enabled!==false:true,is_custom:false,parent_term:o?.parent_term||null};}).filter(x=>x.enabled!==false&&!deletedTerms.has(String(x.term).toLowerCase())&&!deletedTerms.has(String(coreCanonicalTerm(x.term)).toLowerCase()));
    const added=overrides.filter(x=>x.is_custom&&x.enabled!==false&&!deletedTerms.has(String(x.term||'').trim().toLowerCase())).map(x=>({term:x.term,enabled:true,is_custom:true,parent_term:x.parent_term||null}));
    const allCore=[...core,...added];
    const groups=OG_GROUPS.filter(g=>{const rootOverride=byTerm.get(g.name.toLowerCase());return !deletedTerms.has(g.name.toLowerCase())&&!rootOverride||(!deletedTerms.has(g.name.toLowerCase())&&rootOverride.enabled!==false);}).map(g=>({name:g.name,variants:[g.name],parent_term:g.name,roots:g.roots}));
    for(const item of allCore){const n=normalized(item.term);let target=groups.find(g=>g.name.toLowerCase()===String(item.parent_term||'').toLowerCase());if(!target)target=groups.find(g=>g.roots.some(r=>n.includes(normalized(r))));if(target&&!target.variants.some(v=>String(v).toLowerCase()===String(item.term).toLowerCase()))target.variants.push(item.term);}
    const assigned=new Set(groups.flatMap(g=>g.variants.map(v=>String(v).toLowerCase())));
    const unmatched=allCore.filter(x=>!assigned.has(String(x.term).toLowerCase()));
    if(unmatched.length)groups.push({name:'Other',variants:unmatched.map(x=>x.term),parent_term:'Other'});
    const punishmentTerms=groups.map(g=>g.name).map(term=>{const saved=punishmentRows.find(x=>coreCanonicalTerm(x.filter_term).toLowerCase()===term.toLowerCase());const rawDuration=saved?.ban_duration_seconds;return {filter_term:term,punishment:String(saved?.punishment||'mask'),reason:String(saved?.reason||''),ban_duration_seconds:rawDuration===null||rawDuration===undefined||rawDuration===''?604800:Number(rawDuration),filter_dms:asBool(saved?.filter_dms,false),tag_matches:asBool(saved?.tag_matches,true)};}).concat(rows.map(x=>String(x.term||'').trim()).filter(Boolean).filter(term=>!CORE_FILTERS.some(v=>v.toLowerCase()===term.toLowerCase())).map(term=>{const saved=punishmentRows.find(x=>String(x.filter_term||'').toLowerCase()===term.toLowerCase());const rawDuration=saved?.ban_duration_seconds;return {filter_term:term,punishment:String(saved?.punishment||'mask'),reason:String(saved?.reason||''),ban_duration_seconds:rawDuration===null||rawDuration===undefined||rawDuration===''?604800:Number(rawDuration),filter_dms:asBool(saved?.filter_dms,false),tag_matches:asBool(saved?.tag_matches,true)};}));
    const canonicalWarningRules=warningRules.map(r=>({...r,filter_term:coreCanonicalTerm(r.filter_term),enabled:true}));
    const settings=moderationSettings[0]||{id:1,warnings_until_ban:3,escalation_reset_mode:'24h'};
    return res.json({filters:rows,builtIn:{name:'Core safety filter',editable:true,protected:true,terms:allCore,groups},punishments:punishmentTerms,warningRules:canonicalWarningRules,settings:{id:settings.id,warnings_until_ban:Number(settings.warnings_until_ban||3),escalation_reset_mode:String(settings.escalation_reset_mode||'24h')==='never'?'never':'24h',updated_at:settings.updated_at||null}});
  }
  const action=String(req.body?.action||'');
  if(action==='settings_update'){const value=Math.max(1,Math.min(1000,Number(req.body?.warnings_until_ban||3)));const {rows}=await db.query("INSERT INTO moderation_settings (id,warnings_until_ban,updated_at) VALUES (1,$1,NOW()) ON CONFLICT (id) DO UPDATE SET warnings_until_ban=$1,updated_at=NOW() RETURNING id,warnings_until_ban,updated_at",[value]);return res.json({settings:rows[0]});}
  if(action==='escalation_reset_mode_update'){const mode=String(req.body?.escalation_reset_mode||'24h').toLowerCase()==='never'?'never':'24h';const {rows}=await db.query("UPDATE moderation_settings SET escalation_reset_mode=$1,updated_at=NOW() WHERE id=1 RETURNING id,warnings_until_ban,escalation_reset_mode,updated_at",[mode]);if(!rows.length)return res.status(500).json({error:'Moderation settings row is missing.'});return res.json({settings:{...rows[0],warnings_until_ban:Number(rows[0].warnings_until_ban||3),escalation_reset_mode:rows[0].escalation_reset_mode==='never'?'never':'24h'}});}
  if(action==='reset_escalation_cycles'){const {rowCount}=await db.query("DELETE FROM user_filter_escalation_cycles");return res.json({ok:true,deleted:rowCount});}
  if(action==='reset_escalation_user' || action==='reset_user_escalation' || action==='reset_escalation_to_zero'){
    const targetUserId=String(req.body?.user_id||req.body?.identifier||'').trim();
    if(!targetUserId)return res.status(400).json({error:'User id is required.'});
    const {rowCount}=await db.query("DELETE FROM user_filter_escalation_cycles WHERE user_id=$1",[targetUserId]);
    return res.json({ok:true,reset_count:Number(rowCount||0),user_id:targetUserId});
  }
  if(action==='warning_rule_add'){
    const filterTerm=coreCanonicalTerm(String(req.body?.filter_term||'').trim().slice(0,100));const warningCount=Math.floor(Number(req.body?.warning_count));const ruleAction=String(req.body?.action||'warn').toLowerCase();const reason=String(req.body?.reason||'').trim().slice(0,500);const banDuration=Math.floor(Number(req.body?.ban_duration_seconds??604800));
    if(!['warn','delete','ip_ban','ban'].includes(ruleAction))return res.status(400).json({error:'Invalid escalation action. Use Warn, Delete message, IP Ban, or Ban.'});
    if(filterTerm.length<2)return res.status(400).json({error:'Filter word is required.'});
    if(!Number.isFinite(warningCount)||warningCount<1||warningCount>1000)return res.status(400).json({error:'Invalid warning count.'});
    if(!Number.isFinite(banDuration)||banDuration<0||banDuration>315360000)return res.status(400).json({error:'Invalid escalation ban duration.'});
    const {rows}=await db.query("INSERT INTO warning_escalation_rules (filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index) VALUES ($1,$2,$3,$4,true,$5,COALESCE((SELECT MAX(order_index)+1 FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)),1)) RETURNING id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index",[filterTerm,warningCount,ruleAction,reason,banDuration]);
    return res.json({rule:{...rows[0],enabled:true}});
  }
  if(action==='warning_rule_update'){
    const id=String(req.body?.id||'').trim();const filterTerm=coreCanonicalTerm(String(req.body?.filter_term||'').trim().slice(0,100));const warningCount=Math.floor(Number(req.body?.warning_count));const ruleAction=String(req.body?.action||'warn').toLowerCase();const reason=String(req.body?.reason||'').trim().slice(0,500);const banDuration=Math.floor(Number(req.body?.ban_duration_seconds??604800));
    if(!id)return res.status(400).json({error:'Rule id required.'});
    if(!['warn','delete','ip_ban','ban'].includes(ruleAction))return res.status(400).json({error:'Invalid escalation action. Use Warn, Delete, IP Ban, or Ban.'});
    if(filterTerm.length<2)return res.status(400).json({error:'Filter word is required.'});
    if(!Number.isFinite(banDuration))return res.status(400).json({error:'Invalid escalation ban duration.'});
    const {rows}=await db.query("UPDATE warning_escalation_rules SET filter_term=$2,warning_count=$3,action=$4,reason=$5,enabled=true,ban_duration_seconds=$6,updated_at=NOW() WHERE id=$1 RETURNING id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds",[id,filterTerm,warningCount,ruleAction,reason,banDuration]);
    if(!rows.length)return res.status(404).json({error:'Rule not found.'});
    return res.json({rule:{...rows[0],enabled:true}});
  }
  if(action==='warning_rule_delete'){const id=String(req.body?.id||'').trim();if(!id)return res.status(400).json({error:'Rule id required.'});await db.query("DELETE FROM warning_escalation_rules WHERE id=$1",[id]);return res.json({ok:true});}
  if(action==='create'){const term=String(req.body?.term||'').trim().slice(0,100);if(term.length<2)return res.status(400).json({error:'Filter term must be at least 2 characters.'});const {rows}=await db.query("INSERT INTO chat_filters (term) VALUES ($1) ON CONFLICT (term) DO UPDATE SET enabled=true,updated_at=now() RETURNING id,term,enabled,created_at,updated_at",[term]);await db.query("INSERT INTO chat_filter_punishments (filter_term,punishment,ban_duration_seconds,filter_dms,tag_matches) VALUES ($1,'mask',604800,$2,$3) ON CONFLICT (filter_term) DO NOTHING",[term,asBool(req.body?.filter_dms,false),asBool(req.body?.tag_matches,true)]);return res.status(201).json({filter:rows[0]});}
  if(action==='manage_save'){
    const filterTermInput=String(req.body?.filter_term||'').trim().slice(0,100);const filterTerm=coreCanonicalTerm(filterTermInput);const punishment=String(req.body?.punishment||'mask').trim().toLowerCase();const punishmentReason=String(req.body?.reason||'').trim().slice(0,500);const durationRaw=req.body?.ban_duration_seconds;const banDuration=durationRaw===null||durationRaw===undefined||durationRaw===''?604800:Math.floor(Number(durationRaw));const filterDms=asBool(req.body?.filter_dms,false);const tagMatches=asBool(req.body?.tag_matches,true);const rules=Array.isArray(req.body?.rules)?req.body.rules:[];
    if(rules.length>50)return res.status(400).json({error:'A filter can have a maximum of 50 warning escalation rules.'});if(filterTerm.length<2)return res.status(400).json({error:'Filter term is required.'});if(!['mask','warn','delete','ip_ban','ban'].includes(punishment))return res.status(400).json({error:'Invalid punishment.'});if(!Number.isFinite(banDuration)||banDuration<0||banDuration>315360000)return res.status(400).json({error:'Invalid punishment ban duration.'});
    const normalizedRules=rules.map(r=>{const actionValue=String(r?.action||r?.rule_action||'warn').toLowerCase();return {id:String(r?.id||'').trim(),warning_count:Math.max(1,Math.min(1000,Number(r?.warning_count||1))),action:actionValue,reason:String(r?.reason||'').trim().slice(0,500),enabled:true,ban_duration_seconds:['ban','ip_ban'].includes(actionValue)?Math.max(0,Math.min(315360000,Math.floor(Number(r?.ban_duration_seconds??604800)))):0};});
    for(let i=0;i<normalizedRules.length;i++){const r=normalizedRules[i];if(!['warn','ban','delete','ip_ban'].includes(r.action)||!Number.isFinite(r.ban_duration_seconds))return res.status(400).json({error:`Invalid escalation rule at row ${i+1}: action must be Warn, Delete, IP Ban, or Ban.`});if(r.warning_count<1)return res.status(400).json({error:'Warning count must be at least 1.'});}
    const isBuiltInTerm=CORE_FILTERS.some(x=>x.toLowerCase()===filterTerm.toLowerCase());
    const tx=[...(!isBuiltInTerm?[{sql:"INSERT INTO chat_filters (term,enabled) VALUES ($1,true) ON CONFLICT (term) DO UPDATE SET enabled=true,updated_at=NOW() RETURNING id,term,enabled",params:[filterTerm]}]:[]),{sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[filterTerm]},{sql:"INSERT INTO chat_filter_punishments (filter_term,punishment,reason,ban_duration_seconds,filter_dms,tag_matches) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (filter_term) DO UPDATE SET punishment=$2,reason=$3,ban_duration_seconds=$4,filter_dms=$5,tag_matches=$6,updated_at=NOW() RETURNING filter_term,punishment,reason,ban_duration_seconds,filter_dms,tag_matches",params:[filterTerm,punishment,punishmentReason,banDuration,filterDms,tagMatches]},...normalizedRules.map((r,i)=>({sql:"INSERT INTO warning_escalation_rules (filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index) VALUES ($1,$2,$3,$4,true,$5,$6) RETURNING id,filter_term,warning_count,action,reason,enabled,ban_duration_seconds,order_index",params:[filterTerm,r.warning_count,r.action,r.reason,r.ban_duration_seconds,i+1]}))];
    try{const result=await db.transaction(tx);const punishmentResultIndex=isBuiltInTerm?1:2;const savedPunishment=result.results[punishmentResultIndex]?.rows?.[0];const savedRules=result.results.slice(punishmentResultIndex+1).map(x=>x.rows?.[0]).filter(Boolean).map(x=>({...x,enabled:true}));if(!savedPunishment)return res.status(409).json({error:'The filter settings transaction completed without returning its saved punishment settings. Nothing was closed so you can retry.',code:'PUNISHMENT_SETTINGS_NOT_RETURNED',filter_term:filterTerm});if(savedRules.length!==normalizedRules.length)return res.status(409).json({error:'One or more escalation rules could not be saved for this filter.',code:'ESCALATION_RULE_NOT_SAVED',filter_term:filterTerm,requested_rules:normalizedRules.length,saved_rules:savedRules.length,failed_rule:null});const {rows:readbackRows}=await db.query("SELECT filter_term,punishment,reason,ban_duration_seconds,filter_dms,tag_matches FROM chat_filter_punishments WHERE lower(filter_term)=lower($1) LIMIT 1",[filterTerm]);const readback=readbackRows[0];if(!readback||readback.filter_dms!==filterDms||readback.tag_matches!==tagMatches){console.error('manage_save punishment settings readback mismatch',{filterTerm,requested:{filter_dms:filterDms,tag_matches:tagMatches},readback:readback||null});return res.status(409).json({error:'The filter was saved, but its DM/tag settings failed the server readback check. Nothing was closed so you can retry.',code:'PUNISHMENT_SETTINGS_NOT_VERIFIED',filter_term:filterTerm});}return res.json({ok:true,punishment:readback,rules:savedRules,settings_verified:true});}catch(err){console.error('manage_save transaction failed',{filterTerm,error:String(err?.message||err)});return res.status(500).json({error:`Could not save filter settings: ${String(err?.message||err)}`,code:'MANAGE_SAVE_TRANSACTION_FAILED',filter_term:filterTerm});}
  }
  if(action==='punishment_update'){
    const filterTerm=String(req.body?.filter_term||'').trim().slice(0,100);const punishment=String(req.body?.punishment||'mask').trim().toLowerCase();const durationRaw=req.body?.ban_duration_seconds;const banDuration=durationRaw===null||durationRaw===undefined||durationRaw===''?604800:Math.floor(Number(durationRaw));const filterDms=asBool(req.body?.filter_dms,false);const tagMatches=asBool(req.body?.tag_matches,true);if(filterTerm.length<2)return res.status(400).json({error:'Filter term is required.'});if(!['mask','warn','delete','ip_ban','ban'].includes(punishment))return res.status(400).json({error:'Invalid punishment.'});if(!Number.isFinite(banDuration)||banDuration<0||banDuration>315360000)return res.status(400).json({error:'Invalid ban duration.'});const {rows}=await db.query("INSERT INTO chat_filter_punishments (filter_term,punishment,ban_duration_seconds,filter_dms,tag_matches) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (filter_term) DO UPDATE SET punishment=$2,ban_duration_seconds=$3,filter_dms=$4,tag_matches=$5,updated_at=NOW() RETURNING filter_term,punishment,ban_duration_seconds,filter_dms,tag_matches",[filterTerm,punishment,banDuration,filterDms,tagMatches]);return res.json({punishment:{...rows[0],filter_dms:asBool(rows[0]?.filter_dms,filterDms),tag_matches:asBool(rows[0]?.tag_matches,tagMatches)}});
  }
  if(action==='core_delete_main'){
    const termInput=String(req.body?.term||'').trim().slice(0,100);
    const mainGroup=OG_GROUPS.find(g=>g.name.toLowerCase()===termInput.toLowerCase()||normalized(g.name)===normalized(termInput));
    if(!mainGroup)return res.status(404).json({error:'Main Core filter not found.'});
    const groupTerms=[...new Set(CORE_FILTERS.filter(v=>mainGroup.roots.some(r=>normalized(v).includes(normalized(r)))))];
    const customVariants=(await db.query("SELECT term FROM core_filter_overrides WHERE is_custom=true AND lower(COALESCE(parent_term,''))=lower($1)",[mainGroup.name])).rows.map(x=>String(x.term||'').trim()).filter(Boolean);
    const allTerms=[mainGroup.name,...groupTerms,...customVariants];
    const keys=[...new Set(allTerms.map(x=>String(x).toLowerCase()).filter(Boolean))];
    await db.transaction([
      {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
      {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
      {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
      {sql:"DELETE FROM core_filter_overrides WHERE lower(term)=ANY($1::text[]) OR (is_custom=true AND lower(COALESCE(parent_term,''))=lower($2))",params:[keys,mainGroup.name]},
      {sql:"INSERT INTO core_filter_deletions (term) VALUES ($1) ON CONFLICT (term) DO UPDATE SET deleted_at=NOW()",params:[mainGroup.name.toLowerCase()]}
    ]);
    return res.json({ok:true,deleted:mainGroup.name,deleted_subfilters:[...groupTerms,...customVariants]});
  }
  if(action==='core_delete_subfilter'){
    const termInput=String(req.body?.term||'').trim().slice(0,100);
    if(termInput.length<2)return res.status(400).json({error:'Core subfilter term required.'});
    if(OG_GROUPS.some(g=>g.name.toLowerCase()===termInput.toLowerCase()||normalized(g.name)===normalized(termInput)))return res.status(400).json({error:'Use Delete Main Filter to remove a main filter and all of its subfilters.'});
    const existingRows=(await db.query("SELECT term,is_custom,parent_term FROM core_filter_overrides ORDER BY lower(term)")).rows;
    const existingRow=existingRows.find(x=>String(x.term||'').toLowerCase()===termInput.toLowerCase()||normalized(x.term)===normalized(termInput));
    const builtIn=CORE_FILTERS.find(x=>x.toLowerCase()===termInput.toLowerCase()||normalized(x)===normalized(termInput));
    if(builtIn){
      const actual=String(builtIn);
      await db.transaction([
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM core_filter_overrides WHERE lower(term)=lower($1)",params:[actual]},
        {sql:"INSERT INTO core_filter_deletions (term) VALUES ($1) ON CONFLICT (term) DO UPDATE SET deleted_at=NOW()",params:[actual.toLowerCase()]}
      ]);
      return res.json({ok:true,deleted:actual});
    }
    if(existingRow?.is_custom){
      const actual=String(existingRow.term||termInput).trim();
      await db.transaction([
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[actual]},
        {sql:"DELETE FROM core_filter_overrides WHERE lower(term)=lower($1) AND is_custom=true",params:[actual]}
      ]);
      return res.json({ok:true,deleted:actual});
    }
    return res.status(404).json({error:'Core subfilter not found.'});
  }
  if(action==='core_delete'){
    const termInput=String(req.body?.term||'').trim().slice(0,100);
    if(termInput.length<2)return res.status(400).json({error:'Core filter term required.'});
    if(termInput.toLowerCase()==='other'){
      const overridesNow=await db.query("SELECT term,parent_term FROM core_filter_overrides WHERE is_custom=true AND enabled=true ORDER BY lower(term)");
      const actualGroups=new Set(OG_GROUPS.map(g=>g.name.toLowerCase()));
      const otherTerms=overridesNow.rows.filter(x=>{const parent=String(x.parent_term||'').trim().toLowerCase();if(parent&&actualGroups.has(parent))return false;const n=normalized(x.term);return !OG_GROUPS.some(g=>g.roots.some(r=>n.includes(normalized(r))));}).map(x=>String(x.term||'').trim()).filter(Boolean);
      if(!otherTerms.length)return res.status(404).json({error:'There are no ungrouped Core Safety filters to delete.'});
      const keys=otherTerms.map(x=>x.toLowerCase());
      await db.transaction([
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=ANY($1::text[])",params:[keys]},
        {sql:"DELETE FROM core_filter_overrides WHERE is_custom=true AND lower(term)=ANY($1::text[])",params:[keys]}
      ]);
      return res.json({ok:true,deleted:'Other',deleted_terms:otherTerms});
    }
    const mainGroup=OG_GROUPS.find(g=>g.name.toLowerCase()===termInput.toLowerCase()||normalized(g.name)===normalized(termInput));
    if(mainGroup){
      const groupTerms=CORE_FILTERS.filter(v=>mainGroup.roots.some(r=>normalized(v).includes(normalized(r))));
      const customVariants=await db.query("SELECT term FROM core_filter_overrides WHERE is_custom=true AND enabled=true AND lower(COALESCE(parent_term,''))=lower($1)",[mainGroup.name]);
      const cleanupTerms=[...new Set([mainGroup.name,...groupTerms,...customVariants.rows.map(x=>String(x.term||''))].filter(Boolean))];
      const groupKeys=[...new Set([mainGroup.name,...groupTerms].map(x=>String(x||'').trim().toLowerCase()).filter(Boolean))];
      const customKeys=customVariants.rows.map(x=>String(x.term||'').trim().toLowerCase()).filter(Boolean);
      const tx=[
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=ANY($1::text[])",params:[groupKeys]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=ANY($1::text[])",params:[groupKeys]},
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=ANY($1::text[])",params:[groupKeys]},
        ...(customKeys.length?[{sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=ANY($1::text[])",params:[customKeys]},{sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=ANY($1::text[])",params:[customKeys]},{sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=ANY($1::text[])",params:[customKeys]}]:[]),
        ...customVariants.rows.map(x=>({sql:"DELETE FROM core_filter_overrides WHERE lower(term)=lower($1) AND is_custom=true",params:[String(x.term||'')]})),
        ...groupTerms.map(x=>({sql:"INSERT INTO core_filter_overrides (term,enabled,is_custom) VALUES ($1,false,false) ON CONFLICT (term) DO UPDATE SET enabled=false,is_custom=false,updated_at=NOW()",params:[x]})),
        {sql:"INSERT INTO core_filter_overrides (term,enabled,is_custom,parent_term) VALUES ($1,false,false,$1) ON CONFLICT (term) DO UPDATE SET enabled=false,is_custom=false,parent_term=$1,updated_at=NOW()",params:[mainGroup.name]}
      ];
      await db.transaction(tx);
      return res.json({ok:true,deleted:mainGroup.name,deleted_terms:cleanupTerms});
    }
    const existing=await db.query("SELECT term,is_custom FROM core_filter_overrides ORDER BY lower(term)");
    const existingRow=existing.rows.find(x=>String(x.term||'').toLowerCase()===termInput.toLowerCase()||normalized(x.term)===normalized(termInput));
    const isBuiltIn=CORE_FILTERS.some(x=>x.toLowerCase()===termInput.toLowerCase()||normalized(x)===normalized(termInput));
    if(isBuiltIn){
      await db.transaction([
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"INSERT INTO core_filter_overrides (term,enabled,is_custom) VALUES ($1,false,false) ON CONFLICT (term) DO UPDATE SET enabled=false,is_custom=false,updated_at=NOW()",params:[termInput]}
      ]);
      return res.json({ok:true,deleted:termInput});
    }
    if(existingRow?.is_custom){
      await db.transaction([
        {sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[termInput]},
        {sql:"DELETE FROM core_filter_overrides WHERE lower(term)=lower($1) AND is_custom=true",params:[termInput]}
      ]);
      return res.json({ok:true,deleted:termInput});
    }
    return res.status(404).json({error:'Core filter not found.'});
  }
  if(action==='core_rename'){const oldTerm=String(req.body?.oldTerm||'').trim().slice(0,100);const newTerm=String(req.body?.newTerm||'').trim().slice(0,100);if(oldTerm.length<2||newTerm.length<2)return res.status(400).json({error:'Both core filter terms are required.'});if(oldTerm.toLowerCase()===newTerm.toLowerCase())return res.json({ok:true});await db.query("INSERT INTO core_filter_overrides (term,enabled,is_custom) VALUES ($1,false,false) ON CONFLICT (term) DO UPDATE SET enabled=false,is_custom=false,updated_at=now()",[oldTerm]);await db.query("UPDATE chat_filter_punishments SET filter_term=$2,updated_at=NOW() WHERE lower(filter_term)=lower($1) AND NOT EXISTS (SELECT 1 FROM chat_filter_punishments p2 WHERE lower(p2.filter_term)=lower($2))",[oldTerm,newTerm]);await db.query("UPDATE warning_escalation_rules SET filter_term=$2,updated_at=NOW() WHERE lower(filter_term)=lower($1)",[oldTerm,newTerm]);const {rows}=await db.query("INSERT INTO core_filter_overrides (term,enabled,is_custom) VALUES ($1,true,true) ON CONFLICT (term) DO UPDATE SET enabled=true,is_custom=true,updated_at=now() RETURNING term,enabled,is_custom",[newTerm]);return res.json({filter:rows[0]});}
  if(action==='core_add'){const term=String(req.body?.term||'').trim().slice(0,100);if(term.length<2)return res.status(400).json({error:'Core filter term must be at least 2 characters.'});const {rows}=await db.query("INSERT INTO core_filter_overrides (term,enabled,is_custom,parent_term) VALUES ($1,true,true,$1) ON CONFLICT (term) DO UPDATE SET enabled=true,is_custom=true,parent_term=COALESCE(core_filter_overrides.parent_term,EXCLUDED.parent_term),updated_at=now() RETURNING term,enabled,is_custom,parent_term",[term]);await db.query("INSERT INTO chat_filter_punishments (filter_term,punishment,ban_duration_seconds,filter_dms,tag_matches) VALUES ($1,'mask',604800,false,true) ON CONFLICT (filter_term) DO NOTHING",[term]);return res.status(201).json({filter:rows[0]});}
  if(action==='core_variant_add'){const parentTerm=String(req.body?.parentTerm||'').trim().slice(0,100);const variant=String(req.body?.variant||'').trim().slice(0,100);if(parentTerm.length<2||variant.length<2)return res.status(400).json({error:'Main filter and variant are required.'});const existing=await db.query("SELECT 1 FROM core_filter_overrides WHERE lower(term)=lower($1) LIMIT 1",[variant]);if(existing.rows.length)return res.status(409).json({error:'Variant already exists.'});const {rows}=await db.query("INSERT INTO core_filter_overrides (term,enabled,is_custom,parent_term) VALUES ($1,true,true,$2) RETURNING term,enabled,is_custom,parent_term",[variant,parentTerm]);return res.status(201).json({filter:rows[0]});}
  // Core deletion is handled above; this legacy disable handler is intentionally removed.
  if(action==='core_remove_custom'){const term=String(req.body?.term||'').trim().slice(0,100);if(term.length<2)return res.status(400).json({error:'Core filter term is required.'});const existing=await db.query("SELECT 1 FROM core_filter_overrides WHERE lower(term)=lower($1) AND is_custom=true LIMIT 1",[term]);if(!existing.rows.length)return res.status(404).json({error:'Custom core filter not found.'});await db.transaction([{sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM core_filter_overrides WHERE lower(term)=lower($1) AND is_custom=true",params:[term]}]);return res.json({ok:true});}
  if(action==='delete'){const id=String(req.body?.id||'').trim();if(!id)return res.status(400).json({error:'Filter id is required.'});const existing=await db.query("SELECT id,term FROM chat_filters WHERE id=$1 LIMIT 1",[id]);if(!existing.rows.length)return res.status(404).json({error:'Custom filter not found.'});const term=String(existing.rows[0].term||'').trim();if(CORE_FILTERS.some(x=>x.toLowerCase()===term.toLowerCase()))return res.status(400).json({error:'Built-in Core Safety filters cannot be deleted.'});await db.transaction([{sql:"DELETE FROM user_filter_escalation_cycles WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM warning_escalation_rules WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM chat_filter_punishments WHERE lower(filter_term)=lower($1)",params:[term]},{sql:"DELETE FROM chat_filters WHERE id=$1",params:[id]}]);return res.json({ok:true,deleted:term});}
  return res.status(400).json({error:'Unknown action.'});
}