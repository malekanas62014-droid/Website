import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET","POST"];

const clean=(value,max)=>String(value??'').trim().slice(0,max);
const validVersion=value=>/^\d+(?:\.\d+)*$/.test(String(value||'').trim());
const validKinds=new Set(['Feature','Improvement','Fix','Security','Maintenance','Update']);

export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:'Admin access required'});
  if(req.method==='GET'){
    const {rows}=await db.query('SELECT id,version,title,summary AS subtitle,kind,created_at FROM update_logs ORDER BY created_at DESC,id DESC');
    return res.json({logs:rows});
  }
  const b=req.body||{};
  const action=String(b.action||'');
  if(action==='create'||action==='update'){
    let version=clean(b.version,32),title=clean(b.title,120),subtitle=clean(b.subtitle,500),kind=clean(b.kind,30)||'Update';
    if(action==='create'&&!version){
      const {rows:latestRows}=await db.query('SELECT version FROM update_logs ORDER BY created_at DESC,id DESC LIMIT 1');
      const latest=String(latestRows[0]?.version||'1').trim();
      version=(()=>{if(!/^\d+(?:\.\d+)?$/.test(latest))return '1.1';const [majorRaw,minorRaw]=latest.includes('.')?latest.split('.'):[latest,'0'];let major=Number(majorRaw),minor=Number(minorRaw);if(!Number.isInteger(major)||!Number.isInteger(minor))return '1.1';minor+=1;if(minor>=10){major+=Math.floor(minor/10);minor%=10;}return major+'.'+minor;})();
    }
    if(!validVersion(version))return res.status(400).json({error:'Version must look like 1, 1.1, or 1.1.1.'});
    if(!title)return res.status(400).json({error:'Title is required.'});
    if(!subtitle)return res.status(400).json({error:'Subtitle is required.'});
    if(!validKinds.has(kind))return res.status(400).json({error:'Invalid update type.'});
    if(action==='create'){
      try{
        const {rows}=await db.query('INSERT INTO update_logs (version,title,summary,kind) VALUES ($1,$2,$3,$4) RETURNING id,version,title,summary AS subtitle,kind,created_at',[version,title,subtitle,kind]);
        return res.json({ok:true,log:rows[0]});
      }catch(e){
        if(String(e?.message||'').toLowerCase().includes('unique'))return res.status(409).json({error:'That version already exists. Choose another version.'});
        throw e;
      }
    }
    const id=Number(b.id);
    if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid update id.'});
    try{
      const {rows}=await db.query('UPDATE update_logs SET version=$2,title=$3,summary=$4,kind=$5 WHERE id=$1 RETURNING id,version,title,summary AS subtitle,kind,created_at',[id,version,title,subtitle,kind]);
      if(!rows.length)return res.status(404).json({error:'Update not found.'});
      return res.json({ok:true,log:rows[0]});
    }catch(e){
      if(String(e?.message||'').toLowerCase().includes('unique'))return res.status(409).json({error:'That version already exists. Choose another version.'});
      throw e;
    }
  }
  if(action==='delete'){
    const id=Number(b.id);
    if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid update id.'});
    const result=await db.query('DELETE FROM update_logs WHERE id=$1',[id]);
    if(!result.rowCount)return res.status(404).json({error:'Update not found.'});
    return res.json({ok:true});
  }
  if(action==='auto_deploy'){
    if(b.user_visible!==true)return res.json({ok:true,skipped:true,reason:'Internal deploys are not added to member Update Logs.'});
    const title=clean(b.title,120),subtitle=clean(b.subtitle,500),kind=clean(b.kind,30)||'Update';
    if(!title||!subtitle)return res.status(400).json({error:'Title and subtitle are required.'});
    if(!validKinds.has(kind))return res.status(400).json({error:'Invalid update type.'});
    const {rows:latestRows}=await db.query('SELECT version FROM update_logs ORDER BY created_at DESC,id DESC LIMIT 1');
    const latest=String(latestRows[0]?.version||'1').trim();
    const version=(()=>{if(!/^\d+(?:\.\d+)?$/.test(latest))return '1.1';const [majorRaw,minorRaw]=latest.includes('.')?latest.split('.'):[latest,'0'];let major=Number(majorRaw),minor=Number(minorRaw);if(!Number.isInteger(major)||!Number.isInteger(minor))return '1.1';minor+=1;if(minor>=10){major+=Math.floor(minor/10);minor%=10;}return major+'.'+minor;})();
    const {rows}=await db.query('INSERT INTO update_logs (version,title,summary,kind) VALUES ($1,$2,$3,$4) RETURNING id,version,title,summary AS subtitle,kind,created_at',[version,title,subtitle,kind]);
    return res.json({ok:true,log:rows[0]});
  }
  return res.status(400).json({error:'Unknown action.'});
}