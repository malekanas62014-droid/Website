import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access="user";
export const methods=["GET"];
export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
  const identifier=String(req.query?.identifier||'').trim();
  if(!identifier)return res.status(400).json({error:'Missing user identifier'});
  const {rows}=await db.query("SELECT u.id,COALESCE(li.last_ip,'') AS last_ip FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_last_ips li ON li.user_id=u.id WHERE lower(u.email)=lower($1) OR lower(COALESCE(p.username,u.name,''))=lower($1) OR lower(u.id)=lower($1) LIMIT 1",[identifier]);
  if(!rows.length)return res.status(404).json({error:'User not found'});
  const u=rows[0];
  const account=await db.query("SELECT 1 FROM banned_users WHERE user_id=$1 AND ban_type<>'ACD' AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[u.id]);
  const ip=u.last_ip?await db.query("SELECT 1 FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[u.last_ip]):{rows:[]};
  return res.json({banned:Boolean(account.rows.length||ip.rows.length),account_banned:Boolean(account.rows.length),ip_banned:Boolean(ip.rows.length)});
}