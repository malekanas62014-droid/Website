import { db } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
export const access = "user";
export const methods = ["GET"];
export default async function (req, res) {
  if (!(await assertAdmin(req))) return res.status(403).json({ error: "Admin access required" });
  const { rows } = await db.query("SELECT id, name, category, premium, bytes, created_at FROM managed_assets ORDER BY created_at DESC");
  res.json(rows);
}