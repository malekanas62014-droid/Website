import { db, storage } from "hatchable";
import { assertAdmin } from "lib/admin-auth";
import { notifyAdminsOfModeration } from "lib/admin-moderation-notify";
export const access="user";
export const methods=["POST"];
export default async function(req,res){
  if(!(await assertAdmin(req)))return res.status(403).json({error:"Admin access required"});
  const {action,identifier,amount,reason,duration,banType}=req.body||{};
  if(action==='add_coins'||action==='remove_coins'){
    const rawAmount=Number(amount);
    if(!Number.isFinite(rawAmount)||!Number.isSafeInteger(Math.floor(rawAmount))||rawAmount<=0)return res.status(400).json({error:'Enter a whole number greater than 0.'});
    if(Math.floor(rawAmount)>2147483647)return res.status(400).json({error:'Coin amount is too large. Maximum is 2,147,483,647.'});
  }
  if(action==='ban' && String(banType||'BAN').toUpperCase()!=='ACD' && !['IB','IP'].includes(String(banType||'BAN').toUpperCase())){
    const rawDuration=Number(duration);
    if(!Number.isFinite(rawDuration)||rawDuration<0)return res.status(400).json({error:'Invalid ban duration.'});
    if(rawDuration>315360000)return res.status(400).json({error:'Ban duration is too long. Maximum is 10 years.'});
  }
  const offensiveItem=String(req.body?.offensiveItem||'').trim().slice(0,500);
  const attachment=req.files?.[0];
  let attachmentKey='',attachmentName='',attachmentType='';
  if(attachment?.buffer){
    attachmentName=String(attachment.filename||'moderation-evidence').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,180);
    attachmentType=String(attachment.contentType||'application/octet-stream').slice(0,160);
    attachmentKey=`moderation/${crypto.randomUUID()}-${attachmentName}`;
    await storage.put(attachmentKey,attachment.buffer,attachmentType);
  }
  if(!action||!identifier)return res.status(400).json({error:'Missing action or user identifier'});
  const {rows}=await db.query("SELECT u.id,u.email,COALESCE(li.last_ip,'') AS last_ip,COALESCE(p.username,u.name,'') AS username,COALESCE(u.hatchable_user_id,u.id) AS scope_id FROM users u LEFT JOIN profile_usernames p ON p.user_id=u.id LEFT JOIN user_last_ips li ON li.user_id=u.id WHERE lower(u.email)=lower($1) OR lower(COALESCE(p.username,u.name,''))=lower($1) OR lower(u.id)=lower($1) LIMIT 1",[String(identifier).trim()]);
  if(!rows.length)return res.status(404).json({error:'User not found'});
  const u=rows[0];
  const {rows:deleted}=await db.query("SELECT 1 FROM deleted_accounts WHERE lower(email)=lower($1) LIMIT 1",[String(u.email||'')]);
  if(deleted.length)return res.status(403).json({error:'Deleted accounts are view-only and cannot be modified.'});
  if(action==='toggle_verified'){
    const enabled=req.body?.enabled===true||String(req.body?.enabled)==='true';
    await db.query("INSERT INTO user_profiles (user_id,is_verified,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET is_verified=EXCLUDED.is_verified,updated_at=NOW()",[String(u.id),enabled]);
    return res.json({ok:true,is_verified:enabled});
  }
  if(action==='toggle_admin'){
    const current=String(req.body?.enabled)==='true'||req.body?.enabled===true;
    const owner=String(u.email||'').trim().toLowerCase()==='robloxassetsowner@protonmail.com';
    if(owner)return res.status(400).json({error:'The owner is always an admin.'});
    const accountId=String(u.id);
    let changedRows=0;
    if(!current){
      const removed=await db.query("DELETE FROM admin_user_directory WHERE user_id=$1 OR lower(email)=lower($2)",[accountId,u.email]);
      changedRows=Number(removed.rowCount||0);
    }else{
      await db.query("DELETE FROM admin_user_directory WHERE user_id=$1 OR lower(email)=lower($2)",[accountId,u.email]);
      const inserted=await db.query("INSERT INTO admin_user_directory (user_id,email,username,is_admin) VALUES ($1,$2,$3,true)",[accountId,u.email,u.username]);
      changedRows=Number(inserted.rowCount||0);
    }
    return res.json({ok:true,is_admin:current,updated_rows:changedRows});
  }
  if(action==='disable_account'){
    const r=String(reason||'Disabled by an administrator.').trim().slice(0,500);
    await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,'BAN',$4,$5,$6,$7,$8)",[String(u.id),u.email,u.username,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
    await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,'BAN',$5,$6,$7) ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL,ban_type='BAN',attachment_key=EXCLUDED.attachment_key,attachment_name=EXCLUDED.attachment_name,attachment_type=EXCLUDED.attachment_type",[u.id,u.email,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
    try{await notifyAdminsOfModeration('ban',u.username,r);}catch(_){ }
    return res.json({ok:true,banned:true});
  }
  if(action==='enable_account'){
    await db.query("DELETE FROM banned_users WHERE user_id=$1 AND ban_type<>'ACD'",[u.id]);
    return res.json({ok:true,banned:false});
  }
  if(action==='ban'){
    const existingAccountBan=await db.query("SELECT 1 FROM banned_users WHERE user_id=$1 AND ban_type<>'ACD' AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[u.id]);
    const existingIpBan=u.last_ip?await db.query("SELECT 1 FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[String(u.last_ip).trim()]):{rows:[]};
    if(existingAccountBan.rows.length||existingIpBan.rows.length)return res.status(409).json({error:'User is already banned.'});
    const r=String(reason||'No reason provided').trim().slice(0,500);
    let type=String(banType||'BAN').toUpperCase();
    if(type==='W'||type==='WARN'){
      await db.query("INSERT INTO user_warnings (user_id,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,$5,$6)",[String(u.id),r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,'W',$4,$5,$6,$7,$8)",[String(u.id),u.email,u.username,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
      try{await notifyAdminsOfModeration('warn',u.username,r);}catch(_){ }
      return res.json({ok:true,warning:true});
    }
    if(type==='AD')type='ACD';
    if(type==='IB'||type==='IP'){
      const targetIp=String(u.last_ip||'').trim();
      if(!targetIp)return res.status(400).json({error:'This user has no recorded IP yet. Have the user visit the site once and try again.'});
      const existingIp=await db.query("SELECT 1 FROM ip_bans WHERE ip=$1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[targetIp]);
      const existingAccount=await db.query("SELECT 1 FROM banned_users WHERE user_id=$1 AND ban_type<>'ACD' AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1",[u.id]);
      if(existingIp.rows.length||existingAccount.rows.length)return res.status(409).json({error:'User is already banned.'});
      await db.query("INSERT INTO ip_bans (ip,reason,offensive_item,expires_at,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,NULL,$4,$5,$6)",[targetIp,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,'IB',$4,$5,$6,$7,$8)",[String(u.id),u.email,u.username,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
    }else{
      const rawSeconds=type==='ACD'?0:Number(duration);
      const seconds=type==='ACD'?0:(Number.isFinite(rawSeconds)?Math.max(0,Math.min(315360000,Math.floor(rawSeconds))):0);
      const expires=seconds?new Date(Date.now()+seconds*1000).toISOString():null;
      const historyType=type==='ACD'?'AD':'BAN';
      await db.query("INSERT INTO ban_history (user_id,email,username,ban_type,reason,offensive_item,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",[String(u.id),u.email,u.username,historyType,r,offensiveItem,attachmentKey||null,attachmentName||null,attachmentType||null]);
      if(type==='ACD'){
        await db.query("INSERT INTO deleted_accounts (user_id,email,username,offensive_item) VALUES ($1,$2,$3,$4) ON CONFLICT (email) DO UPDATE SET user_id=EXCLUDED.user_id,username=EXCLUDED.username,offensive_item=EXCLUDED.offensive_item",[String(u.id),String(u.email||'').toLowerCase(),u.username,offensiveItem]);
        await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,NULL,'ACD',$5,$6,$7) ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=NULL,ban_type='ACD',attachment_key=EXCLUDED.attachment_key,attachment_name=EXCLUDED.attachment_name,attachment_type=EXCLUDED.attachment_type",[u.id,u.email,r,offensiveItem]);
        await db.query("INSERT INTO profile_usernames (user_id,username) VALUES ($1,'Account deleted') ON CONFLICT (user_id) DO UPDATE SET username='Account deleted'",[u.id]);
      }else await db.query("INSERT INTO banned_users (user_id,email,reason,offensive_item,expires_at,ban_type,attachment_key,attachment_name,attachment_type) VALUES ($1,$2,$3,$4,$5,'BAN',$6,$7,$8) ON CONFLICT (user_id) DO UPDATE SET email=EXCLUDED.email,reason=EXCLUDED.reason,offensive_item=EXCLUDED.offensive_item,expires_at=EXCLUDED.expires_at,ban_type='BAN',attachment_key=EXCLUDED.attachment_key,attachment_name=EXCLUDED.attachment_name,attachment_type=EXCLUDED.attachment_type",[u.id,u.email,r,offensiveItem,expires,attachmentKey||null,attachmentName||null,attachmentType||null]);
    }
    try{await notifyAdminsOfModeration('ban',u.username,r);}catch(_){ }
    return res.json({ok:true});
  }
  if(action==='unban_ip'){
    if(!u.last_ip)return res.status(400).json({error:'This user has no recorded IP.'});
    const ipResult=await db.query("DELETE FROM ip_bans WHERE ip=$1",[String(u.last_ip).trim()]);
    if(Number(ipResult.rowCount||0)>0)try{await notifyAdminsOfModeration('unban',u.username,'IP ban removed');}catch(_){ }
    return res.json({ok:true,removed_ip_bans:Number(ipResult.rowCount||0)});
  }
  if(action==='unban'){
    const removedAccount=await db.query("DELETE FROM banned_users WHERE user_id=$1 AND ban_type<>'ACD'",[u.id]);
    let removedIp=0;
    if(u.last_ip){
      const ipResult=await db.query("DELETE FROM ip_bans WHERE ip=$1",[String(u.last_ip).trim()]);
      removedIp=Number(ipResult.rowCount||0);
    }
    if(Number(removedAccount.rowCount||0)>0||removedIp>0)try{await notifyAdminsOfModeration('unban',u.username,'Ban removed');}catch(_){ }
    return res.json({ok:true,removed_account_bans:Number(removedAccount.rowCount||0),removed_ip_bans:removedIp});
  }
  if(action==='change_username'){
    const username=String(amount||'').trim();
    if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return res.status(400).json({error:'Username must be 3-20 characters and use only letters, numbers, or _.'});
    const {rows:dupe}=await db.query("SELECT user_id FROM profile_usernames WHERE lower(username)=lower($1) AND user_id<>$2 LIMIT 1",[username,u.id]);
    if(dupe.length)return res.status(409).json({error:'That username is already taken'});
    await db.query("INSERT INTO profile_usernames (user_id,username) VALUES ($1,$2) ON CONFLICT (user_id) DO UPDATE SET username=EXCLUDED.username",[u.id,username]);
    return res.json({ok:true,username});
  }
  if(action==='add_coins'||action==='remove_coins'){
    const rawAmount=Number(amount);
    if(!Number.isFinite(rawAmount)||!Number.isSafeInteger(Math.floor(rawAmount))||rawAmount<=0)return res.status(400).json({error:'Enter a whole number greater than 0.'});
    const n=Math.min(2147483647,Math.floor(rawAmount));
    const d=action==='add_coins'?n:-n;
    await db.query("INSERT INTO premium_wallets (user_id,coins) VALUES ($1,GREATEST(0,$2)) ON CONFLICT (user_id) DO UPDATE SET coins=GREATEST(0,premium_wallets.coins+$2)",[u.scope_id,d]);
    const wallet=await db.query("SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1",[u.scope_id]);
    return res.json({ok:true,coins:Number(wallet.rows[0]?.coins||0)});
  }
  return res.status(400).json({error:'Unknown action'});
}