import { db, auth, storage } from "hatchable";
import { requireStudioDevice } from "lib/studio-device";

export const access = "public";
export const methods = ["GET"];

const ASSETS = {
  wall: { name: "Wall Gamepass Script.rbxm", key: "legacy-assets/wall.b64" },
  boss: { name: "BossFight.rbxm", key: "legacy-assets/boss.b64" },
  sink: { name: "Sink.rbxm", key: "legacy-assets/sink.b64" },
  acv2: { name: "AcV2.rbxm", key: "legacy-assets/acv2.b64" },
  ac: { name: "Ac.rbxm", key: "legacy-assets/ac.b64" },
  flashlight3: { name: "FlashLight V3.rbxm", key: "legacy-assets/flashlight3.b64" },
  flashlight2: { name: "FlashLight V2.rbxm", key: "legacy-assets/flashlight2.b64" },
  workspace: { name: "Workspace deleter (Bug Fixes).rbxm", key: "legacy-assets/workspace.b64" },
  flashlight: { name: "FlashLight.rbxm", key: "legacy-assets/flashlight.b64" },
  traffic: { name: "my roblox traffic Light.rbxm", key: "legacy-assets/traffic.b64" },
  gamble: { name: "GambleGui.rbxm", key: "legacy-assets/gamble.b64" },
  door: { name: "DoorWithLock.rbxm", key: "legacy-assets/door.b64" },
  gui: { name: "GuiPart.rbxm", key: "legacy-assets/gui.b64" },
  run: { name: "RunScript.rbxm", key: "legacy-assets/run.b64" },
  settings: { name: "SettingsGui.rbxm", key: "legacy-assets/settings.b64" },
  shop: { name: "ShopGui.rbxm", key: "legacy-assets/shop.b64" },
};

export default async function (req, res) {
  if(!requireStudioDevice(req,res))return;
  const id = String(req.query?.id || "");
  const asset = ASSETS[id];
  if (!asset) return res.status(404).json({ error: "Asset not found." });

  const { rows } = await db.query(
    "SELECT premium, basic_price, disabled, disabled_reason, removed FROM page_asset_overrides WHERE legacy_id=$1 LIMIT 1",
    [id]
  );
  const override = rows[0] || {};
  if (override.removed) return res.status(404).json({ error: "Asset not found." });
  if (override.disabled) return res.status(403).json({ error: "Disabled", reason: override.disabled_reason || "Disabled by the owner." });

  const premium = override.premium === true;
  const price = Math.max(0, Number(override.basic_price || 0));
  const user = await auth.getUser(req);

  if (premium) {
    if (!user) return res.status(401).json({ error: "Sign in required for Premium assets." });
    const wallet = await db.query("SELECT premium_access FROM premium_wallets WHERE user_id=$1 LIMIT 1", [String(user.id)]);
    if (!wallet.rows[0]?.premium_access) return res.status(403).json({ error: "Premium access is required." });
  } else if (price > 0) {
    if (!user) return res.status(401).json({ error: "Sign in required to purchase this asset." });
    const owned = await db.query("SELECT 1 FROM asset_purchases WHERE user_id=$1 AND asset_key=$2 LIMIT 1", [String(user.id), `legacy-${id}`]);
    if (!owned.rows.length) return res.status(403).json({ error: "Purchase required", price });
  }

  const replacementKey = String(override.storage_key || "").trim();
  if (replacementKey) {
    const file = await storage.get(replacementKey);
    const storedName=String(replacementKey).split('/').pop()||'';
    const originalName=storedName.replace(/^(?:[0-9a-fA-F-]{36}|\d+)-/, '') || String(asset.name||'asset').trim();
    const safeName=originalName.replace(/[\\\"\r\n]/g,'_');
    const mimeByExt={'.rbxm':'application/octet-stream','.rbxmx':'application/xml','.rbxlx':'application/xml','.rbxl':'application/octet-stream','.zip':'application/zip','.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.txt':'text/plain'};
    const ext=(safeName.match(/(\.[A-Za-z0-9]+)$/)||['',''])[1].toLowerCase();
    res.setHeader("Content-Type", mimeByExt[ext] || file.contentType || "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
    res.setHeader("Cache-Control", "private, no-store");
    res.send(file.buffer);
    return;
  }

  const file = await storage.get(asset.key);
  const encoded = new TextDecoder().decode(file.buffer).trim();
  let binary;
  try { binary = atob(encoded); } catch { return res.status(500).json({ error: "Stored asset is corrupted." }); }
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  res.setHeader("Content-Type", "application/octet-stream");
  res.setHeader("Content-Disposition", `attachment; filename="${asset.name.replace(/[\\\"]+/g, "_")}"`);
  res.setHeader("Cache-Control", "private, no-store");
  res.send(bytes);
}