import { db } from "hatchable";

export const access = "user";
export const methods = ["POST"];

export default async function(req, res) {
  const userId = String(req.user.id);
  const id = String(req.body?.id || "");
  if (!id) return res.status(400).json({ error: "Missing asset id." });

  let key = id;
  let price = 0;
  let disabled = false;
  let reason = null;

  const owned = await db.query(
    "SELECT 1 FROM asset_purchases WHERE user_id=$1 AND asset_key=$2 LIMIT 1",
    [userId, key]
  );
  if (owned.rows.length) return res.json({ ok: true, purchased: true });

  if (id.startsWith("managed-")) {
    const assetId = Number(id.slice(8));
    if (!Number.isInteger(assetId) || assetId < 1) return res.status(400).json({ error: "Invalid asset id." });
    const { rows } = await db.query(
      "SELECT premium,basic_price,disabled,disabled_reason FROM managed_assets WHERE id=$1 LIMIT 1",
      [assetId]
    );
    if (!rows.length) return res.status(404).json({ error: "Asset not found." });
    const a = rows[0];
    if (a.premium) return res.status(400).json({ error: "This is a Premium asset." });
    price = Math.max(0, Number(a.basic_price || 0));
    disabled = !!a.disabled;
    reason = a.disabled_reason;
  } else if (id.startsWith("legacy-")) {
    const legacyId = id.slice(7);
    const { rows } = await db.query(
      "SELECT premium,basic_price,disabled,disabled_reason,removed FROM page_asset_overrides WHERE legacy_id=$1 LIMIT 1",
      [legacyId]
    );
    if (rows.length) {
      const a = rows[0];
      if (a.removed) return res.status(404).json({ error: "Asset not found." });
      if (a.premium) return res.status(400).json({ error: "This is a Premium asset." });
      price = Math.max(0, Number(a.basic_price || 0));
      disabled = !!a.disabled;
      reason = a.disabled_reason;
    }
  } else {
    return res.status(404).json({ error: "Asset not found." });
  }

  if (disabled) return res.status(403).json({ error: "Disabled", reason: reason || "Disabled by the owner." });

  if (price <= 0) {
    await db.query(
      "INSERT INTO asset_purchases (user_id,asset_key) VALUES ($1,$2) ON CONFLICT DO NOTHING",
      [userId, key]
    );
    return res.json({ ok: true, coins: null, purchased: true });
  }

  // Hatchable wraps single db.query calls, so don't use a data-modifying CTE here.
  // Instead use optimistic concurrency inside a real transaction: the debit only
  // succeeds if the balance we just read is still current and the asset is not
  // already purchased. A concurrent purchase therefore cannot double-charge.
  try {
    const wallet = await db.query(
      "SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1",
      [userId]
    );
    const currentCoins = Math.max(0, Number(wallet.rows[0]?.coins || 0));
    if (currentCoins < price) {
      return res.status(402).json({ error: "You don't have enough Coins.", required: price });
    }

    const expectedCoins = currentCoins - price;
    const tx = await db.transaction([
      {
        sql: `UPDATE premium_wallets
                 SET coins=$1
               WHERE user_id=$2
                 AND coins=$3
                 AND NOT EXISTS (
                   SELECT 1 FROM asset_purchases
                    WHERE user_id=$2 AND asset_key=$4
                 )
               RETURNING coins`,
        params: [expectedCoins, userId, currentCoins, key],
      },
      {
        sql: `INSERT INTO asset_purchases (user_id,asset_key)
              SELECT $1,$2
              WHERE EXISTS (
                SELECT 1 FROM premium_wallets
                 WHERE user_id=$1 AND coins=$3
              )
              ON CONFLICT DO NOTHING
              RETURNING asset_key`,
        params: [userId, key, expectedCoins],
      },
    ]);

    const updatedCoins = Number(tx.results?.[0]?.rows?.[0]?.coins);
    const inserted = tx.results?.[1]?.rows?.length > 0;
    if (!Number.isFinite(updatedCoins) || !inserted) {
      const fresh = await db.query(
        "SELECT coins FROM premium_wallets WHERE user_id=$1 LIMIT 1",
        [userId]
      );
      const freshCoins = Math.max(0, Number(fresh.rows[0]?.coins || 0));
      const alreadyOwned = await db.query(
        "SELECT 1 FROM asset_purchases WHERE user_id=$1 AND asset_key=$2 LIMIT 1",
        [userId, key]
      );
      if (alreadyOwned.rows.length) {
        return res.json({ ok: true, purchased: true, coins: freshCoins });
      }
      return res.status(402).json({ error: "You don't have enough Coins.", required: price });
    }
    return res.json({ ok: true, coins: updatedCoins, purchased: true });
  } catch (error) {
    throw error;
  }
}