import { db, storage } from "hatchable";
import { requireStudioDevice } from "lib/studio-device";

export const access = "user";
export const methods = ["GET"];

export default async function(req, res) {
  if(!requireStudioDevice(req,res))return;
  const id = Number(req.query?.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid asset id" });

  const { rows } = await db.query(
    "SELECT id,name,storage_key,disabled,disabled_reason,download_enabled,premium,basic_price FROM managed_assets WHERE id=$1 LIMIT 1",
    [id]
  );
  if (!rows.length) return res.status(404).json({ error: "Asset not found" });
  const a = rows[0];
  if (a.disabled || !a.download_enabled) return res.status(403).json({ error: "Disabled", reason: a.disabled_reason || "Disabled by the owner." });

  if (a.premium) {
    const wallet = await db.query(
      "SELECT premium_access FROM premium_wallets WHERE user_id=$1 LIMIT 1",
      [String(req.user.id)]
    );
    if (!wallet.rows[0]?.premium_access) return res.status(403).json({ error: "Premium access is required." });
  } else if (Number(a.basic_price || 0) > 0) {
    const owned = await db.query(
      "SELECT 1 FROM asset_purchases WHERE user_id=$1 AND asset_key=$2 LIMIT 1",
      [String(req.user.id), "managed-" + String(a.id)]
    );
    if (!owned.rows.length) return res.status(403).json({ error: "Purchase required", price: Number(a.basic_price) });
  }

  if (!a.storage_key) return res.status(404).json({ error: "File unavailable" });
  const file = await storage.get(a.storage_key);
  const storedName=String(a.storage_key||'').split('/').pop()||'';
  const originalName=storedName.replace(/^(?:[0-9a-fA-F-]{36}|\d+)-/, '') || String(a.name||'asset').trim();
  const safeName=originalName.replace(/[\\\"\r\n]/g,'_');
  const mimeByExt={'.rbxm':'application/octet-stream','.rbxmx':'application/xml','.rbxlx':'application/xml','.rbxl':'application/octet-stream','.zip':'application/zip','.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.txt':'text/plain'};
  const ext=(safeName.match(/(\.[A-Za-z0-9]+)$/)||['',''])[1].toLowerCase();
  res.setHeader("Content-Type", mimeByExt[ext] || file.contentType || "application/octet-stream");
  res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
  res.setHeader("Cache-Control", "private, no-store");
  res.send(file.buffer);
}