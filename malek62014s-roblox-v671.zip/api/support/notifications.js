import { db, auth } from "hatchable";

export const access = "public";
export const methods = ["GET","POST"];

function cookieGuestId(req){
  const headerId=String(req.headers?.['x-support-guest-id']||'').trim();
  if(headerId)return headerId;
  const cookieHeader=String(req.headers?.cookie||'');
  const match=cookieHeader.match(/(?:^|;\s*)support_guest_id=([^;]+)/);
  return match?decodeURIComponent(match[1]):'';
}

export default async function(req,res){
  const user=await auth.getUser(req);
  let recipientType='guest';
  let recipientId=cookieGuestId(req);
  if(user){
    recipientType='user';
    recipientId=String(user.id);
  }
  if(!recipientId)return res.json({notifications:[]});

  if(req.method==='GET'){
    const {rows}=await db.query(`SELECT id,title,message,created_at,seen_at
      FROM support_notifications
      WHERE recipient_type=$1 AND recipient_id=$2
      ORDER BY created_at DESC,id DESC LIMIT 50`,[recipientType,recipientId]);
    const notifications=rows.map(n=>{
      let title=String(n.title||'').replace(/^PRESTIGE\s*[·-]\s*/i,'');
      if(/^Support ticket closed$/i.test(title)) title='Support ticket resolved';
      const messageText=String(n.message||'');
      const message=title.toLowerCase()==='support ticket declined'
        ? messageText.replace(/\bhas been closed by\b/gi,'has been declined by')
        : messageText.replace(/\bhas been closed by\b/gi,'has been resolved by');
      return {...n,title,message};
    });
    return res.json({notifications,recipient_type:recipientType});
  }

  const id=Number(req.body?.id);
  if(!Number.isInteger(id)||id<1)return res.status(400).json({error:'Invalid notification id.'});
  await db.query(`UPDATE support_notifications SET seen_at=NOW()
    WHERE id=$1 AND recipient_type=$2 AND recipient_id=$3`,[id,recipientType,recipientId]);
  return res.json({ok:true});
}