import { db, auth } from "hatchable";
import { sendWebPushToUsers } from "lib/web-push";

export const access = "public";
export const methods = ["GET","POST"];

const CATEGORY_VALUES = new Set(["General","Asset","Download","Purchase","Account","Moderation","Bug","Suggestion"]);
const PRIORITY_VALUES = new Set(["low","normal","high"]);
const GUEST_COOKIE = "support_guest_id";
const DAILY_LIMIT = 3;

async function getUser(req){ return await auth.getUser(req); }

function getGuestId(req){
  const headerId=String(req.headers?.['x-support-guest-id']||'').trim();
  if(headerId)return headerId;
  const cookieHeader=String(req.headers?.cookie||'');
  const match=cookieHeader.match(/(?:^|;\s*)support_guest_id=([^;]+)/);
  return match?decodeURIComponent(match[1]):'';
}

function ensureGuestId(req,res){
  let id=getGuestId(req);
  if(!id){
    id='guest_'+crypto.randomUUID();
    res.cookie(GUEST_COOKIE,encodeURIComponent(id),{httpOnly:true,sameSite:'lax',secure:true,maxAge:31536000,path:'/'});
  }
  return id;
}

async function getSupportIdentity(req,res){
  const user=await getUser(req);
  if(user){
    return {user,userId:String(user.id),username:String(user.handle||user.display_name||'User').trim().slice(0,80)||'User',email:String(user.email||'').trim().slice(0,254),anonymous:false};
  }
  return {user:null,userId:ensureGuestId(req,res),username:'Unknown',email:'',anonymous:true};
}

async function getDailyCount(userId){
  const {rows}=await db.query("SELECT COUNT(*)::int AS count FROM support_tickets WHERE user_id=$1 AND created_at >= CURRENT_DATE AND created_at < CURRENT_DATE + INTERVAL '1 day'",[userId]);
  return Number(rows[0]?.count||0);
}

export default async function(req,res){
  const identity=await getSupportIdentity(req,res);
  const user=identity.user;
  const userId=identity.userId;
  const guestId=identity.anonymous?userId:getGuestId(req);

  if(req.method==='GET'){
    const {rows}=await db.query(`SELECT t.id,t.subject,t.category,t.priority,t.status,t.assigned_admin,t.created_at,t.updated_at,t.closed_at,
      (SELECT m.message FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_message,
      (SELECT m.sender_role FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_sender_role
      FROM support_tickets t WHERE t.user_id=$1 OR ($2<>'' AND t.user_id=$2) ORDER BY t.updated_at DESC,t.id DESC LIMIT 100`,[userId,guestId]);
    return res.json({tickets:rows,anonymous:identity.anonymous,guest_id:guestId||null,daily_limit:DAILY_LIMIT,daily_used:await getDailyCount(userId)});
  }

  const dailyUsed=await getDailyCount(userId);
  if(dailyUsed>=DAILY_LIMIT)return res.status(429).json({error:'You have reached the daily support ticket limit. You can create more tickets tomorrow.',code:'DAILY_TICKET_LIMIT',limit:DAILY_LIMIT});

  const subject=String(req.body?.subject||'').trim().slice(0,120);
  const category=String(req.body?.category||'General').trim();
  const priority=String(req.body?.priority||'normal').trim().toLowerCase();
  const message=String(req.body?.message||'').trim().slice(0,4000);
  if(subject.length<3)return res.status(400).json({error:'Subject must be at least 3 characters.'});
  if(!CATEGORY_VALUES.has(category))return res.status(400).json({error:'Invalid support category.'});
  if(!PRIORITY_VALUES.has(priority))return res.status(400).json({error:'Invalid support priority.'});
  if(message.length<5)return res.status(400).json({error:'Please describe the problem in at least 5 characters.'});

  const ticket=await db.query(`INSERT INTO support_tickets (user_id,user_email,username,subject,category,priority,status)
    VALUES ($1,$2,$3,$4,$5,$6,'open') RETURNING id,subject,category,priority,status,assigned_admin,created_at,updated_at`,[userId,identity.email,identity.username,subject,category,priority]);
  const t=ticket.rows[0];
  const first=await db.query(`INSERT INTO support_messages (ticket_id,sender_user_id,sender_name,sender_email,sender_role,message)
    VALUES ($1,$2,$3,$4,'user',$5) RETURNING id,ticket_id,sender_name,sender_email,sender_role,message,created_at`,[t.id,userId,identity.username,identity.email,message]);
  try{
    const {rows:admins}=await db.query("SELECT DISTINCT user_id FROM admin_user_directory WHERE is_admin=true AND user_id IS NOT NULL");
    const ids=admins.map(x=>String(x.user_id));
    const {rows:owner}=await db.query("SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1",['robloxassetsowner@protonmail.com']);
    if(owner[0]?.id)ids.push(String(owner[0].id));
    const eligible=[];
    for(const id of [...new Set(ids)]){
      const {rows:prefs}=await db.query("SELECT COALESCE(notifications_enabled,true) AS enabled,COALESCE(notification_support,true) AS support FROM user_preferences WHERE user_id=$1 LIMIT 1",[id]);
      if((!prefs.length||prefs[0].enabled!==false)&&(!prefs.length||prefs[0].support!==false))eligible.push(id);
    }
    await sendWebPushToUsers(eligible,'Customer Support','New ticket #'+String(t.id)+' · '+String(t.subject||''),'support_ticket_'+String(t.id));
  }catch(_){ }
  return res.status(201).json({ok:true,ticket:t,message:first.rows[0],guest_id:identity.anonymous?userId:null});
}