import { db, auth } from "hatchable";
import { isAdminUser } from "lib/admin-auth";

export const access = "public";
export const methods = ["GET","POST"];

function getGuestId(req){
  const cookieHeader=String(req.headers?.cookie||'');
  const match=cookieHeader.match(/(?:^|;\s*)support_guest_id=([^;]+)/);
  return match?decodeURIComponent(match[1]):'';
}

export default async function(req,res){
  const user=await auth.getUser(req);
  const identity=user||req.member||req.user||null;
  const admin=identity?await isAdminUser(String(identity.id||''),identity.email):false;
  const headerGuestId=String(req.headers?.['x-support-guest-id']||'').trim();
  const guestId=headerGuestId||getGuestId(req);
  if(!user&&!admin&&!guestId)return res.status(401).json({error:"Support ticket access could not be verified."});
  const ticketId=Number(req.params?.id);
  if(!Number.isInteger(ticketId)||ticketId<1)return res.status(400).json({error:'Invalid ticket id.'});
  const ticketResult=await db.query('SELECT id,user_id,user_email,username,subject,category,priority,status,assigned_admin,created_at,updated_at,closed_at FROM support_tickets WHERE id=$1 LIMIT 1',[ticketId]);
  if(!ticketResult.rows.length)return res.status(404).json({error:'Support ticket not found.'});
  const ticket=ticketResult.rows[0];
  const isGuestTicket=String(ticket.user_id||'').startsWith('guest_');
  const ownerId=isGuestTicket?String(guestId||''):String(user?.id||identity?.id||'');
  if(!admin&&(!ownerId||String(ticket.user_id)!==ownerId))return res.status(403).json({error:'You do not have access to this ticket.'});

  if(req.method==='GET'){
    const {rows:messages}=await db.query('SELECT id,ticket_id,sender_user_id,sender_name,sender_email,sender_role,message,created_at FROM support_messages WHERE ticket_id=$1 ORDER BY created_at ASC,id ASC LIMIT 500',[ticketId]);
    return res.json({ticket,messages});
  }

  if(!admin&&String(ticket.user_id)!==ownerId)return res.status(403).json({error:'You do not have access to this ticket.'});
  const message=String(req.body?.message||'').trim().slice(0,4000);
  if(message.length<1)return res.status(400).json({error:'Message cannot be empty.'});
  if(ticket.status==='closed')return res.status(409).json({error:'This ticket is closed. Open a new ticket for a new issue.'});
  const senderName=admin?'Support Team':String(identity?.handle||identity?.display_name||ticket.username||'User').slice(0,80);
  const senderRole=admin?'admin':'user';
  const senderEmail=String(identity?.email||'').slice(0,254);
  const inserted=await db.query(`INSERT INTO support_messages (ticket_id,sender_user_id,sender_name,sender_email,sender_role,message)
    VALUES ($1,$2,$3,$4,$5,$6) RETURNING id,ticket_id,sender_user_id,sender_name,sender_email,sender_role,message,created_at`,[ticketId,ownerId,senderName,senderEmail,senderRole,message]);
  const nextStatus=admin?'waiting_user':'open';
  await db.query(`UPDATE support_tickets SET status=$2,updated_at=NOW(),closed_at=NULL WHERE id=$1`,[ticketId,nextStatus]);
  return res.status(201).json({ok:true,message:inserted.rows[0],status:nextStatus});
}