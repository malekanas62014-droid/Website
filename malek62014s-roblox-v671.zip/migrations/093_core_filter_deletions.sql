CREATE TABLE IF NOT EXISTS core_filter_deletions (
  term TEXT PRIMARY KEY,
  deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO core_filter_deletions (term)
SELECT DISTINCT lower(term)
FROM core_filter_overrides
WHERE is_custom=false AND enabled=false
  AND term IS NOT NULL AND trim(term)<>''
ON CONFLICT (term) DO NOTHING;