ALTER TABLE user_preferences ADD COLUMN IF NOT EXISTS notification_logins BOOLEAN NOT NULL DEFAULT TRUE;
CREATE TABLE IF NOT EXISTS user_login_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  username text NOT NULL,
  session_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, session_key)
);
CREATE INDEX IF NOT EXISTS idx_user_login_events_created ON user_login_events(created_at DESC);