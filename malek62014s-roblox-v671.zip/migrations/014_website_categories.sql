CREATE TABLE IF NOT EXISTS website_categories (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, slug TEXT NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
INSERT INTO website_categories (name,slug) VALUES ('Flashlights','flashlights') ON CONFLICT (slug) DO NOTHING;
INSERT INTO website_categories (name,slug) VALUES ('Scripts','scripts') ON CONFLICT (slug) DO NOTHING;
INSERT INTO website_categories (name,slug) VALUES ('Models','models') ON CONFLICT (slug) DO NOTHING;
INSERT INTO website_categories (name,slug) VALUES ('Tools','tools') ON CONFLICT (slug) DO NOTHING;
INSERT INTO website_categories (name,slug) VALUES ('Everything','everything') ON CONFLICT (slug) DO NOTHING;
ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT '';