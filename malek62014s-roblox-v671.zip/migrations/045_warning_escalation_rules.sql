CREATE TABLE IF NOT EXISTS warning_escalation_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warning_count integer NOT NULL CHECK (warning_count >= 1 AND warning_count <= 1000),
  action text NOT NULL CHECK (action IN ('warn','ban','permanent_ban')),
  reason text NOT NULL DEFAULT '',
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
)