ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS disabled boolean NOT NULL DEFAULT false;
ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS disabled_reason text;
ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS basic_price numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS premium_price numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE managed_assets ADD COLUMN IF NOT EXISTS download_enabled boolean NOT NULL DEFAULT true;