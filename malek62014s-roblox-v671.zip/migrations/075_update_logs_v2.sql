ALTER TABLE update_logs ALTER COLUMN version TYPE TEXT USING version::text;
ALTER TABLE update_logs ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'Update';
UPDATE update_logs SET version='1',title='Update Logs are live',summary='Added a member-only Update Logs page so you can see the latest website changes, fixes, and new features in one place.',kind='Feature' WHERE version='544';
INSERT INTO update_logs (version,title,summary,kind) SELECT '1.1','Notifications are cleaner','Removed the New App Install notification so notification settings stay focused on useful alerts.','Improvement' WHERE NOT EXISTS (SELECT 1 FROM update_logs WHERE version='1.1');
CREATE UNIQUE INDEX IF NOT EXISTS update_logs_version_unique ON update_logs(version);