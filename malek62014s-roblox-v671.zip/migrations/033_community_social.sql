CREATE TABLE IF NOT EXISTS user_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_user_id text NOT NULL,
  reporter_username text NOT NULL,
  reported_user_id text NOT NULL,
  reported_username text NOT NULL,
  category text NOT NULL,
  details text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolved_by text
);
CREATE INDEX IF NOT EXISTS idx_user_reports_status_created ON user_reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_reports_reported ON user_reports(reported_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS direct_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_user_id text NOT NULL,
  sender_username text NOT NULL,
  recipient_user_id text NOT NULL,
  recipient_username text NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  read_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_direct_messages_pair ON direct_messages(sender_user_id, recipient_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_direct_messages_recipient ON direct_messages(recipient_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS chat_filters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  term text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_filters_enabled ON chat_filters(enabled);