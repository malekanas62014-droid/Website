CREATE OR REPLACE FUNCTION reserve_username_change(p_user_id text)
RETURNS TABLE(ok boolean,reservation_id uuid,coins integer,error text)
LANGUAGE plpgsql
AS $$
DECLARE
  v_coins integer;
  v_existing uuid;
BEGIN
  INSERT INTO premium_wallets (user_id,coins,premium_access)
  VALUES (p_user_id,0,false)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT w.coins INTO v_coins
  FROM premium_wallets w
  WHERE w.user_id=p_user_id
  FOR UPDATE;

  SELECT r.id INTO v_existing
  FROM username_change_reservations r
  WHERE r.user_id=p_user_id
    AND r.status='pending'
    AND r.created_at > NOW() - INTERVAL '30 minutes'
  ORDER BY r.created_at DESC
  LIMIT 1;

  IF v_existing IS NOT NULL THEN
    RETURN QUERY SELECT true,v_existing,v_coins,NULL::text;
    RETURN;
  END IF;

  IF COALESCE(v_coins,0) < 25 THEN
    RETURN QUERY SELECT false,NULL::uuid,COALESCE(v_coins,0),'You don''t have enough Coins to change your username. You need 25 Coins.'::text;
    RETURN;
  END IF;

  UPDATE premium_wallets
  SET coins=coins-25
  WHERE user_id=p_user_id;

  INSERT INTO username_change_reservations (user_id,amount,status)
  VALUES (p_user_id,25,'pending')
  RETURNING id INTO reservation_id;

  RETURN QUERY SELECT true,reservation_id,v_coins-25,NULL::text;
END;
$$