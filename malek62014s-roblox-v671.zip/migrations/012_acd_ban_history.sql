CREATE TABLE IF NOT EXISTS ban_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  email TEXT,
  username TEXT,
  ban_type TEXT NOT NULL DEFAULT 'BAN',
  reason TEXT,
  banned_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS deleted_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  email TEXT NOT NULL,
  deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (email)
);
CREATE INDEX IF NOT EXISTS idx_ban_history_email ON ban_history(email);
CREATE INDEX IF NOT EXISTS idx_ban_history_user_id ON ban_history(user_id);