CREATE TABLE IF NOT EXISTS web_push_vapid_keys (
  id INTEGER PRIMARY KEY CHECK (id=1),
  public_jwk JSONB NOT NULL,
  private_jwk JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)