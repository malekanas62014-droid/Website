ALTER TABLE user_reports ADD COLUMN IF NOT EXISTS source_type text NOT NULL DEFAULT 'user';
ALTER TABLE user_reports ADD COLUMN IF NOT EXISTS source_message_id text;