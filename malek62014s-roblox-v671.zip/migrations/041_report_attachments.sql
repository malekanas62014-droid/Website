CREATE TABLE IF NOT EXISTS user_report_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES user_reports(id) ON DELETE CASCADE,
  filename text NOT NULL,
  content_type text NOT NULL,
  storage_key text NOT NULL,
  size_bytes integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
)