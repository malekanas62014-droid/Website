CREATE TABLE IF NOT EXISTS profile_usernames (
  user_id text PRIMARY KEY,
  username text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);