CREATE TABLE IF NOT EXISTS user_filter_escalation_cycles (
  user_id TEXT NOT NULL,
  filter_term TEXT NOT NULL,
  warning_count INTEGER NOT NULL DEFAULT 0,
  last_violation_at TIMESTAMPTZ NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, filter_term)
);