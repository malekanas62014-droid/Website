CREATE TABLE IF NOT EXISTS manual_update_release (
  id integer PRIMARY KEY,
  release_version bigint NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO manual_update_release (id, release_version)
VALUES (1, 635)
ON CONFLICT (id) DO NOTHING;