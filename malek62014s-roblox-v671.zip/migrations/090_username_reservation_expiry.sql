CREATE OR REPLACE FUNCTION expire_username_change_reservation(p_user_id text)
RETURNS TABLE(ok boolean,refunded boolean,coins integer,amount integer,message text)
LANGUAGE plpgsql
AS $$
DECLARE
  v_id uuid;
  v_amount integer;
  v_coins integer;
BEGIN
  SELECT r.id,r.amount INTO v_id,v_amount
  FROM username_change_reservations r
  WHERE r.user_id=p_user_id
    AND r.status='pending'
    AND r.created_at <= NOW() - INTERVAL '30 minutes'
  ORDER BY r.created_at DESC
  LIMIT 1
  FOR UPDATE;

  IF v_id IS NULL THEN
    SELECT w.coins INTO v_coins FROM premium_wallets w WHERE w.user_id=p_user_id LIMIT 1;
    RETURN QUERY SELECT true,false,COALESCE(v_coins,0),0,'No expired reservation.'::text;
    RETURN;
  END IF;

  UPDATE premium_wallets SET coins=coins+v_amount WHERE user_id=p_user_id RETURNING premium_wallets.coins INTO v_coins;
  UPDATE username_change_reservations SET status='refunded',settled_at=NOW() WHERE id=v_id AND user_id=p_user_id AND status='pending';
  RETURN QUERY SELECT true,true,COALESCE(v_coins,0),v_amount,'Expired username reservation refunded.'::text;
END;
$$