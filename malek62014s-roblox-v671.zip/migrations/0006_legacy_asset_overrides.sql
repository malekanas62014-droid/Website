CREATE TABLE IF NOT EXISTS legacy_asset_overrides (
  legacy_id text PRIMARY KEY,
  premium boolean,
  basic_price numeric(12,2),
  premium_price numeric(12,2),
  updated_at timestamptz NOT NULL DEFAULT now()
);