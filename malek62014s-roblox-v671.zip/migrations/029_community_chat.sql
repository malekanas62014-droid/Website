CREATE TABLE chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  username text NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_chat_messages_created_at ON chat_messages (created_at DESC);
CREATE INDEX idx_chat_messages_user_id ON chat_messages (user_id);

CREATE TABLE chat_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  username text NOT NULL,
  message text NOT NULL,
  reason text NOT NULL DEFAULT 'Vulgar language detected',
  matched_terms text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_chat_logs_created_at ON chat_logs (created_at DESC);
CREATE INDEX idx_chat_logs_user_id ON chat_logs (user_id);