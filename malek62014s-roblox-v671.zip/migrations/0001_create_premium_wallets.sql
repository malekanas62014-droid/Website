CREATE TABLE premium_wallets (
  user_id TEXT PRIMARY KEY,
  coins INTEGER NOT NULL DEFAULT 5 CHECK (coins >= 0),
  premium_access BOOLEAN NOT NULL DEFAULT false,
  last_reward_week DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
)