ALTER TABLE user_preferences ADD COLUMN IF NOT EXISTS notification_friend_requests BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE user_preferences ADD COLUMN IF NOT EXISTS notification_followers BOOLEAN NOT NULL DEFAULT TRUE;
CREATE TABLE IF NOT EXISTS tos_meta (
  id BOOLEAN PRIMARY KEY DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO tos_meta (id,updated_at) VALUES (TRUE,NOW()) ON CONFLICT (id) DO NOTHING;
CREATE TABLE IF NOT EXISTS tos_sections (
  id BIGSERIAL PRIMARY KEY,
  section_number INTEGER NOT NULL DEFAULT 1,
  kicker TEXT NOT NULL DEFAULT 'Community',
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tos_sections_order ON tos_sections(active,sort_order,id);
INSERT INTO tos_sections (section_number,kicker,title,body,sort_order,active)
SELECT 11,'07 · Profiles','Profile bios','Profile bios must follow the same community standards as other content on the website. Do not use a bio for harassment, threats, hate, sexual content, scams, malicious links, personal information, impersonation, or attempts to bypass moderation. A bio may be removed or restricted when it violates these Terms.',11,TRUE
WHERE NOT EXISTS (SELECT 1 FROM tos_sections WHERE title='Profile bios');