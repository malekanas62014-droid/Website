-- Move the complete built-in Terms of Service into the editable Terms manager.
-- Titles are checked before inserting so this stays safe if a section already exists.
INSERT INTO tos_sections (section_number,kicker,title,body,sort_order,active)
SELECT v.section_number,v.kicker,v.title,v.body,v.sort_order,v.active
FROM (VALUES
  (0, 'Overview', 'Terms overview', $body$These Terms establish the rules for using malek62014's Roblox Assets, including accounts, downloads, Premium features, Coins, community tools, support, and moderation.$body$, 0, TRUE),
  (1, '01 · Conduct', 'Use the site responsibly', $body$- Do not use the site to harass, threaten, scam, impersonate, or target other users.
- Do not post or send hate speech, serious harassment, sexual content involving minors, or content that encourages real-world violence.
- Do not spam, flood, exploit bugs, bypass rate limits, or intentionally disrupt the site or its services.
- Do not attempt to access another user's account, private messages, moderation tools, or administrative features without permission.$body$, 1, TRUE),
  (2, '02 · Identity', 'Accounts', $body$- Keep access to your email account secure. Sign-in codes are private and should never be shared.
- Do not create or use accounts to evade a ban, warning, restriction, or other moderation action.
- Information you provide should not be intentionally misleading or used to impersonate another person.
- You may request help with an account issue through Customer Support.$body$, 2, TRUE),
  (3, '03 · Privacy', 'Privacy & information use', $body$We do not steal your account information.

We do not ask you to provide your Roblox password, your email password, recovery codes, browser passwords, or payment-card numbers. Sign-in uses a one-time code sent to the email address associated with your account. We use information only for operating the service, providing account features, processing site activity, support, security, and moderation.

Email & account identity — Used to sign you in, associate your account, and provide account features.
Support & community messages — Stored so support tickets, chat moderation, reports, and replies can function.
Security information — A limited record of network information such as a last-seen IP may be retained for security and network-ban enforcement.

We do not sell or rent your personal information. We also do not use your information to take control of your Roblox account. Never send passwords, authentication codes, or other secrets in a support ticket.$body$, 3, TRUE),
  (4, '04 · Content', 'Assets and downloads', $body$- Assets are provided for their stated purpose, primarily use with Roblox Studio.
- Do not redistribute, resell, re-upload, or claim ownership of assets unless you have the rights or permission to do so.
- Do not use downloads to intentionally damage another person's game, device, account, or data.
- Some assets may be free, paid with site Coins, or limited to Premium access. Availability and pricing may change.$body$, 4, TRUE),
  (5, '05 · Commerce', 'Coins, Premium, and purchases', $body$- Coins and Premium access are website features and have no cash value unless explicitly stated otherwise.
- Do not exploit bugs or automation to generate, duplicate, transfer, or spend Coins improperly.
- Access to an asset may be removed, disabled, or changed when necessary for security, ownership, compatibility, or moderation reasons.$body$, 5, TRUE),
  (6, '06 · Community', 'Chat, DMs, and reports', $body$- Keep community conversations reasonably respectful. Disagreements are allowed; abuse and targeted harassment are not.
- Do not use chat or DMs for spam, threats, scams, malicious links, or prohibited content.
- Profile bios are public content and must follow the same community standards. Do not use a bio for harassment, threats, hate, sexual content, scams, malicious links, personal information, impersonation, or attempts to bypass moderation.
- Use the report system honestly. False, abusive, or intentionally misleading reports may themselves lead to moderation action.$body$, 6, TRUE),
  (7, '07 · Enforcement', 'Moderation and enforcement', $body$We may review content and account activity to enforce these Terms and protect the community. Depending on the situation, enforcement can include a warning, chat restriction, temporary ban, permanent ban, account deletion, or IP-based restriction.

Serious violations may receive stronger action without requiring previous warnings. We may also take action against attempts to evade moderation.

Moderation decisions are made based on the information available at the time and may consider severity, context, repetition, and prior history.$body$, 7, TRUE),
  (8, '08 · Security', 'Security and abuse', $body$- Do not probe, attack, overload, scrape aggressively, or attempt to bypass security controls or access restrictions.
- Do not upload files or content designed to compromise the site, other users, or their devices.
- Please report security issues to the site owner rather than exploiting them against other users.$body$, 8, TRUE),
  (9, '09 · Service', 'Availability and changes', $body$The site, assets, features, Coins, Premium access, and community systems may be changed, suspended, or discontinued at any time. We do not guarantee that every asset or feature will always be available or error-free.

These Terms may be updated as the website changes. The latest version published on this page is the version that applies to future use of the site.$body$, 9, TRUE),
  (10, '10 · Rights', 'Respect other people''s rights', $body$Do not upload, distribute, or claim material that you do not have the right to use. If you believe an asset or other content infringes your rights, contact the site owner with enough information to identify the material and explain the issue.$body$, 10, TRUE),
  (11, '11 · Profiles', 'Profile bios', $body$Profile bios must follow the same community standards as other content on the website. Do not use a bio for harassment, threats, hate, sexual content, scams, malicious links, personal information, impersonation, or attempts to bypass moderation. A bio may be removed or restricted when it violates these Terms.$body$, 11, TRUE),
  (12, 'Legal note', 'A note on these Terms', $body$These Terms are written to make the site's rules understandable and predictable. They are practical community terms, not a substitute for jurisdiction-specific legal advice. Continued use of the service after an updated version is published means the updated Terms apply to future use.$body$, 12, TRUE)
) AS v(section_number,kicker,title,body,sort_order,active)
WHERE NOT EXISTS (
  SELECT 1 FROM tos_sections existing WHERE lower(existing.title)=lower(v.title)
);

UPDATE tos_sections
SET section_number=11,kicker='11 · Profiles',sort_order=11,updated_at=NOW()
WHERE lower(title)=lower('Profile bios');

UPDATE tos_meta SET updated_at=NOW() WHERE id=TRUE;