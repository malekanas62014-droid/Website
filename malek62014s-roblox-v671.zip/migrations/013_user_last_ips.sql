CREATE TABLE IF NOT EXISTS user_last_ips (
  user_id TEXT PRIMARY KEY,
  last_ip TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);