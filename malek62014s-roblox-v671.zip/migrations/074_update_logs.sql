CREATE TABLE IF NOT EXISTS update_logs (
  id BIGSERIAL PRIMARY KEY,
  version INTEGER NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO update_logs (version, title, summary)
SELECT 544, 'Update Log is here', 'Added the new member-only /logs page and started the site update history. Future site changes will be recorded here as release-style updates.'
WHERE NOT EXISTS (SELECT 1 FROM update_logs WHERE version = 544);