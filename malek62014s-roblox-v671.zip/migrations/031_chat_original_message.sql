ALTER TABLE chat_logs ADD COLUMN IF NOT EXISTS original_message text;
UPDATE chat_logs SET original_message=message WHERE original_message IS NULL;
CREATE INDEX IF NOT EXISTS idx_chat_logs_original_message ON chat_logs (id);