CREATE TABLE IF NOT EXISTS admin_user_directory (
  user_id text PRIMARY KEY,
  email text,
  username text,
  banned boolean NOT NULL DEFAULT false,
  coins integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);