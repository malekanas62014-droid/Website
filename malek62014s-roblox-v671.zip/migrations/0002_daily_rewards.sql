CREATE TABLE IF NOT EXISTS daily_rewards (
  user_id text PRIMARY KEY,
  last_claim_date date,
  streak integer NOT NULL DEFAULT 0,
  total_claims integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);