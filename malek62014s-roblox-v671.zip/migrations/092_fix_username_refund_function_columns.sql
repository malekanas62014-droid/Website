CREATE OR REPLACE FUNCTION refund_username_change(p_user_id text,p_reservation_id uuid)
RETURNS TABLE(ok boolean,refunded boolean,coins integer,amount integer,message text)
LANGUAGE plpgsql
AS $$
DECLARE
  v_amount integer;
  v_coins integer;
BEGIN
  SELECT r.amount INTO v_amount FROM username_change_reservations AS r WHERE r.id=p_reservation_id AND r.user_id=p_user_id AND r.status='pending' FOR UPDATE;
  IF v_amount IS NULL THEN
    SELECT w.coins INTO v_coins FROM premium_wallets AS w WHERE w.user_id=p_user_id LIMIT 1;
    RETURN QUERY SELECT true,false,COALESCE(v_coins,0),0,'Coins were already settled.'::text;
    RETURN;
  END IF;
  UPDATE premium_wallets AS w SET coins=w.coins+v_amount WHERE w.user_id=p_user_id RETURNING w.coins INTO v_coins;
  UPDATE username_change_reservations AS r SET status='refunded',settled_at=NOW() WHERE r.id=p_reservation_id AND r.user_id=p_user_id AND r.status='pending';
  RETURN QUERY SELECT true,true,COALESCE(v_coins,0),v_amount,'Username change Coins were refunded.'::text;
END;
$$