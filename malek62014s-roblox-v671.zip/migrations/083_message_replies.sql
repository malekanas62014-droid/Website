ALTER TABLE direct_messages ADD COLUMN IF NOT EXISTS reply_to_id uuid;
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS reply_to_id uuid;
CREATE INDEX IF NOT EXISTS idx_direct_messages_reply_to ON direct_messages(reply_to_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_reply_to ON chat_messages(reply_to_id);