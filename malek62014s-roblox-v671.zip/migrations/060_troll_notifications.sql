CREATE TABLE IF NOT EXISTS troll_notifications (
  id BIGSERIAL PRIMARY KEY,
  recipient_id TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  button_text TEXT NOT NULL DEFAULT 'Got it',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  seen_at TIMESTAMPTZ NULL
)