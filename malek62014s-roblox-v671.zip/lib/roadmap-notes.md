# Roadmap / Ideas

## Open idea (added 2026-07-31)
- Translate EVERY UI string, basically everything on the page (including any
  remaining hardcoded/English-only text, aria-labels, alt text, tooltips,
  modal copy, toast copy) across all 11 supported languages.
- Add sound effects (e.g. hover tick, click, download start, success chime,
  error buzz) — respect a mute toggle and browser autoplay restrictions.
- Add more animations throughout (hero, cards, transitions, modals, category
  switches) to make the site feel more alive — "5x cooler" ask from the user.

Not yet implemented — pick this up on the next pass.